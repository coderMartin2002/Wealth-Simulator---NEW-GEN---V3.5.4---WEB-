let updates_hub_ui = document.getElementById("updates-hub-ui");
let updates_hub_ui_menu_opt = document.getElementById("update-notes-ui-btn");
let close_updates_hub_ui_opt = document.getElementById("close-updates-ui-btn");

updates_hub_ui_menu_opt.onclick = function() {
    updates_hub_ui.style.display = "flex";
    challenge_hub_ui.style.display = "none";
    console_ui.style.display = "none";
    document.getElementById("inventory-ui").style.display = "none";
    document.getElementById("fund-farms-ui").style.display = "none";
    document.getElementById("guessing-game-ui").style.display = "none";
    document.getElementById("store-ui").style.display = "none";
    document.getElementById("gambling-hub-ui").style.display = "none";
    document.getElementById("settings-ui").style.display = "none";
    document.getElementById("gambling-hub-ui-2").style.display = "none";
}

close_updates_hub_ui_opt.onclick = function() {
    updates_hub_ui.style.display = "none";
}