let v321 = document.getElementById("v-3.2.1");
let v332 = document.getElementById("v-3.3.2");
let v343 = document.getElementById("v-3.4.3");
let v344 = document.getElementById("v-3.5.4");

let version_slot_opt_1 = document.getElementById("version-slot-opt-1");
let version_slot_opt_2 = document.getElementById("version-slot-opt-2");
let version_slot_opt_3 = document.getElementById("version-slot-opt-3");
let version_slot_opt_4 = document.getElementById("version-slot-opt-4");

version_slot_opt_1.addEventListener("click", () => { v321.scrollIntoView({behavior: "smooth", block: "center"}); })
version_slot_opt_2.addEventListener("click", () => { v332.scrollIntoView({behavior: "smooth", block: "center"}); })
version_slot_opt_3.addEventListener("click", () => { v343.scrollIntoView({behavior: "smooth", block: "center"}); })
version_slot_opt_4.addEventListener("click", () => { v344.scrollIntoView({behavior: "smooth", block: "center"}); })

document.getElementById("version-sect").onclick = function() {
    setTimeout(() => { updates_hub_ui_menu_opt.click(); }, 500)
    setTimeout(() => { version_slot_opt_4.click(); }, 1200)
}