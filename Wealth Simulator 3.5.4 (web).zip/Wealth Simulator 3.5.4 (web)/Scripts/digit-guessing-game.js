let rand_digit_inp = document.getElementById("rand-digit-inp");
let rand_digit_output = document.getElementById("rand-digit-output");
let rand_digit_rng_arr = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
let start_digit_match_opt_btn = document.getElementById("start-digit-match-btn");
let random_digit_opt = document.getElementById("random-digit-opt");
let digit_guess_match_win = 2.50;
let digit_guess_match_streak_counter = 0;
let digit_guess_mismatch_counter = 0;

let total_guessing_matches_won = 0;
let total_guessing_matches_lost = 0;
let total_guessing_matches_cash_earned = 0;

random_digit_opt.onclick = function() {
    let random_digit = Math.floor(Math.random() * rand_digit_rng_arr.length);
    rand_digit_inp.value = random_digit;
    keyboardClickAudio();
}

function matchWin() {
    digit_guess_match_streak_counter++;
    digit_guess_mismatch_counter = 0;
}

function matchWinAward(win_type, win_amount) {
    notificationDialog(win_type + " > " + "<span style='color: lime; margin-left: 6px;'>YOU WON $" + formatMoneyValue(win_amount) + "</span>" + "<span style='margin-left: 6px; margin-right: 6px;'>&</span>" + "<span style='color: yellow;'> X1 MYSTERY TOKEN</span>", 5000);
    player_cash_balance += win_amount;
    inventory_slot_9_player_owned_amount++;
    total_guessing_matches_won++;
}

start_digit_match_opt_btn.onclick = function() {
    document.getElementById("usr-selected-digit-output").style.display = "block";
    document.getElementById("rand-digit-output").style.display = "block";
    let final_rng_value = rand_digit_rng_arr[Math.floor(Math.random() * rand_digit_rng_arr.length)];
    keyboardClickAudio();

    if (rand_digit_inp.value == "") {
        alert("You must enter a digit!");
    } else if (rand_digit_inp.value > 10) {
        alert("You cannot exceed 10!");
    } else  {
        random_digit_opt.disabled = true; random_digit_opt.style.cursor = "not-allowed"; random_digit_opt.style.opacity = "0.5";
        start_digit_match_opt_btn.disabled = true; start_digit_match_opt_btn.style.cursor = "not-allowed"; start_digit_match_opt_btn.style.opacity = "0.5";
        rand_digit_inp.disabled = true; rand_digit_inp.style.cursor = "not-allowed"; rand_digit_inp.style.opacity = "0.5";
        document.getElementById("usr-selected-digit-output").innerHTML = "YOUR NUMBER: " + "<span style='color: aquamarine;'>" + rand_digit_inp.value + "</span>";
        document.getElementById("rand-digit-output").innerHTML = "WINNING NUMBER: " + "<span style='color: yellow;'>" + final_rng_value + "</span>";

        let rand_digit_rng_int = setInterval( function() {
            rand_digit_output.innerHTML = "WINNING NUMBER: " + "<span style='color: yellow;'>" + rand_digit_rng_arr[Math.floor(Math.random() * rand_digit_rng_arr.length)] + "</span>";
        }, 100)
        setTimeout( function()  {
            clearInterval(rand_digit_rng_int);
            rand_digit_output.innerHTML = "WINNING NUMBER: " + "<span style='color: yellow;'>" + final_rng_value + "</span>";

            if (final_rng_value == rand_digit_inp.value) {
                matchWin();
                matchWinAward("WINNING MATCH!", digit_guess_match_win);

                document.getElementById("mismatch-1").innerHTML = "";
                document.getElementById("mismatch-2").innerHTML = "";
                document.getElementById("mismatch-3").innerHTML = "";


                /*
                setTimeout(() => {
                    document.getElementById("usr-selected-digit-output").style.display = "none";
                    document.getElementById("rand-digit-output").style.display = "none";
                }, 1000)
                */

                if (task_4_active) {
                    task_4_progress++;
                    task_4_progress_bar.value++;
                }

                total_guessing_matches_cash_earned += digit_guess_match_win;

            } else {
                //notificationDialog("MISMATCH!", 2000);
                upgradePurchaseFailedAudio();
                total_guessing_matches_lost++;
                digit_guess_mismatch_counter++;
            }
            setTimeout(() => {
                random_digit_opt.disabled = false; random_digit_opt.style.cursor = "pointer"; random_digit_opt.style.opacity = "1";
                start_digit_match_opt_btn.disabled = false; start_digit_match_opt_btn.style.cursor = "pointer"; start_digit_match_opt_btn.style.opacity = "1";
                rand_digit_inp.disabled = false; rand_digit_inp.style.cursor = "text"; rand_digit_inp.style.opacity = "1";
            }, 1000)
        }, 3500)
    }
}
