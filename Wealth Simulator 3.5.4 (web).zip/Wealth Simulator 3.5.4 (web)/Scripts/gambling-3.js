let spin_btn_3 = document.getElementById("spin-btn-3");

let final_booster_slot_1_id = document.getElementById("booster-slot-symbol-1");
let final_booster_slot_2_id = document.getElementById("booster-slot-symbol-2");
let final_booster_slot_3_id = document.getElementById("booster-slot-symbol-3");

let final_booster_slot_id_storage = [final_booster_slot_1_id, final_booster_slot_2_id, final_booster_slot_3_id];

let booster_reel_slot_1 = document.getElementById("gambling-booster-slot-1");
let booster_reel_slot_2 = document.getElementById("gambling-booster-slot-2");
let booster_reel_slot_3 = document.getElementById("gambling-booster-slot-3");

let booster_slot_1_int;
let booster_slot_2_int;
let booster_slot_3_int;

let booster_slot_int_storage = [booster_slot_1_int, booster_slot_2_int, booster_slot_3_int];
let booster_reels_storage = [booster_reel_slot_1, booster_reel_slot_2, booster_reel_slot_3];

let x2_farm_income_booster_probability = 2;
let x3_farm_income_booster_probability = 4; 
let x2_farm_speed_booster_probability = 10;
let x5_farm_speed_booster_probability = 20;
let x2_level_xp_booster_probability = 25;

let mystery_token_probability = 40;
let streak_saver_booster_probability = 25;
let extra_wilds_booster_probability = 30;
let instant_level_xp_booster_probability = 5;
let trivia_extra_attempt_booster_probability = 12;

document.getElementById("booster-spinner-opt").onclick = function() { 
    document.getElementById("gambling-hub-ui-3").style.display = "flex"; 
    document.getElementById("slot-selection-dialog-overlay").style.display = "none";
    document.getElementById("gambling-hub-ui").style.display = "none"; 
    document.getElementById("gambling-hub-ui-2").style.display = "none";

}
document.getElementById("close-gambling-hub-ui-btn-3").onclick = function() { document.getElementById("gambling-hub-ui-3").style.display = "none"; }

function rareBoosterWinsRNG(slot_reel) { // RARE WIN RNG
    let mystery_token_win = Math.floor(Math.random() * mystery_token_probability);
    let x2_farm_income_booster_win = Math.floor(Math.random() * x2_farm_income_booster_probability);
    let x3_farm_income_booster_win = Math.floor(Math.random() * x3_farm_income_booster_probability);
    let x2_farm_speed_booster_win = Math.floor(Math.random() * x2_farm_income_booster_probability);
    let x5_farm_speed_booster_win = Math.floor(Math.random() * x5_farm_speed_booster_probability);
    let x2_level_xp_booster_win = Math.floor(Math.random() * x2_level_xp_booster_probability);

    let extra_wilds_booster_win = Math.floor(Math.random() * extra_wilds_booster_probability);
    let instant_level_xp_booster_win = Math.floor(Math.random() * instant_level_xp_booster_probability);
    let trivia_extra_attempt_booster_win = Math.floor(Math.random() * trivia_extra_attempt_booster_probability);
    let streak_saver_booster_win = Math.floor(Math.random() * streak_saver_booster_probability);

    if (mystery_token_win === 1) {
        slot_reel.src = "Images/mystery-booster.svg";
    } else if (x2_farm_income_booster_win === 1) {
        slot_reel.src = "Images/x2-income.svg";
    } else if (x3_farm_income_booster_win === 1) {
        slot_reel.src = "Images/x3-income.svg";
    } else if (x2_farm_speed_booster_win === 1) {
        slot_reel.src = "Images/x2-farm-speed.svg";
    } else if (x5_farm_speed_booster_win === 1) {
        slot_reel.src = "Images/x5-farm-speed.svg";
    } else if (x2_level_xp_booster_win === 1) {
        slot_reel.src = "Images/x2-level-xp-booster.svg";
    } else if (extra_wilds_booster_win === 1) {
        slot_reel.src = "Images/wild-50-percent.svg";
    } else if (instant_level_xp_booster_win === 1) {
        slot_reel.src = "Images/instant-level-up-booster.svg";
    } else if (trivia_extra_attempt_booster_win === 1) {
        slot_reel.src = "Images/trivia-heart-plus-one.svg";
    } else if (streak_saver_booster_win === 1) {
        slot_reel.src = "Images/tick-icon.svg";
    } else {
        
    }
}

function boosterSlotWinVisual(highlight_accent, win) {
    bonusWinAudio();
    for (let i = 0; i < booster_reels_storage.length; i++) {
        booster_reels_storage[i].style.border = "5px solid " + highlight_accent;
    }
    notificationDialog(win + " BOOSTER CREDITED TO INVENTORY!", 3000)
}

function disableSpinOpt() { spin_btn_3.disabled = true; spin_btn_3.style.opacity = "0.5"; spin_btn_3.style.cursor = "not-allowed"; }
function enableSpinOpt() { spin_btn_3.disabled = false; spin_btn_3.style.opacity = "1"; spin_btn_3.style.cursor = "pointer"; }

function initiateBoosterSpin() {  // SPIN INITIATION SEQUENCE
    initiateReelRotation();

    booster_slot_1_int = setInterval(() => {
        rareBoosterWinsRNG(document.getElementById("booster-slot-symbol-1"));
    }, 200)
    booster_slot_2_int = setInterval(() => {
        rareBoosterWinsRNG(document.getElementById("booster-slot-symbol-2"));
    }, 200)
    booster_slot_3_int = setInterval(() => {
        rareBoosterWinsRNG(document.getElementById("booster-slot-symbol-3"));
    }, 200)

    spinningReelsAudio();
    addPlayerLvlXp(100);

    for (let i = 0; i < final_booster_slot_id_storage.length; i++) { final_booster_slot_id_storage[i].style.border = "5px solid black"; }

    setTimeout(() => {
        clearInterval(booster_slot_1_int);
        clearInterval(booster_slot_2_int);
        clearInterval(booster_slot_3_int);

        setTimeout(() => { enableSpinOpt(); }, 1000)
        

        // FINAL REEL OUTPUT ID's

        let final_booster_slot_1_id = document.getElementById("booster-slot-symbol-1");
        let final_booster_slot_2_id = document.getElementById("booster-slot-symbol-2");
        let final_booster_slot_3_id = document.getElementById("booster-slot-symbol-3");

        // X2 FARM INCOME BOOSTER WIN

        if (final_booster_slot_1_id.src.includes("x2-income.svg") && final_booster_slot_2_id.src.includes("x2-income.svg") && final_booster_slot_3_id.src.includes("x2-income.svg")) {
            boosterSlotWinVisual("red", "X2 FARM INCOME");
            inventory_slot_1_player_owned_amount++;
        }

        // X3 FARM INCOME BOOSTER WIN

        if (final_booster_slot_1_id.src.includes("x3-income.svg") && final_booster_slot_2_id.src.includes("x3-income.svg") && final_booster_slot_3_id.src.includes("x3-income.svg")) {
            boosterSlotWinVisual("lime", "X3 FARM INCOME");
            inventory_slot_2_player_owned_amount++;
        }

        // X2 FARM SPEED BOOSTER WIN

        if (final_booster_slot_1_id.src.includes("x2-farm-speed.svg") && final_booster_slot_2_id.src.includes("x2-farm-speed.svg") && final_booster_slot_3_id.src.includes("x2-farm-speed.svg")) {
            boosterSlotWinVisual("lightblue", "X2 FARM SPEED");
            inventory_slot_3_player_owned_amount++;
        }

        // X5 FARM SPEED BOOSTER WIN

        if (final_booster_slot_1_id.src.includes("x5-farm-speed.svg") && final_booster_slot_2_id.src.includes("x5-farm-speed.svg") && final_booster_slot_3_id.src.includes("x5-farm-speed.svg")) {
            boosterSlotWinVisual("orange", "X5 FARM SPEED");
            inventory_slot_8_player_owned_amount++;
        }

        // +50% WILDS BOOSTER WIN

        if (final_booster_slot_1_id.src.includes("wild-50-percent.svg") && final_booster_slot_2_id.src.includes("wild-50-percent.svg") && final_booster_slot_3_id.src.includes("wild-50-percent.svg")) {
            boosterSlotWinVisual("purple", "+%50 WILDS");
            inventory_slot_4_player_owned_amount++;
        }

        // MYSTERY TOKEN WIN

        if (final_booster_slot_1_id.src.includes("mystery-booster.svg") && final_booster_slot_2_id.src.includes("mystery-booster.svg") && final_booster_slot_3_id.src.includes("mystery-booster.svg")) {
            boosterSlotWinVisual("rgb(163, 181, 46)", "MYSTERY TOKEN");
            inventory_slot_9_player_owned_amount++;
        }

        // JACKPOT 7'S WIN

        if (final_booster_slot_1_id.src.includes("triple-777-jackpot.svg") && final_booster_slot_2_id.src.includes("triple-777-jackpot.svg") && final_booster_slot_3_id.src.includes("triple-777-jackpot.svg")) {
            notificationDialog("JACKPOT WON > $" + triple_7_win, 3000);
            for (let i = 0; i < booster_reels_storage.length; i++) { booster_reels_storage[i].style.border = "5px solid springgreen"; }
            player_cash_balance += triple_7_win;
            total_triple_stars_won_counter++;
            bonusWinAudio();
        }

        // STAR WIN

        for (let i = 0; i < final_booster_slot_id_storage.length; i++) {
            if (final_booster_slot_id_storage[i].src.includes("star-symbol.svg")) {
                player_cash_balance += 50;

                smallDingAudio();
                notificationDialog("WIN > STAR > $" + formatMoneyValue(50), 3500);
                final_slot_id_storage[i].style.border = "5px solid springgreen";
            }
        }
    }, 4000)
}

spin_btn_3.onclick = function() { // SPIN VALIDATION
    if (player_booster_tokens > 0) {
        player_booster_tokens--;
        initiateBoosterSpin();
        disableSpinOpt();
        for (let i = 0; i < booster_reels_storage.length; i++) { 
            booster_reels_storage[i].style.border = "5px solid black";
        }
    } else {
        upgradePurchaseFailedAudio();
        notificationDialog("Insufficient Tokens!", 3000);
    }
}