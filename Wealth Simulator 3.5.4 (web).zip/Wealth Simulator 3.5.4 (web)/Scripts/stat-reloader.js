window.onload = function() {
    winline_highlighting_preference.dispatchEvent(new Event("change"));
    reel_border_shadow_preference.dispatchEvent(new Event("change"));
    reel_alternation_animation_preference.dispatchEvent(new Event("change"));
    farm_percent_progress_preference.dispatchEvent(new Event("change"));

    autoLoad();
    if (mod_1_installed) {
        loadDomViewer(function() {}, function() {
            notificationDialog("Could not load the installed DOM inspector.", 4000);
        });
    }
    updateStats();
    updateCustomLoanStats();
    initiateReelRotation();
    notificationDialog("<><><><><><><><><><><><><><><><><><><><><><><><><><><>", 3000);
    
    for (let i = 0; i < registered_loans_storage.length; i++) {
        if (registered_loans_storage[i]) {
            let loan = registered_loans_storage[i];
            let loanSlot = document.createElement("div");
            loanSlot.className = "loan-slot";
            loanSlot.innerHTML = "<span style='color: whitesmoke; font-weight: bold;'>Loan Amount </span> > <span style='color: lime;'>$" + formatMoneyValue(loan.loan_amount) + "</span><br><span style='color: whitesmoke; font-weight: bold;'>Interest Rate </span> > " + formatDisplayNumber(loan.loan_interest_rate * 100) + "%<br><span style='color: whitesmoke; font-weight: bold;'>Full Repayment Amount </span> > <span style='color: lime;'>$" + formatMoneyValue(loan.repayment_progress) + "</span><br><span style='color: whitesmoke; font-weight: bold;'>Loan Repayment Progress </span> > " + loan.repayment_progress + "<br><span style='color: whitesmoke; font-weight: bold;'>Installment </span> > $" + formatMoneyValue(loan.full_repayment / loan.installments) + "<br><span style='color: whitesmoke; font-weight: bold;'>Total Installments </span> > " + formatDisplayNumber(loan.installments) + "<br><span style='color: aquamarine; font-weight: bold;'>Status </span> > " + loan.status;
            document.getElementById("active-loans-panel").appendChild(loanSlot);

            loan.remaining_balance = Number.isFinite(Number(loan.remaining_balance))
                ? Number(loan.remaining_balance)
                : (String(loan.status).includes("REPAID") ? 0 : Number(loan.full_repayment));

            let registeredLoanSlot = document.createElement("section");
            registeredLoanSlot.className = "registered-loan-slot";
            registeredLoanSlot.style.cursor = "pointer";

            function updateRegisteredLoanSlot() {
                loan.status = loan.remaining_balance <= 0
                    ? "<span style='color: yellow;'>REPAID</span>"
                    : "<span style='color: #E86D72;'>UNPAID</span>";
                loan.repayment_progress = "$" + formatMoneyValue(loan.full_repayment - loan.remaining_balance) + " / <span style='color: lime'>$" + formatMoneyValue(loan.full_repayment) + "</span>";
                registeredLoanSlot.innerHTML = "LOAN ID > <span style='color: whitesmoke;'>" + loan.loan_id + "</span><br>LOAN AMOUNT > <span style='color: lime;'>$" + formatMoneyValue(loan.loan_amount) + "</span><br>FULL REPAYMENT > <span style='color: lime;'>$" + formatMoneyValue(loan.full_repayment) + "</span><br>INSTALLMENTS > " + formatDisplayNumber(loan.installments) + "<br>DECISION > <span style='color: aqua;'>APPROVED</span><br>STATUS > " + loan.status;
            }

            function updateActiveLoansPanel() {
                loanSlot.innerHTML = "<span style='color: whitesmoke; font-weight: bold;'>LOAN ID (#) </span> > <span style='color: yellow;'>" + loan.loan_id + "</span><br><span style='color: whitesmoke; font-weight: bold;'>Loan Amount </span> > <span style='color: lime;'>$" + formatMoneyValue(loan.loan_amount) + "</span><br><span style='color: whitesmoke; font-weight: bold;'>Interest Rate </span> > " + formatDisplayNumber(loan.loan_interest_rate * 100) + "%<br><span style='color: whitesmoke; font-weight: bold;'>Full Repayment Amount </span> > <span style='color: lime;'>$" + formatMoneyValue(loan.full_repayment) + "</span><br><span style='color: whitesmoke; font-weight: bold;'>Loan Repayment Progress </span> > " + loan.repayment_progress + "<br><span style='color: whitesmoke; font-weight: bold;'>Installment </span> > $" + formatMoneyValue(loan.full_repayment / loan.installments) + "<br><span style='color: whitesmoke; font-weight: bold;'>Total Installments </span> > " + formatDisplayNumber(loan.installments) + "<br><span style='color: aquamarine; font-weight: bold;'>Status </span> > " + loan.status;
            }

            updateRegisteredLoanSlot();
            updateActiveLoansPanel();
            
            registeredLoanSlot.addEventListener("click", () => {
                oscClickAudio();
                loan_manual_management_dialog_overlay.style.display = "flex";
                document.getElementById("loan-id-manager-output").innerHTML = "LOAN ID > <span style='color: yellow'>[" + loan.loan_id + "]</span><br>LOAN AMOUNT > <span style='color: lime;'>$" + formatMoneyValue(loan.loan_amount) + "</span><br>REMAINING DEBT > $" + formatMoneyValue(loan.remaining_balance);

                pay_custom_amount_opt.onclick = () => {
                    const customPayment = Number(custom_loan_payment_amount_inp.value);

                    if (!Number.isFinite(customPayment) || customPayment <= 0) {
                        notificationDialog("Invalid payment amount / Empty Field!", 3000);
                    } else if (customPayment > loan.remaining_balance) {
                        notificationDialog("Payment exceeds remaining debt!", 3000);
                    } else if (customPayment > player_cash_balance) {
                        notificationDialog("Insufficient Funds!", 3000);
                        upgradePurchaseFailedAudio();
                    } else {
                        player_cash_balance -= customPayment;
                        current_loan_debt = Math.max(0, current_loan_debt - customPayment);
                        loan.remaining_balance = Math.max(0, Number((loan.remaining_balance - customPayment).toFixed(2)));
                        if (loan.remaining_balance <= 0.01) {
                            loan.remaining_balance = 0;
                            stopRepaymentInterval(loan.loan_id);
                        }
                        updateRegisteredLoanSlot();
                        updateActiveLoansPanel();
                        updateStats();
                        document.getElementById("loan-id-manager-output").innerHTML = "LOAN ID > <span style='color: yellow'>[" + loan.loan_id + "]</span><br>LOAN AMOUNT > <span style='color: lime;'>$" + formatMoneyValue(loan.loan_amount) + "</span><br>REMAINING DEBT > $" + formatMoneyValue(loan.remaining_balance);
                        autoSave();
                        mysteryWinAudio();
                        notificationDialog("[PAYMENT SUCCESS] > $" + formatMoneyValue(customPayment) + " PAYMENT MADE!", 3000);
                    }
                };

                pay_full_payment_opt.disabled = false;
                pay_full_payment_opt.style.opacity = "1";
                pay_full_payment_opt.style.cursor = "pointer";
                pay_full_payment_opt.onclick = () => {
                    if (loan.remaining_balance <= 0.01) {
                        notificationDialog("[ERROR] > LOAN ALREADY REPAID!", 3000);
                        upgradePurchaseFailedAudio();
                    } else if (player_cash_balance >= loan.remaining_balance) {
                        const fullPayment = loan.remaining_balance;
                        player_cash_balance -= fullPayment;
                        current_loan_debt = Math.max(0, Number((current_loan_debt - fullPayment).toFixed(2)));
                        loan.remaining_balance = 0;
                        delete loan.next_repayment_at;

                        stopRepaymentInterval(loan.loan_id);
                        updateRegisteredLoanSlot();
                        updateActiveLoansPanel();
                        updateStats();
                        autoSave();
                        setTimeout(() => { loan_manual_management_dialog_overlay.style.display = "none"; }, 1000);
                        document.getElementById("loan-id-manager-output").innerHTML = "LOAN ID > <span style='color: yellow'>[" + loan.loan_id + "]</span><br>LOAN AMOUNT > <span style='color: lime;'>$" + formatMoneyValue(loan.loan_amount) + "</span><br>REMAINING DEBT > $" + formatMoneyValue(loan.remaining_balance);
                        upgradePurchasedAudio();
                        notificationDialog("[LOAN REPAID] > PAID IN FULL!", 3500);
                    } else {
                        notificationDialog("Insufficient Funds!", 3000);
                        upgradePurchaseFailedAudio();
                    }
                };
            });

            document.getElementById("registered-loans-list").appendChild(registeredLoanSlot);

            if (Number(loan.remaining_balance) > 0) {
                startRepaymentInterval(loan, () => {
                    updateRegisteredLoanSlot();
                    updateActiveLoansPanel();
                });
            }
        }
    }

    if (typeof initializeLoanOptions === "function") {
        initializeLoanOptions();
    }

    // MOD STATUSES

    if (mod_1_installed === true) { install_mod_1_opt.disabled = true; install_mod_1_opt.style.cursor = "not-allowed"; install_mod_1_opt.innerHTML = "<span style='color: lime;'>INSTALLED</span>"; }
    if (mod_2_installed === true) { install_mod_2_opt.disabled = true; install_mod_2_opt.style.cursor = "not-allowed"; install_mod_2_opt.innerHTML = "<span style='color: lime;'>INSTALLED</span>"; }
    if (mod_3_installed === true) { install_mod_3_opt.disabled = true; install_mod_3_opt.style.cursor = "not-allowed"; install_mod_3_opt.innerHTML = "<span style='color: lime;'>INSTALLED</span>"; }

    let loading_progress_int = setInterval(() => {
        document.getElementById("loading-progress-bar").value += Math.floor(Math.random() * 50) + 5; // Increment by a random value between 5 and 14

        document.getElementById("loading-output-txt").innerHTML = "Loading... " + document.getElementById("loading-progress-bar").value + "%";

        if (document.getElementById("loading-progress-bar").value === 100) {
            setTimeout(() => { document.getElementById("loading-progress-bar").value = 0; }, 1000)
            setTimeout(() => {
                document.getElementById("main-loading-screen-dialog-overlay").style.display = "none";
                document.getElementById("main-cont-ui").style.display = "flex";
            }, 500)
            clearInterval(loading_progress_int);
        }
    }, Math.floor(Math.random() * 500) + 200)

    document.getElementById("progress-dialog-overlay").style.display = "none";
    
    for (let i = 0; i < purchase_dialog_overlays_storage.length; i++) {
        if (purchase_dialog_overlays_storage[i]) {
            purchase_dialog_overlays_storage[i].style.display = "none";
        }
    }

    if (!total_passive_income_pool > 0) {
        restartPassiveIncomeInterval();
    }

    if (quick_collect_perk_owned) {
        quick_collect_btn.style.opacity = "1";
        quick_collect_btn.style.cursor = "pointer";
        quick_collect_btn.disabled = false;
        document.getElementById("store-slot-9-upgrade-btn").style.opacity = "0.5";
        document.getElementById("store-slot-9-upgrade-btn").style.cursor = "not-allowed";
        document.getElementById("store-slot-9-upgrade-btn").disabled = true;

        document.getElementById("buff-12-ownership-output").innerHTML = "<span style='color: lime'>ACTIVE</span>";
        document.getElementById("buff-12-ownership-output").style.borderRight = "5px solid lime";
    }

    document.getElementById("tier-1-table").innerHTML = "<span style='display: inline-flex; align-items: center; white-space: nowrap; color: rgb(10, 111, 183);'><img src='Images/Cash-balance-icon.png' width='50px' height='50px' style='flex-shrink: 0; margin-right: 10px;' />Tier 1 Fund Farms ---</span><span style='color: aquamarine; margin-left: 10px;'>OWNED</span>|" + "<span style='color: lime;'>ACTIVE</span>";
    if (tier_2_farm_unlocked) { document.getElementById("tier-2-table").innerHTML = "<span style='display: inline-flex; align-items: center; white-space: nowrap; color: rgb(10, 111, 183);'><img src='Images/Cash-balance-icon.png' width='50px' height='50px' style='flex-shrink: 0; margin-right: 10px;' />Tier 2 Fund Farms ---</span><span style='color: aquamarine; margin-left: 10px;'>OWNED</span>|" + "<span style='color: lime;'>ACTIVE</span>"; }
    if (tier_3_farm_unlocked) { document.getElementById("tier-3-table").innerHTML = "<span style='display: inline-flex; align-items: center; white-space: nowrap; color: rgb(190, 126, 5);'><img src='Images/Tycoon-score-balance-icon.png' width='50px' height='50px' style='flex-shrink: 0; margin-right: 10px;' />Tier 3 Coin Farms ---</span><span style='color: aquamarine; margin-left: 10px;'>OWNED</span>|" + "<span style='color: lime;'>ACTIVE</span>"; }



    if (farm_1_auto_state) {
        farm_1_auto_opt.innerHTML = "<h3 style='color: lime'>ACTIVE</h3>";
        farm_1_auto_opt.disabled = true;
        farm_1_auto_opt.style.opacity = "0.5";
        farm_1_auto_opt.style.cursor = "not-allowed";
        farm_1_progress_int = collectFundFarm(farm_1_cash_amount, 1000, farm_1_collect_opt, farm_1_progress_bar, farm_1_progress_int, 0);
        if (!farm_1_auto_int) {
            farm_1_auto_int = setInterval(() => { farm_1_collect_opt.click(); }, 500);
        }
    }
    if (farm_2_auto_state) {
        farm_2_auto_opt.innerHTML = "<h3 style='color: lime'>ACTIVE</h3>";
        farm_2_auto_opt.disabled = true;
        farm_2_auto_opt.style.opacity = "0.5";
        farm_2_auto_opt.style.cursor = "not-allowed";
        farm_2_progress_int = collectFundFarm(farm_2_cash_amount, 1000, farm_2_collect_opt, farm_2_progress_bar, farm_2_progress_int, 0);
        if (!farm_2_auto_int) {
            farm_2_auto_int = setInterval(() => { farm_2_collect_opt.click(); }, 500);
        }
    }
    if (farm_3_auto_state) {
        farm_3_auto_opt.innerHTML = "<h3 style='color: lime'>ACTIVE</h3>";
        farm_3_auto_opt.disabled = true;
        farm_3_auto_opt.style.opacity = "0.5";
        farm_3_auto_opt.style.cursor = "not-allowed";
        farm_3_progress_int = collectFundFarm(farm_3_cash_amount, 1000, farm_3_collect_opt, farm_3_progress_bar, farm_3_progress_int, 0);
        if (!farm_3_auto_int) {
            farm_3_auto_int = setInterval(() => { farm_3_collect_opt.click(); }, 500);
        }
    }
    if (farm_4_auto_state) {
        farm_4_auto_opt.innerHTML = "<h3 style='color: lime'>ACTIVE</h3>";
        farm_4_auto_opt.disabled = true;
        farm_4_auto_opt.style.opacity = "0.5";
        farm_4_auto_opt.style.cursor = "not-allowed";
        farm_4_progress_int = collectFundFarm(farm_4_cash_amount, 1000, farm_4_collect_opt, farm_4_progress_bar, farm_4_progress_int, 0);
        if (!farm_4_auto_int) {
            farm_4_auto_int = setInterval(() => { farm_4_collect_opt.click(); }, 500);
        }
    }
    if (farm_5_auto_state) {
        farm_5_auto_opt.innerHTML = "<h3 style='color: lime'>ACTIVE</h3>";
        farm_5_auto_opt.disabled = true;
        farm_5_auto_opt.style.opacity = "0.5";
        farm_5_auto_opt.style.cursor = "not-allowed";
        farm_5_progress_int = collectFundFarm(farm_5_cash_amount, 1000, farm_5_collect_opt, farm_5_progress_bar, farm_5_progress_int, 0);
        if (!farm_5_auto_int) {
            farm_5_auto_int = setInterval(() => { farm_5_collect_opt.click(); }, 500);
        }
    }
    if (farm_6_auto_state) {
        farm_6_auto_opt.innerHTML = "<h3 style='color: lime'>ACTIVE</h3>";
        farm_6_auto_opt.disabled = true;
        farm_6_auto_opt.style.opacity = "0.5";
        farm_6_auto_opt.style.cursor = "not-allowed";
        farm_6_progress_int = collectFundFarm(farm_6_cash_amount, 1000, farm_6_collect_opt, farm_6_progress_bar, farm_6_progress_int, 0);
        if (!farm_6_auto_int) {
            farm_6_auto_int = setInterval(() => { farm_6_collect_opt.click(); }, 500);
        }
    }

    if (tier_2_farm_1_auto_state) {
        tier_2_farm_1_auto_opt.innerHTML = "<h3 style='color: lime'>ACTIVE</h3>";
        tier_2_farm_1_auto_opt.disabled = true;
        tier_2_farm_1_auto_opt.style.opacity = "0.5";
        tier_2_farm_1_auto_opt.style.cursor = "not-allowed";
        tier_2_farm_1_progress_int = collectFundFarm(tier_2_farm_1_cash_amount, 1000, tier_2_farm_1_collect_opt, tier_2_farm_1_progress_bar, tier_2_farm_1_progress_int, 0);
        if (!tier_2_farm_1_auto_int) {
            tier_2_farm_1_auto_int = setInterval(() => { tier_2_farm_1_collect_opt.click(); }, 500);
        }
    }
    if (tier_2_farm_2_auto_state) {
        tier_2_farm_2_auto_opt.innerHTML = "<h3 style='color: lime'>ACTIVE</h3>";
        tier_2_farm_2_auto_opt.disabled = true;
        tier_2_farm_2_auto_opt.style.opacity = "0.5";
        tier_2_farm_2_auto_opt.style.cursor = "not-allowed";
        tier_2_farm_2_progress_int = collectFundFarm(tier_2_farm_2_cash_amount, 1000, tier_2_farm_2_collect_opt, tier_2_farm_2_progress_bar, tier_2_farm_2_progress_int, 0);
        if (!tier_2_farm_2_auto_int) {
            tier_2_farm_2_auto_int = setInterval(() => { tier_2_farm_2_collect_opt.click(); }, 500);
        }
    }
    if (tier_2_farm_3_auto_state) {
        tier_2_farm_3_auto_opt.innerHTML = "<h3 style='color: lime'>ACTIVE</h3>";
        tier_2_farm_3_auto_opt.disabled = true;
        tier_2_farm_3_auto_opt.style.opacity = "0.5";
        tier_2_farm_3_auto_opt.style.cursor = "not-allowed";
        tier_2_farm_3_progress_int = collectFundFarm(tier_2_farm_3_cash_amount, 1000, tier_2_farm_3_collect_opt, tier_2_farm_3_progress_bar, tier_2_farm_3_progress_int, 0);
        if (!tier_2_farm_3_auto_int) {
            tier_2_farm_3_auto_int = setInterval(() => { tier_2_farm_3_collect_opt.click(); }, 500);
        }
    }
    if (tier_2_farm_4_auto_state) {
        tier_2_farm_4_auto_opt.innerHTML = "<h3 style='color: lime'>ACTIVE</h3>";
        tier_2_farm_4_auto_opt.disabled = true;
        tier_2_farm_4_auto_opt.style.opacity = "0.5";
        tier_2_farm_4_auto_opt.style.cursor = "not-allowed";
        tier_2_farm_4_progress_int = collectFundFarm(tier_2_farm_4_cash_amount, 1000, tier_2_farm_4_collect_opt, tier_2_farm_4_progress_bar, tier_2_farm_4_progress_int, 0);
        if (!tier_2_farm_4_auto_int) {
            tier_2_farm_4_auto_int = setInterval(() => { tier_2_farm_4_collect_opt.click(); }, 500);
        }
    }
    if (tier_2_farm_5_auto_state) {
        tier_2_farm_5_auto_opt.innerHTML = "<h3 style='color: lime'>ACTIVE</h3>";
        tier_2_farm_5_auto_opt.disabled = true;
        tier_2_farm_5_auto_opt.style.opacity = "0.5";
        tier_2_farm_5_auto_opt.style.cursor = "not-allowed";
        tier_2_farm_5_progress_int = collectFundFarm(tier_2_farm_5_cash_amount, 1000, tier_2_farm_5_collect_opt, tier_2_farm_5_progress_bar, tier_2_farm_5_progress_int, 0);
        if (!tier_2_farm_5_auto_int) {
            tier_2_farm_5_auto_int = setInterval(() => { tier_2_farm_5_collect_opt.click(); }, 500);
        }
    }
    if (tier_2_farm_6_auto_state) {
        tier_2_farm_6_auto_opt.innerHTML = "<h3 style='color: lime'>ACTIVE</h3>";
        tier_2_farm_6_auto_opt.disabled = true;
        tier_2_farm_6_auto_opt.style.opacity = "0.5";
        tier_2_farm_6_auto_opt.style.cursor = "not-allowed";
        tier_2_farm_6_progress_int = collectFundFarm(tier_2_farm_6_cash_amount, 1000, tier_2_farm_6_collect_opt, tier_2_farm_6_progress_bar, tier_2_farm_6_progress_int, 0);
        if (!tier_2_farm_6_auto_int) {
            tier_2_farm_6_auto_int = setInterval(() => { tier_2_farm_6_collect_opt.click(); }, 500);
        }
    }

    if (tier_3_farm_1_auto_state) {
        tier_3_farm_1_auto_opt.innerHTML = "<h3 style='color: lime'>ACTIVE</h3>";
        tier_3_farm_1_auto_opt.disabled = true;
        tier_3_farm_1_auto_opt.style.opacity = "0.5";
        tier_3_farm_1_auto_opt.style.cursor = "not-allowed";
        tier_3_farm_1_progress_int = collectFundFarm(tier_3_farm_1_cash_amount, 1000, tier_3_farm_1_collect_opt, tier_3_farm_1_progress_bar, tier_3_farm_1_progress_int, 0);
        if (!tier_3_farm_1_auto_int) {
            tier_3_farm_1_auto_int = setInterval(() => { tier_3_farm_1_collect_opt.click(); }, 500);
        }
    }
    if (tier_3_farm_2_auto_state) {
        tier_3_farm_2_auto_opt.innerHTML = "<h3 style='color: lime'>ACTIVE</h3>";
        tier_3_farm_2_auto_opt.disabled = true;
        tier_3_farm_2_auto_opt.style.opacity = "0.5";
        tier_3_farm_2_auto_opt.style.cursor = "not-allowed";
        tier_3_farm_2_progress_int = collectFundFarm(tier_3_farm_2_cash_amount, 1000, tier_3_farm_2_collect_opt, tier_3_farm_2_progress_bar, tier_3_farm_2_progress_int, 0);
        if (!tier_3_farm_2_auto_int) {
            tier_3_farm_2_auto_int = setInterval(() => { tier_3_farm_2_collect_opt.click(); }, 500);
        }
    }
    if (tier_3_farm_3_auto_state) {
        tier_3_farm_3_auto_opt.innerHTML = "<h3 style='color: lime'>ACTIVE</h3>";
        tier_3_farm_3_auto_opt.disabled = true;
        tier_3_farm_3_auto_opt.style.opacity = "0.5";
        tier_3_farm_3_auto_opt.style.cursor = "not-allowed";
        tier_3_farm_3_progress_int = collectFundFarm(tier_3_farm_3_cash_amount, 1000, tier_3_farm_3_collect_opt, tier_3_farm_3_progress_bar, tier_3_farm_3_progress_int, 0);
        if (!tier_3_farm_3_auto_int) {
            tier_3_farm_3_auto_int = setInterval(() => { tier_3_farm_3_collect_opt.click(); }, 500);
        }
    }
    if (tier_3_farm_4_auto_state) {
        tier_3_farm_4_auto_opt.innerHTML = "<h3 style='color: lime'>ACTIVE</h3>";
        tier_3_farm_4_auto_opt.disabled = true;
        tier_3_farm_4_auto_opt.style.opacity = "0.5";
        tier_3_farm_4_auto_opt.style.cursor = "not-allowed";
        tier_3_farm_4_progress_int = collectFundFarm(tier_3_farm_4_cash_amount, 1000, tier_3_farm_4_collect_opt, tier_3_farm_4_progress_bar, tier_3_farm_4_progress_int, 0);
        if (!tier_3_farm_4_auto_int) {
            tier_3_farm_4_auto_int = setInterval(() => { tier_3_farm_4_collect_opt.click(); }, 500);
        }
    }
    if (tier_3_farm_5_auto_state) {
        tier_3_farm_5_auto_opt.innerHTML = "<h3 style='color: lime'>ACTIVE</h3>";
        tier_3_farm_5_auto_opt.disabled = true;
        tier_3_farm_5_auto_opt.style.opacity = "0.5";
        tier_3_farm_5_auto_opt.style.cursor = "not-allowed";
        tier_3_farm_5_progress_int = collectFundFarm(tier_3_farm_5_cash_amount, 1000, tier_3_farm_5_collect_opt, tier_3_farm_5_progress_bar, tier_3_farm_5_progress_int, 0);
        if (!tier_3_farm_5_auto_int) {
            tier_3_farm_5_auto_int = setInterval(() => { tier_3_farm_5_collect_opt.click(); }, 500);
        }
    }
    if (tier_3_farm_6_auto_state) {
        tier_3_farm_6_auto_opt.innerHTML = "<h3 style='color: lime'>ACTIVE</h3>";
        tier_3_farm_6_auto_opt.disabled = true;
        tier_3_farm_6_auto_opt.style.opacity = "0.5";
        tier_3_farm_6_auto_opt.style.cursor = "not-allowed";
        tier_3_farm_6_progress_int = collectFundFarm(tier_3_farm_6_cash_amount, 1000, tier_3_farm_6_collect_opt, tier_3_farm_6_progress_bar, tier_3_farm_6_progress_int, 0);
        if (!tier_3_farm_6_auto_int) {
            tier_3_farm_6_auto_int = setInterval(() => { tier_3_farm_6_collect_opt.click(); }, 500);
        }
    }
    
}

window.onbeforeunload = function() {
    const unloadTime = Date.now();
    total_playtime += unloadTime - current_timestamp;
    current_timestamp = unloadTime;
    autoSave();
}

function getSafeProgressPercent(progressValue, progressBar) {
    const max = Number(progressBar?.max) || 100;
    if (!Number.isFinite(max) || max <= 0) return 0;

    const barValue = Number(progressBar?.value);
    const currentValue = Number.isFinite(Number(progressValue)) && Number(progressValue) >= 0 ? Number(progressValue) : barValue;
    const current = Number.isFinite(currentValue) ? currentValue : 0;

    return Math.min(100, Math.max(0, Math.round((current / max) * 100)));
}

function updateStats() {
    random_confirmation_number_output.textContent = random_confirmation_number;
    document.getElementById("mystery-booster-amount-output-2").innerHTML = "<span style='color: yellow;'><img src='Images/mystery-booster.svg' width='30px' height='30px' style='margin-right: 10px; font-size: 30px; font-weight: bold; font-family: monospace, Verdana, Geneva, Tahoma, sans-serif; color: orange; vertical-align: middle;'>AVAILABLE TOKENS >> </span>" + formatDisplayNumber(inventory_slot_9_player_owned_amount);

    document.getElementById("auto-spin-countdown-output").innerHTML = "Auto-Spins >> " + "<span style='color: yellow;'>" + custom_auto_spin_count_limit + "<span style='color: snow;'>/</span>" + custom_auto_spin_count + "</span>";
    document.getElementById("auto-spin-count-output").innerHTML = "Auto-Spins > " + formatDisplayNumber(custom_auto_spin_count);
    current_bet_output.innerHTML = "Current Bet : <span style='color: yellow'>$" + bet.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</span>";
    bet_based_cash_win_output.innerHTML = "Cash Win : $" + bet_based_cash_win_2.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    document.getElementById("current-bet-output-2").innerHTML = "Current Bet : <span style='color: yellow'>$" + bet_2.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</span>";
    bet_based_cash_win_output_2.innerHTML = "Cash Win : $" + bet_based_cash_win_2.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    document.getElementById("player-lvl-output").innerHTML = "<h4 style='color: lime;'>" + formatDisplayNumber(player_lvl) + "</h4>";
    document.getElementById("next-lvl-req-output").innerHTML = "<h4 style='color: snow; margin-right: 1px'>" + formatDisplayNumber(player_lvl_progress_bar_value.value) + "<h4 style='color: lime; margin-right: 4px; margin-left: 4px;'> / </h4>" + formatDisplayNumber(next_lvl_req) + "<h4 style='color: yellow; margin-left: 2px;'>XP</h4></h4>";
    document.getElementById("stats-tab-current-bet-output").innerHTML = "Bet / Stake > <span style='color: springgreen'>$" + bet.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</span>";
    document.getElementById("stats-tab-current-bet-output-2").innerHTML = "Bet / Stake > <span style='color: springgreen'>$" + bet_2.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</span>";
    document.getElementById("wild-bonus-free-spins-output").innerHTML = "<span style='color: #ff00e6'>Wild Spins</span> > <span style='color: yellow'>" + formatDisplayNumber(wild_bonus_free_spins) + "/10</span>";
    document.getElementById("free-spins-bonus-spins-output").innerHTML = "<span style='color: #00ff2f'>Free Spins</span> > <span style='color: yellow'>" + formatDisplayNumber(free_spins_bonus_spins) + "/" + formatDisplayNumber(free_spins_granted);
    document.getElementById("free-spins-awarded-output").innerHTML = "<span style='color: #e5ff00'>" + formatDisplayNumber(free_spins_granted) + " FREE SPINS AWARDED</span>";

    // MATCH BOARDS

    document.getElementById("board-slot-revelation-price-output").innerHTML = "<span style='color: aquamarine; margin-right: 5px;'>SLOT REVELATION PRICE</span><span style='color: snow;'> >> </span><span style='color: yellow;'>$" + formatMoneyValue(price) + "</span>";

    // MAIN BALANCES

    document.getElementById("booster-spinner-tokens-output").innerHTML = "BOOSTER TOKENS >> " + formatDisplayNumber(player_booster_tokens);
    document.getElementById("cash-balance-output").innerHTML = "$" + formatMoneyValue(player_cash_balance);
    document.getElementById("coins-balance-output").innerHTML = formatDisplayNumber(player_coins_balance);
    document.getElementById("diamonds-balance-output").innerHTML = formatDisplayNumber(player_diamond_balance);
    savings_balance_output.innerHTML = "<span style='color: yellow'>$" + formatMoneyValue(player_savings_balance) + "</span>";

    // passive income stats

    document.getElementById("current-passive-income-pool-output").innerHTML = "<span style='color: whitesmoke;'>YOUR PASSIVE INCOME POOL > </span> $" + formatMoneyValue(total_passive_income_pool) + " / <span style='color: yellow;'>" + passive_income_grant_int / 1000 + "s</span>";
    document.getElementById("passive-income-pool-output").innerHTML = "<span style='color: rgb(0, 255, 229);'>$" + formatMoneyValue(total_passive_income_pool) + "</span><span style='color: snow; margin-right: 5px; margin-left: 5px;'>/</span><span style='color: yellow;'>" + passive_income_grant_int / 1000 + "s</span>";
    document.getElementById("passive-income-int-timer-output").innerHTML = " <span style='color: aquamarine; font-weight: bold; font-family: monospace, sans-serif; margin-right: 6px;'>" + "GRANT TIMER >> 00:" + passive_income_grant_int / 1000 + "s</span>" + "<span style='color: springgreen;'>" + "(-3s)</span>";
    document.getElementById("passive-income-int-reduction-price-output").innerHTML = "<span style='color: lime'><span style='color: yellow;'>PRICE >></span> $" + formatMoneyValue(store_slot_1_passive_income_cashout_int_reduction_price) + " </span>" + " <img src='Images/Cash-balance-icon.png' style='margin-left: 5px;' width='25px' height='25px' />";

    // store stats

    document.getElementById("tier-2-farm-price-output").innerHTML = "<span style='color: lime'><span style='color: yellow;'>PRICE >> " + formatDisplayNumber(store_slot_3_tier_2_farm_price) + " </span></span>" + " <img src='Images/Tycoon-score-balance-icon.png' style='margin-left: 5px;' width='25px' height='25px' />";
    document.getElementById("tier-3-farm-price-output").innerHTML = "<span style='color: lime'><span style='color: yellow;'>PRICE >> " + formatDisplayNumber(store_slot_5_tier_3_farm_price) + " </span></span>" + " <img src='Images/Diamond-icon.png' style='margin-left: 6px;' width='25px' height='px' />";
    document.getElementById("passive-income-cashout-int-reduction-percent-output").innerHTML = "<span style='color: lime'>" + formatDisplayNumber(store_slot_1_passive_income_cashout_int_reduction_percent * 100) + "% </span>";
    document.getElementById("passive-income-cashout-int-reduction-seconds-output").innerHTML = "<span style='color: lime'>(-" + formatDisplayNumber(store_slot_1_passive_income_cashout_int_reduction / 1000) + "s)</span>";
    document.getElementById("double-income-booster-price-output").innerHTML = "<span style='color: yellow'>PRICE >> " + "<span style='color: yellow'>" + formatDisplayNumber(store_slot_2_upgrade_price) + " COINS</span>" + "</span>" + " <img src='Images/Tycoon-score-balance-icon.png' style='margin-left: 5px;' width='25px' height='25px' />";
    document.getElementById("triple-income-booster-price-output").innerHTML = "<span style='color: yellow'>PRICE >> " + "<span style='color: yellow'>" + formatDisplayNumber(store_slot_4_upgrade_price) + " COINS</span>" + "</span>" + " <img src='Images/Tycoon-score-balance-icon.png' style='margin-left: 5px;' width='25px' height='25px' />";
    document.getElementById("double-farm-speed-booster-price-output").innerHTML = "<span style='color: yellow'>PRICE >> " + "<span style='color: yellow'>" + formatDisplayNumber(store_slot_6_upgrade_price) + " COINS</span>" + "</span>" + " <img src='Images/Tycoon-score-balance-icon.png' style='margin-left: 5px;' width='25px' height='25px' />";
    document.getElementById("x5-farm-speed-booster-price-output").innerHTML = "<span style='color: yellow'>PRICE >> " + "<span style='color: yellow'>" + formatDisplayNumber(store_slot_7_upgrade_price) + " COINS</span>" + "</span>" + " <img src='Images/Tycoon-score-balance-icon.png' style='margin-left: 5px;' width='25px' height='25px' />";;
    document.getElementById("50-percent-extra-wilds-booster-price-output").innerHTML = "<span style='color: yellow'>PRICE >> " + "<span style='color: aqua'>X" + formatDisplayNumber(store_slot_8_upgrade_price) + " DIAMOND</span>" + "</span>" + " <img src='Images/Diamond-icon.png' style='margin-left: 5px;' width='20px' height='18px' />";
    document.getElementById("quick-collect-perk-price-output").innerHTML = "<span style='color: yellow'>PRICE >> " + "<span style='color: aqua'>X" + formatDisplayNumber(store_slot_9_upgrade_price) + " DIAMONDS</span>" + "</span>" + " <img src='Images/Diamond-icon.png' style='margin-left: 5px;' width='15px' height='15px' />";
    document.getElementById("free-spins-bonus-price-output").innerHTML = "<span style='color: yellow; font-size: 18px;'>PRICE >> " + "<span style='color: aqua'>X" + formatDisplayNumber(store_slot_13_upgrade_price) + " DIAMONDS</span>" + "</span>" + " <img src='Images/Diamond-icon.png' width='18px' height='18px' style='margin-left: 5px;' />";
    document.getElementById("wild-free-spins-bonus-price-output").innerHTML = "<span style='color: yellow; font-size: 18px;'>PRICE >> " + "<span style='color: aqua'>X" + formatDisplayNumber(store_slot_14_upgrade_price) + " DIAMONDS</span>" + "</span>" + " <img src='Images/Diamond-icon.png' width='20px' height='18px' style='margin-left: 5px;' />";
    document.getElementById("streak-saver-booster-price-output").innerHTML = "<span style='color: yellow; font-size: 18px;'>PRICE >> " + "<span style='color: springgreen'>$" + formatMoneyValue(store_slot_15_upgrade_price) + "</span>" + "</span>" + " <img src='Images/Cash-balance-icon.png' width='30px' height='30px' style='margin-left: 5px;' />";
    document.getElementById("trivia-last-life-booster-price-output").innerHTML = "<span style='color: yellow; font-size: 18px;'>PRICE >> " + "<span style='color: springgreen'>$" + formatMoneyValue(store_slot_16_upgrade_price) + "</span>" + "</span>" + " <img src='Images/Cash-balance-icon.png' width='30px' height='30px' style='margin-left: 5px;' />";
    document.getElementById("free-spree-booster-price-output").innerHTML = "<span style='color: yellow; font-size: 18px;'>PRICE >> " + "<span style='color: aquamarine'>X" + formatDisplayNumber(store_slot_17_upgrade_price) + "</span>" + "</span>" + " <img src='Images/Diamond-icon.png' width='20px' height='18px' style='margin-left: 5px;' />";

    // INVENTORY

    document.getElementById("inventory-slot-1-double-income-amount-output").innerHTML = "<span style='color: yellow'> OWNED >> </span>" + formatDisplayNumber(inventory_slot_1_player_owned_amount); 
    document.getElementById("inventory-slot-2-triple-income-amount-output").innerHTML = "<span style='color: yellow'> OWNED >> </span>" + formatDisplayNumber(inventory_slot_2_player_owned_amount); 
    document.getElementById("inventory-slot-3-double-farm-speed-output").innerHTML = "<span style='color: yellow'> OWNED >> </span>" + formatDisplayNumber(inventory_slot_3_player_owned_amount);
    document.getElementById("inventory-slot-8-poly-farm-speed-output").innerHTML = "<span style='color: yellow'> OWNED >> </span>" + formatDisplayNumber(inventory_slot_8_player_owned_amount);
    document.getElementById("inventory-slot-4-double-extra-wilds-output").innerHTML = "<span style='color: yellow'> OWNED >> </span>" + formatDisplayNumber(inventory_slot_4_player_owned_amount);
    document.getElementById("inventory-slot-5-wild-bonus-output").innerHTML = "<span style='color: yellow'> OWNED >> </span>" + formatDisplayNumber(inventory_slot_5_player_owned_amount); 
    document.getElementById("inventory-slot-6-instant-xp-output").innerHTML = "<span style='color: yellow'> OWNED >> </span>" + formatDisplayNumber(inventory_slot_6_player_owned_amount); 
    document.getElementById("inventory-slot-7-double-lvl-xp-output").innerHTML = "<span style='color: yellow'> OWNED >> </span>" + formatDisplayNumber(inventory_slot_7_player_owned_amount); 
    document.getElementById("inventory-slot-9-mystery-booster-output").innerHTML = "<span style='color: yellow'> OWNED >> </span>" + formatDisplayNumber(inventory_slot_9_player_owned_amount); 
    document.getElementById("inventory-slot-11-trivia-last-life-booster-output").innerHTML = "<span style='color: yellow'> OWNED >> </span>" + formatDisplayNumber(inventory_slot_11_player_owned_amount); 
    document.getElementById("inventory-slot-12-game-changer-booster-output").innerHTML = "<span style='color: yellow'> OWNED >> </span>" + formatDisplayNumber(inventory_slot_12_player_owned_amount); 
    document.getElementById("inventory-slot-13-free-spree-output").innerHTML = "<span style='color: yellow'> OWNED >> </span>" + formatDisplayNumber(inventory_slot_13_player_owned_amount); 

    document.getElementById("inventory-slot-10-free-spins-bonus-output").innerHTML = "<span style='color: yellow'> OWNED >> </span>" + formatDisplayNumber(inventory_slot_10_player_owned_amount); 
    document.getElementById("inventory-slot-1-booster-duration-output").innerHTML = "<span style='color: aqua'> DURATION >> </span>" + inventory_slot_1_booster_duration_int / 1000 + "s"; 
    document.getElementById("inventory-slot-2-booster-duration-output").innerHTML = "<span style='color: aqua'> DURATION >> </span>" + inventory_slot_2_booster_duration_int / 1000 + "s"; 
    document.getElementById("inventory-slot-3-booster-duration-output").innerHTML = "<span style='color: aqua'> DURATION >> </span>" + inventory_slot_3_booster_duration_int / 1000 + "s"; 
    document.getElementById("inventory-slot-4-booster-duration-output").innerHTML = "<span style='color: aqua'> DURATION >> </span>" + inventory_slot_4_booster_duration_int / 1000 + "s"; 
    document.getElementById("inventory-slot-5-booster-duration-output").innerHTML = "<span style='color: aqua'>INSTANT</span>";
    document.getElementById("inventory-slot-6-booster-duration-output").innerHTML = "<span style='color: aqua'>INSTANT</span>";
    document.getElementById("inventory-slot-7-booster-duration-output").innerHTML = "<span style='color: aqua'> DURATION >> </span>" + inventory_slot_7_booster_duration_int / 60000 + "m"; 
    document.getElementById("inventory-slot-9-booster-duration-output").innerHTML = "<span style='color: aqua'>INSTANT</span>";
    document.getElementById("inventory-slot-10-booster-duration-output").innerHTML = "<span style='color: aqua'>INSTANT</span>";
    document.getElementById("inventory-slot-11-booster-duration-output").innerHTML = "<span style='color: aqua'>INSTANT</span>";
    document.getElementById("inventory-slot-12-booster-duration-output").innerHTML = "<span style='color: aqua'>INSTANT</span>";
    document.getElementById("inventory-slot-13-booster-duration-output").innerHTML = "<span style='color: aqua'> DURATION >> </span>" + inventory_slot_13_booster_duration_int / 1000 + "s";
    document.getElementById("inventory-slot-8-booster-duration-output").innerHTML = "<span style='color: aqua'> DURATION >> </span>" + inventory_slot_8_booster_duration_int / 1000 + "s"; 

    // BANK STATS

    document.getElementById("cash-to-coin-rate-output").innerHTML = "<span style='color: springgreen'>Cash</span> > <span style='color: springgreen'>$" + Number(cash_to_coin_slider.value).toFixed(2) + "</span> / <span style='color: yellow'>Coins</span> > <span style='color: yellow'>" + cash_to_coin_slider.value / cash_to_coin_grant_rate + "</span>";
    document.getElementById("cash-to-diamond-rate-output").innerHTML = "<span style='color: springgreen'>Cash</span> > <span style='color: springgreen'>$" + Number(cash_to_diamond_slider.value).toFixed(2) + "</span> / <span style='color: aqua'>Diamonds</span> > <span style='color: aqua'>" + cash_to_diamond_slider.value / cash_to_diamond_grant_rate + "</span>";
    document.getElementById("diamond-to-cash-rate-output").innerHTML = "<span style='color: aqua'>Diamonds</span> > <span style='color: aqua'>" + diamond_to_cash_slider.value + "</span> / <span style='color: springgreen'>Cash</span> > <span style='color: springgreen'>$" + (diamond_to_cash_slider.value * cash_to_diamond_grant_rate).toFixed(2) + "</span>";
    
    // LOANS STATS

    let per_repayment_amount = loan_repayment_count > 0 ? loan_repayment_amount / loan_repayment_count : loan_repayment_amount;

    document.getElementById("current-loan-debt-output").innerHTML = "<span style='color: #E86D72'>Current Loan Debt > </span><span style='color: #E86D72'>$" + formatMoneyValue(current_loan_debt) + "</span>";
    document.getElementById("current-loan-debt-limit-output").innerHTML = "<span style='color: #ffffff'>Current Loan Debt Litmit > </span><span style='color: lime'>$" + formatMoneyValue(current_loan_debt) + " <span style='color: snow;'>/</span> <span style='color: #ff020a;'>$" + formatMoneyValue(current_loan_debt_limit) + "</span></span>";
    document.getElementById("tycoon-score-output").innerHTML = "<span style='color: yellow'>Tycoon Credit > </span><span style='color: lime'>" + formatDisplayNumber(player_tycoon_score) + "</span>";
    document.getElementById("loan-repayment-eta-timer-output").innerHTML = "<span style='color: aquamarine'>Fixed Repayment Interval > 5 MINUTES</span>";

    // TASK STATS

    document.getElementById("tasks-completed-output").innerHTML = "Tasks Completed > " + formatDisplayNumber(total_tasks_completed) + "/" + formatDisplayNumber(current_tasks_pool);

    if (task_1_active || task_1_completion_status) { document.getElementById("task-1-percent-progress-output").innerHTML = getSafeProgressPercent(task_1_progress, task_1_progress_bar) + "%" + " > <span style='color: lime;'>$" + formatMoneyValue(task_1_progress) + "</span>"; }
    if (task_2_active || task_2_completion_status) { document.getElementById("task-2-percent-progress-output").innerHTML = getSafeProgressPercent(task_2_progress, task_2_progress_bar) + "%" + " > <span style='color: lime;'>$" + formatMoneyValue(task_2_progress) + "</span>"; }
    if (task_3_active || task_3_completion_status) { document.getElementById("task-3-percent-progress-output").innerHTML = getSafeProgressPercent(task_3_progress, task_3_progress_bar) + "%" + " > <span style='color: lime;'>$" + formatMoneyValue(task_3_progress) + "</span>"; }
    if (task_4_active || task_4_completion_status) { document.getElementById("task-4-percent-progress-output").innerHTML = getSafeProgressPercent(task_4_progress, task_4_progress_bar) + "%"; }
    if (task_5_active || task_5_completion_status) { document.getElementById("task-5-percent-progress-output").innerHTML = getSafeProgressPercent(task_5_progress, task_5_progress_bar) + "%"; }
    if (task_6_active || task_6_completion_status) { document.getElementById("task-6-percent-progress-output").innerHTML = getSafeProgressPercent(task_6_progress, task_6_progress_bar) + "%"; }
    if (task_7_active || task_7_completion_status) { document.getElementById("task-7-percent-progress-output").innerHTML = getSafeProgressPercent(task_7_progress, task_7_progress_bar) + "%"; }
    
    // INVENTORY UI STATS

    document.getElementById("inventory-777-jackpot-counter-stat").innerHTML = "Won<span style='color: rgb(204, 255, 0)'> > </span>" + formatDisplayNumber(total_777_jackpots_won_counter);
    document.getElementById("inventory-wild-bonus-counter-stat").innerHTML = "Won<span style='color: rgb(252, 0, 210)'> > </span>" + formatDisplayNumber(total_wild_bonus_won_counter);
    document.getElementById("inventory-triple-wilds-counter-stat").innerHTML = "Won<span style='color: rgb(162, 3, 210)'> > </span>" + formatDisplayNumber(total_triple_wilds_won_counter);
    document.getElementById("inventory-triple-stars-counter-stat").innerHTML = "Won<span style='color: rgb(162, 3, 210)'> > </span>" + formatDisplayNumber(total_triple_stars_won_counter);
    document.getElementById("inventory-free-spins-bonus-counter-stat").innerHTML = "Won<span style='color: rgb(230, 255, 5)'> > </span>" + formatDisplayNumber(free_spins_won_counter);

    // PROGRESS UI STATS

    document.getElementById("fund-farm-click-count-output").innerHTML = "<span style='color: yellow'>" + formatDisplayNumber(total_fund_farm_clicks) + " Clicks</span>";
    document.getElementById("fund-farm-cash-earned-output").innerHTML = "<span style='color: yellow'>$" + formatMoneyValue(total_fund_farm_cash_earned) + "</span>";
    document.getElementById("passive-income-cash-pool-output").innerHTML = "<span style='color: yellow'>$" + formatMoneyValue(total_passive_income_pool) + "</span>";
    document.getElementById("passive-income-cashout-int-output").innerHTML = "<span style='color: yellow'>" + passive_income_grant_int / 1000 + "s </span>" + "<span style='color: snow'>--- " + passive_income_grant_int_seconds + "s ---</span>";
    document.getElementById("playtime-output").innerHTML = "<span style='color: snow'>" + playtime_hours + "h " + playtime_minutes + "m " + playtime_seconds + "s</span>";
    document.getElementById("guess-matched-numbers-output").innerHTML = " <span style='color: yellow'>" + formatDisplayNumber(total_guessing_matches_won) + "</span>";
    document.getElementById("guess-mismatched-numbers-output").innerHTML = " <span style='color: yellow'>" + formatDisplayNumber(total_guessing_matches_lost) + "</span>";
    document.getElementById("total-match-amount-won-output").innerHTML = " <span style='color: yellow'>" + formatMoneyValue(total_guessing_matches_cash_earned) + "</span>";
    document.getElementById("total-spins-output").innerHTML = "<span style='color: lime'> Total Spins > </span><span style='color: yellow'>" + formatDisplayNumber(total_spins) + "</span></span>";
    document.getElementById("total-spins-cash-earned-output").innerHTML = "<span style='color: lime'> Cash Earned : </span><span style='color: yellow'>$" + formatMoneyValue(total_spins_cash_earned) + "</span></span>";
    document.getElementById("total-spins-cash-lost-output").innerHTML = "<span style='color: lime'> Cash Lost > </span><span style='color: yellow'>$" + formatMoneyValue(total_spins_cash_lost) + "</span></span>";
    document.getElementById("total-triple-777-jackpots-won-output").innerHTML = "<span style='color: lime'> 777's Jackpots Won > </span><span style='color: yellow'>" + formatDisplayNumber(total_777_jackpots_won_counter) + "</span></span>";
    document.getElementById("total-wild-bonuses-won-output").innerHTML = "<span style='color: lime'> Wild Bonuses Won > </span><span style='color: yellow'>" + formatDisplayNumber(total_wild_bonus_won_counter) + "</span></span>";
    document.getElementById("total-free-spins-bonuses-won-output").innerHTML = "<span style='color: lime'> Free Spins Won > </span><span style='color: yellow'>" + formatDisplayNumber(free_spins_won_counter) + "</span></span>";
    document.getElementById("current-lvl-progress-stat-output").innerHTML = "<span style='color: lime'> Current Level > </span><span style='color: yellow'>" + formatDisplayNumber(player_lvl) + "</span></span>";
    document.getElementById("current-lvl-progress-bar-value-output").innerHTML = "<span style='color: lime'> Current Level Progress > </span><span style='color: yellow'>" + formatDisplayNumber(player_lvl_progress_value) + "</span></span>";
    document.getElementById("next-lvl-cap-output").innerHTML = "<span style='color: lime'> Next Level Target > </span><span style='color: yellow'>" + formatDisplayNumber(next_lvl_req) + "</span></span>";
    document.getElementById("total-trivia-matches-output").innerHTML = "<span style='color: lime'> Total Trivia Matches > </span><span style='color: yellow'>" + formatDisplayNumber(total_trivia_matches) + "</span></span>";
    document.getElementById("total-correct-answers-output").innerHTML = "<span style='color: lime'> Total Correct Answers > </span><span style='color: yellow'>" + formatDisplayNumber(total_correct_answers) + "</span></span>";
    document.getElementById("total-incorrect-answers-output").innerHTML = "<span style='color: lime'> Total Incorrect Answers > </span><span style='color: yellow'>" + formatDisplayNumber(total_incorrect_answers) + "</span></span>";
    document.getElementById("total-answer-reveals-purchased-output").innerHTML = "<span style='color: lime'> Total Answer Reveals Used > </span><span style='color: yellow'>" + formatDisplayNumber(total_answer_reveals_purchased) + "</span></span>";
    document.getElementById("total-easy-mode-matches").innerHTML = "<span style='color: lime'> Total Easy Matches Played > </span><span style='color: yellow'>" + formatDisplayNumber(total_easy_matches) + "</span></span>";
    document.getElementById("total-medium-mode-matches").innerHTML = "<span style='color: lime'> Total Medium Matches Played > </span><span style='color: yellow'>" + formatDisplayNumber(total_medium_matches) + "</span></span>";
    document.getElementById("total-hard-mode-matches").innerHTML = "<span style='color: lime'> Total Hard Matches Played > </span><span style='color: yellow'>" + formatDisplayNumber(total_hard_matches) + "</span></span>";
    document.getElementById("total-timed-mode-matches").innerHTML = "<span style='color: lime'> Total Timed Matches Played > </span><span style='color: yellow'>" + formatDisplayNumber(total_timed_matches) + "</span></span>";
    document.getElementById("cash-bal-progress-output").innerHTML = " <span style='color: lime;'>$" + formatMoneyValue(player_cash_balance) + "</span>";
    document.getElementById("coins-bal-progress-output").innerHTML = " <span style='color: yellow;'>$" + formatMoneyValue(player_coins_balance) + "</span>";
    document.getElementById("diamonds-bal-progress-output").innerHTML = " <span style='color: aqua;'>$" + formatMoneyValue(player_diamond_balance) + "</span>";
    document.getElementById("tycoon-credit-bal-progress-output").innerHTML = " <span style='color: orange;'>$" + formatMoneyValue(player_tycoon_score) + "</span>";

    // BOARD SLOTS PASSIVE GRANTS

    document.getElementById("board-slot-1-amount").innerHTML = "<span style='color: springgreen'>+$" + board_1_grant_amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</span>";
    document.getElementById("board-slot-2-amount").innerHTML = "<span style='color: springgreen'>+$" + board_2_grant_amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</span>";
    document.getElementById("board-slot-3-amount").innerHTML = "<span style='color: springgreen'>+$" + board_3_grant_amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</span>";
    document.getElementById("board-slot-4-amount").innerHTML = "<span style='color: springgreen'>+$" + board_4_grant_amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</span>";
    document.getElementById("board-slot-5-amount").innerHTML = "<span style='color: springgreen'>+$" + board_5_grant_amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</span>";
    document.getElementById("board-slot-6-amount").innerHTML = "<span style='color: springgreen'>+$" + board_6_grant_amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</span>";

    slot_cash_ref_1.innerHTML = "<span style='color: rgb(0, 255, 229); margin-right: 7px;'> $" + formatMoneyValue(total_passive_income_pool) + "</span><span style='color: springgreen;'><span style='color: snow; margin-right: 7px;'>/</span><span style='color: yellow;'>" + passive_income_grant_int / 1000 + "s</span> >> +$" + formatMoneyValue(board_1_grant_amount) + "</span>";
    slot_cash_ref_2.innerHTML = "<span style='color: rgb(0, 255, 229); margin-right: 7px;'> $" + formatMoneyValue(total_passive_income_pool) + "</span><span style='color: springgreen;'><span style='color: snow; margin-right: 7px;'>/</span><span style='color: yellow;'>" + passive_income_grant_int / 1000 + "s</span> >> +$" + formatMoneyValue(board_2_grant_amount) + "</span>";
    slot_cash_ref_3.innerHTML = "<span style='color: rgb(0, 255, 229); margin-right: 7px;'> $" + formatMoneyValue(total_passive_income_pool) + "</span><span style='color: springgreen;'><span style='color: snow; margin-right: 7px;'>/</span><span style='color: yellow;'>" + passive_income_grant_int / 1000 + "s</span> >> +$" + formatMoneyValue(board_3_grant_amount) + "</span>";
    slot_cash_ref_4.innerHTML = "<span style='color: rgb(0, 255, 229); margin-right: 7px;'> $" + formatMoneyValue(total_passive_income_pool) + "</span><span style='color: springgreen;'><span style='color: snow; margin-right: 7px;'>/</span><span style='color: yellow;'>" + passive_income_grant_int / 1000 + "s</span> >> +$" + formatMoneyValue(board_4_grant_amount) + "</span>";
    slot_cash_ref_5.innerHTML = "<span style='color: rgb(0, 255, 229); margin-right: 7px;'> $" + formatMoneyValue(total_passive_income_pool) + "</span><span style='color: springgreen;'><span style='color: snow; margin-right: 7px;'>/</span><span style='color: yellow;'>" + passive_income_grant_int / 1000 + "s</span> >> +$" + formatMoneyValue(board_5_grant_amount) + "</span>";
    slot_cash_ref_6.innerHTML = "<span style='color: rgb(0, 255, 229); margin-right: 7px;'> $" + formatMoneyValue(total_passive_income_pool) + "</span><span style='color: springgreen;'><span style='color: snow; margin-right: 7px;'>/</span><span style='color: yellow;'>" + passive_income_grant_int / 1000 + "s</span> >> +$" + formatMoneyValue(board_6_grant_amount) + "</span>";

    // FARM PERCENT PROGRESS STATUSES

    document.getElementById("farm-1-percent-progress-output").innerHTML = getSafeProgressPercent(farm_1_progress_bar.value, farm_1_progress_bar) + "%";
    document.getElementById("farm-2-percent-progress-output").innerHTML = getSafeProgressPercent(farm_2_progress_bar.value, farm_2_progress_bar) + "%";
    document.getElementById("farm-3-percent-progress-output").innerHTML = getSafeProgressPercent(farm_3_progress_bar.value, farm_3_progress_bar) + "%";
    document.getElementById("farm-4-percent-progress-output").innerHTML = getSafeProgressPercent(farm_4_progress_bar.value, farm_4_progress_bar) + "%";
    document.getElementById("farm-5-percent-progress-output").innerHTML = getSafeProgressPercent(farm_5_progress_bar.value, farm_5_progress_bar) + "%";
    document.getElementById("farm-6-percent-progress-output").innerHTML = getSafeProgressPercent(farm_6_progress_bar.value, farm_6_progress_bar) + "%";

    document.getElementById("tier-2-farm-1-percent-progress-output").innerHTML = getSafeProgressPercent(tier_2_farm_1_progress_bar.value, tier_2_farm_1_progress_bar) + "%";
    document.getElementById("tier-2-farm-2-percent-progress-output").innerHTML = getSafeProgressPercent(tier_2_farm_2_progress_bar.value, tier_2_farm_2_progress_bar) + "%";
    document.getElementById("tier-2-farm-3-percent-progress-output").innerHTML = getSafeProgressPercent(tier_2_farm_3_progress_bar.value, tier_2_farm_3_progress_bar) + "%";
    document.getElementById("tier-2-farm-4-percent-progress-output").innerHTML = getSafeProgressPercent(tier_2_farm_4_progress_bar.value, tier_2_farm_4_progress_bar) + "%";
    document.getElementById("tier-2-farm-5-percent-progress-output").innerHTML = getSafeProgressPercent(tier_2_farm_5_progress_bar.value, tier_2_farm_5_progress_bar) + "%";
    document.getElementById("tier-2-farm-6-percent-progress-output").innerHTML = getSafeProgressPercent(tier_2_farm_6_progress_bar.value, tier_2_farm_6_progress_bar) + "%";

    document.getElementById("tier-3-farm-1-percent-progress-output").innerHTML = getSafeProgressPercent(tier_3_farm_1_progress_bar.value, tier_3_farm_1_progress_bar) + "%";
    document.getElementById("tier-3-farm-2-percent-progress-output").innerHTML = getSafeProgressPercent(tier_3_farm_2_progress_bar.value, tier_3_farm_2_progress_bar) + "%";
    document.getElementById("tier-3-farm-3-percent-progress-output").innerHTML = getSafeProgressPercent(tier_3_farm_3_progress_bar.value, tier_3_farm_3_progress_bar) + "%";
    document.getElementById("tier-3-farm-4-percent-progress-output").innerHTML = getSafeProgressPercent(tier_3_farm_4_progress_bar.value, tier_3_farm_4_progress_bar) + "%";
    document.getElementById("tier-3-farm-5-percent-progress-output").innerHTML = getSafeProgressPercent(tier_3_farm_5_progress_bar.value, tier_3_farm_5_progress_bar) + "%";
    document.getElementById("tier-3-farm-6-percent-progress-output").innerHTML = getSafeProgressPercent(tier_3_farm_6_progress_bar.value, tier_3_farm_6_progress_bar) + "%";
}

function updateFundFarmCashAmounts() {
    // TIER 1 FUND FARMS

    document.getElementById("farm_1_cash_amount_output").innerHTML = "<h3> $" + farm_1_cash_amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</h3>";
    document.getElementById("farm_2_cash_amount_output").innerHTML = "<h3> $" + farm_2_cash_amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</h3>";
    document.getElementById("farm_3_cash_amount_output").innerHTML = "<h3> $" + farm_3_cash_amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</h3>";
    document.getElementById("farm_4_cash_amount_output").innerHTML = "<h3> $" + farm_4_cash_amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</h3>";
    document.getElementById("farm_5_cash_amount_output").innerHTML = "<h3> $" + farm_5_cash_amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</h3>";
    document.getElementById("farm_6_cash_amount_output").innerHTML = "<h3> $" + farm_6_cash_amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</h3>";

    // TIER 2 FUND FARMS

    document.getElementById("tier-2-farm-1-cash-amount-output").innerHTML = "<h3> $" + tier_2_farm_1_cash_amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</h3>";
    document.getElementById("tier-2-farm-2-cash-amount-output").innerHTML = "<h3> $" + tier_2_farm_2_cash_amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</h3>";
    document.getElementById("tier-2-farm-3-cash-amount-output").innerHTML = "<h3> $" + tier_2_farm_3_cash_amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</h3>";
    document.getElementById("tier-2-farm-4-cash-amount-output").innerHTML = "<h3> $" + tier_2_farm_4_cash_amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</h3>";
    document.getElementById("tier-2-farm-5-cash-amount-output").innerHTML = "<h3> $" + tier_2_farm_5_cash_amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</h3>";
    document.getElementById("tier-2-farm-6-cash-amount-output").innerHTML = "<h3> $" + tier_2_farm_6_cash_amount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</h3>";

    // TIER 3 COIN FARMS

    document.getElementById("tier-3-farm-1-cash-amount-output").innerHTML = "<h3 style='color: yellow;'>" + tier_3_farm_1_cash_amount + "</h3>";
    document.getElementById("tier-3-farm-2-cash-amount-output").innerHTML = "<h3 style='color: yellow;'>" + tier_3_farm_2_cash_amount + "</h3>";
    document.getElementById("tier-3-farm-3-cash-amount-output").innerHTML = "<h3 style='color: yellow;'>" + tier_3_farm_3_cash_amount + "</h3>";
    document.getElementById("tier-3-farm-4-cash-amount-output").innerHTML = "<h3 style='color: yellow;'>" + tier_3_farm_4_cash_amount + "</h3>";
    document.getElementById("tier-3-farm-5-cash-amount-output").innerHTML = "<h3 style='color: yellow;'>" + tier_3_farm_5_cash_amount + "</h3>";
    document.getElementById("tier-3-farm-6-cash-amount-output").innerHTML = "<h3 style='color: yellow;'>" + tier_3_farm_6_cash_amount + "</h3>";
}

let stat_reloader_int = setInterval( function() {
    updateStats();
    updateBetDisplay();
    updateBetDisplay2();
    updatePlayerLvlProgressUI();

    // LOAN AVAILABILITY CHECKERS

    //if (player_tycoon_score >= 100) { cash_loan_1_available = false; enableLoanOpt(cash_loan_opt_1); } else { cash_loan_1_available = false; disableLoanOpt(cash_loan_opt_1); }
    //if (player_tycoon_score >= 200) { cash_loan_2_available = false; enableLoanOpt(cash_loan_opt_2); } else { cash_loan_2_available = false; disableLoanOpt(cash_loan_opt_2); }
    //if (player_tycoon_score >= 300) { cash_loan_3_available = false; enableLoanOpt(cash_loan_opt_3); } else { cash_loan_3_available = false; disableLoanOpt(cash_loan_opt_3); }
    //if (player_tycoon_score >= 400) { cash_loan_4_available = false; enableLoanOpt(cash_loan_opt_4); } else { cash_loan_4_available = false; disableLoanOpt(cash_loan_opt_4); }
 

    // TIER 1 FARMS
    // Periodically check farm status to enable/disable buttons

    fundFarmsStatusChecker(farm_1_progress_bar, farm_1_collect_opt, farm_1_progress_int, 5);
    fundFarmsStatusChecker(farm_2_progress_bar, farm_2_collect_opt, farm_2_progress_int, 10);
    fundFarmsStatusChecker(farm_3_progress_bar, farm_3_collect_opt, farm_3_progress_int, 15);
    fundFarmsStatusChecker(farm_4_progress_bar, farm_4_collect_opt, farm_4_progress_int, 25);
    fundFarmsStatusChecker(farm_5_progress_bar, farm_5_collect_opt, farm_5_progress_int, 45);
    fundFarmsStatusChecker(farm_6_progress_bar, farm_6_collect_opt, farm_6_progress_int, 90);

    // TIER 2 FARMS

    fundFarmsStatusChecker(tier_2_farm_1_progress_bar, tier_2_farm_1_collect_opt, tier_2_farm_1_progress_int, 5);
    fundFarmsStatusChecker(tier_2_farm_2_progress_bar, tier_2_farm_2_collect_opt, tier_2_farm_2_progress_int, 10);
    fundFarmsStatusChecker(tier_2_farm_3_progress_bar, tier_2_farm_3_collect_opt, tier_2_farm_3_progress_int, 15);
    fundFarmsStatusChecker(tier_2_farm_4_progress_bar, tier_2_farm_4_collect_opt, tier_2_farm_4_progress_int, 25);
    fundFarmsStatusChecker(tier_2_farm_5_progress_bar, tier_2_farm_5_collect_opt, tier_2_farm_5_progress_int, 45);
    fundFarmsStatusChecker(tier_2_farm_6_progress_bar, tier_2_farm_6_collect_opt, tier_2_farm_6_progress_int, 90);

    // TIER 3 FARMS

    fundFarmsStatusChecker(tier_3_farm_1_progress_bar, tier_3_farm_1_collect_opt, tier_3_farm_1_progress_int, 10);
    fundFarmsStatusChecker(tier_3_farm_2_progress_bar, tier_3_farm_2_collect_opt, tier_3_farm_2_progress_int, 20);
    fundFarmsStatusChecker(tier_3_farm_3_progress_bar, tier_3_farm_3_collect_opt, tier_3_farm_3_progress_int, 30);
    fundFarmsStatusChecker(tier_3_farm_4_progress_bar, tier_3_farm_4_collect_opt, tier_3_farm_4_progress_int, 40);
    fundFarmsStatusChecker(tier_3_farm_5_progress_bar, tier_3_farm_5_collect_opt, tier_3_farm_5_progress_int, 50);
    fundFarmsStatusChecker(tier_3_farm_6_progress_bar, tier_3_farm_6_collect_opt, tier_3_farm_6_progress_int, 60);


    if (auto_spin_active) {
        disableGamblingControls();
        document.getElementById("stats-tab-auto-spin-status-output").innerHTML = "Auto-Spin > <span style='color: springgreen; font-weight: bold;'>" + "Active" + "</span>";
    } else {
        document.getElementById("stats-tab-auto-spin-status-output").innerHTML = "Auto-Spin > <span style='color: rgb(255, 150, 150); font-weight: bold;'>" + "Inactive" + "</span>";
    }

    if (auto_spin_2_active) {
        disableGamblingControls2();
        document.getElementById("stats-tab-auto-spin-status-output-2").innerHTML = "Auto-Spin > <span style='color: springgreen; font-weight: bold;'>" + "Active" + "</span>";
    } else {
        document.getElementById("stats-tab-auto-spin-status-output-2").innerHTML = "Auto-Spin > <span style='color: rgb(255, 150, 150); font-weight: bold;'>" + "Inactive" + "</span>";
    }

    if (spin_initiation_status) { disableGamblingControls(); }
    if (spin_2_initiation_status) { disableGamblingControls2(); }


    if (jackpot_win_probability === 40) {
        document.getElementById("increase-7s-probability-diamond").disabled = true;
        document.getElementById("increase-7s-probability-diamond").style.cursor = "not-allowed";
        document.getElementById("increase-7s-probability-diamond").style.opacity = "0.5";
        document.getElementById("increase-7s-probability-coins").disabled = true;
        document.getElementById("increase-7s-probability-coins").style.cursor = "not-allowed";
        document.getElementById("increase-7s-probability-coins").style.opacity = "0.5";
    }
    if (wild_win_probability === 10) {
        document.getElementById("increase-wilds-probability-diamond").disabled = true;
        document.getElementById("increase-wilds-probability-diamond").style.cursor = "not-allowed";
        document.getElementById("increase-wilds-probability-diamond").style.opacity = "0.5";
        document.getElementById("increase-wilds-probability-coins").disabled = true;
        document.getElementById("increase-wilds-probability-coins").style.cursor = "not-allowed";
        document.getElementById("increase-wilds-probability-coins").style.opacity = "0.5";
    }

    // WILD FREE SPINS ENDING SEQUENCE

    if (wild_bonus_free_spins === 10) { // Wild Bonus Free Spins Expiry sequence
        wild_bonus_active = false;
        wild_bonus_free_spins = 0;
        setTimeout(() => {
            notificationDialog("WILD BONUS EXPIRED!", 3000);
            jack_win = 5;
            queen_win = 7;
            king_win = 10;
            jackpot_win_probability = 60;
            wild_win_probability = 15;
            wild_bonus_probability = 15;

            jack_probability = 12;
            queen_probability = 12;
            king_probability = 15;
            diamond_probability = 30;
            cash_probability = 15;

            inventory_slot_4_use_booster_opt.disabled = false;
            inventory_slot_4_use_booster_opt.style.opacity = "1";
            inventory_slot_4_use_booster_opt.style.cursor = "pointer";
            inventory_slot_5_use_booster_opt.disabled = false;
            inventory_slot_5_use_booster_opt.style.opacity = "1";
            inventory_slot_5_use_booster_opt.style.cursor = "pointer";
            document.getElementById("wild-bonus-end-dialog-overlay").style.display = "flex";
            document.getElementById("wild-bonus-free-spins-output").style.display = "none";

            document.getElementById("total-bonus-cash-win-output").innerHTML = "<span style='color: lime'>Cash Won > $" + wild_bonus_cash_win_total.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</span>";
            document.getElementById("total-bonus-coin-win-output").innerHTML = "<span style='color: yellow'>Coins Won > " + wild_bonus_coin_win_total + "</span>";
            document.getElementById("total-bonus-diamond-win-output").innerHTML = "<span style='color: aquamarine'>Diamonds Won > " + wild_bonus_diamond_win_total + "</span>";

            clearInterval(security_control_disable_int);
            clearInterval(wild_bet_lock_int);
            setTimeout(() => { document.getElementById("wild-bonus-end-dialog-overlay").style.display = "none"; }, 10000)

            bet_btn.style.display = "block";
            max_bet_btn.style.display = "block";
            high_roller_opt.style.display = "block";
            bet = 2;
            terminateAutoSpin();
        }, 5000)
    }

    if (free_spins_bonus_spins == free_spins_granted) { // Free Spins Bonus Expiry sequence
        free_spins_bonus_active = false;
        free_spins_bonus_spins = 0;
        custom_auto_spin_count = 5;
        custom_auto_spin_count_limit = 0;
        terminateAutoSpin2();
        setTimeout(() => {
            notificationDialog("FREE SPINS BONUS EXPIRED!", 3000);
            terminateAutoSpin2();

            jack_2_probability = 8;
            queen_2_probability = 12;
            king_2_probability = 17;
            cash_2_probability = 12;

            triple_wilds_probability = 30;
            cherry_probability = 20;
            seven_probability = 30;
            diamond_2_probability = 45;
            star_probability = 400;

            cash_win_2 = 2;
            diamond_win_2 = 1;
            coin_win_2 = 1;
            coin_cluster_win = 3;
            // Keep these in sync with gambling-2.js defaults
            jack_win_2 = 1.00;
            queen_win_2 = 1.50;
            king_win_2 = 2.50;

            free_spins_granted = null;
            free_spins_bonus_probability = 45;
            high_roller_opt_2.style.display = "block";
            inventory_slot_4_use_booster_opt.disabled = false;
            inventory_slot_4_use_booster_opt.style.opacity = "1";
            inventory_slot_4_use_booster_opt.style.cursor = "pointer";
            inventory_slot_10_use_booster_opt.disabled = false;
            inventory_slot_10_use_booster_opt.style.opacity = "1";
            inventory_slot_10_use_booster_opt.style.cursor = "pointer";
            inventory_slot_5_use_booster_opt.disabled = false;
            inventory_slot_5_use_booster_opt.style.opacity = "1";
            inventory_slot_5_use_booster_opt.style.cursor = "pointer";
            setTimeout(() => { document.getElementById("auto-spin-countdown-dialog-overlay").style.display = "none"; }, 1500)
            document.getElementById("free-spins-bonus-end-dialog-overlay").style.display = "flex";
            document.getElementById("free-spins-bonus-spins-output").style.display = "none";
            document.getElementById("total-free-spins-bonus-cash-win-output").innerHTML = "<span style='color: lime'>Cash Won > $" + free_spins_bonus_cash_win_total.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + "</span>";
            document.getElementById("total-free-spins-bonus-coin-win-output").innerHTML = "<span style='color: yellow'>Coins Won > " + formatDisplayNumber(free_spins_bonus_coin_win_total) + "</span>";
            document.getElementById("total-free-spins-bonus-diamond-win-output").innerHTML = "<span style='color: aquamarine'>Diamonds Won > " + formatDisplayNumber(free_spins_bonus_diamond_win_total) + "</span>";
            clearInterval(security_control_disable_int_2);
            setTimeout(() => { document.getElementById("free-spins-bonus-end-dialog-overlay").style.display = "none"; }, 10000)

            bet_btn_2.style.display = "block";
            max_bet_btn_2.style.display = "block";
            bet_2 = 2;
        }, 4000)
    }

    // TASK ACTIVE STATUS CHECKERS

    if (task_1_progress === task_1_progress_bar.max) { notificationDialog("TASK COMPLETED!", 3000); task_1_progress = -1; total_tasks_completed++; task_1_active = false; task_1_completion_status = true; taskCompletedAudio() }
    if (task_2_progress === task_2_progress_bar.max) { notificationDialog("TASK COMPLETED!", 3000); task_2_progress = -1; total_tasks_completed++; task_2_active = false; task_2_completion_status = true; taskCompletedAudio() }
    if (task_3_progress === task_3_progress_bar.max) { notificationDialog("TASK COMPLETED!", 3000); task_3_progress = -1; total_tasks_completed++; task_3_active = false; task_3_completion_status = true; taskCompletedAudio() }
    if (task_4_progress === task_4_progress_bar.max) { notificationDialog("TASK COMPLETED!", 3000); task_4_progress = -1; total_tasks_completed++; task_4_active = false; task_4_completion_status = true; taskCompletedAudio() }
    if (task_5_progress === task_5_progress_bar.max) { notificationDialog("TASK COMPLETED!", 3000); task_5_progress = -1; total_tasks_completed++; task_5_active = false; task_5_completion_status = true; taskCompletedAudio() }
    if (task_6_progress === task_6_progress_bar.max) { notificationDialog("TASK COMPLETED!", 3000); task_6_progress = -1; total_tasks_completed++; task_6_active = false; task_6_completion_status = true; taskCompletedAudio() }
    if (task_7_progress === task_7_progress_bar.max) { notificationDialog("TASK COMPLETED!", 3000); task_7_progress = -1; total_tasks_completed++; task_7_active = false; task_7_completion_status = true; taskCompletedAudio() }
    
    syncTaskClaimButtons();

    if (digit_guess_match_streak_counter === 1) {
        document.getElementById("match-streak-1").innerHTML = "<img src='Images/tick-icon.svg' style='border-radius: 50px;' width='60px' height='60px' />";
    } 
    if (digit_guess_match_streak_counter === 2) {
        document.getElementById("match-streak-2").innerHTML = "<img src='Images/tick-icon.svg' style='border-radius: 50px;' width='60px' height='60px' />";
    } 
    if (digit_guess_match_streak_counter === 3) {
        document.getElementById("match-streak-3").innerHTML = "<img src='Images/tick-icon.svg' style='border-radius: 50px;' width='60px' height='60px' />";
        collectFarmAudio();
        setTimeout(() => { digit_guess_match_streak_counter = 0; }, 100)
        setTimeout(() => {
            document.getElementById("match-streak-1").innerHTML = "";
            document.getElementById("match-streak-2").innerHTML = "";
            document.getElementById("match-streak-3").innerHTML = "";
            document.getElementById("mismatch-1").innerHTML = "";
            document.getElementById("mismatch-2").innerHTML = "";
            document.getElementById("mismatch-3").innerHTML = "";
        }, 1000)
        matchWinAward("STREAK COMPLETED!", digit_guess_match_win * 4);
        let random_booster_win = Math.floor(Math.random() * 20);
        let random_bonus_win = Math.floor(Math.random() * 30);

        if (random_booster_win === 1) {
            inventory_slot_1_player_owned_amount++;
            smallDingAudio();
            notificationDialog("Credited X1 Double Farm Income Booster", 4000);
        } else if (random_booster_win === 5) {
            inventory_slot_2_player_owned_amount++;
            smallDingAudio();
            notificationDialog("Credited X1 Triple Farm Income Booster", 4000);
        } else if (random_booster_win === 1) {
            let random_bonus = Math.floor(Math.random() * 2);

            if (random_bonus === 1) {
                inventory_slot_10_player_owned_amount++;
                notificationDialog("Credited X1 Free Spins Bonus to inventory", 4000);
            } else if (random_bonus === 2) {
                inventory_slot_5_player_owned_amount++;
                notificationDialog("Credited X1 Wild Spins Bonus to inventory", 4000);
            }
        }
    }

    if (digit_guess_mismatch_counter === 1) {
        document.getElementById("mismatch-1").innerHTML = "<img src='Images/x-icon.svg' style='border-radius: 50px;' width='60px' height='60px' />";
        
    } else if (digit_guess_mismatch_counter === 2) {
        document.getElementById("mismatch-2").innerHTML = "<img src='Images/x-icon.svg' style='border-radius: 50px;' width='60px' height='60px' />";
    } else if (digit_guess_mismatch_counter === 3) {
        document.getElementById("mismatch-3").innerHTML = "<img src='Images/x-icon.svg' style='border-radius: 50px;' width='60px' height='60px' />";
        setTimeout(() => {
            digit_guess_match_streak_counter = 0;
            digit_guess_mismatch_counter = 0;
            document.getElementById("match-streak-1").innerHTML = "";
            document.getElementById("match-streak-2").innerHTML = "";
            document.getElementById("match-streak-3").innerHTML = "";
            document.getElementById("mismatch-1").innerHTML = "";
            document.getElementById("mismatch-2").innerHTML = "";
            document.getElementById("mismatch-3").innerHTML = "";
            rand_digit_inp.value = "";
            upgradePurchaseFailedAudio();
        }, 1000)
        notificationDialog("STREAK HAS BEEN RESET!", 3000);
    }

    if (tier_2_farm_unlocked) {
        document.getElementById("store-slot-3-upgrade-btn").disabled = true;
        document.getElementById("store-slot-3-upgrade-btn").style.opacity = "0.5";
        document.getElementById("store-slot-3-upgrade-btn").style.cursor = "not-allowed";
    }

    if (tier_3_farm_unlocked) {
        document.getElementById("store-slot-5-upgrade-btn").disabled = true;
        document.getElementById("store-slot-5-upgrade-btn").style.opacity = "0.5";
        document.getElementById("store-slot-5-upgrade-btn").style.cursor = "not-allowed";
    }

    if (store_slot_1_passive_income_cashout_int_reduction_lvl === 5) {
         document.getElementById("passive-income-int-reduction-lvl-output").innerHTML = " <span style='color: yellow; font-weight: bold; font-family: monospace, sans-serif;'>UPGRADE LEVEL >> [" + store_slot_1_passive_income_cashout_int_reduction_lvl + "/" + store_slot_1_upgrade_max_lvl + "]</span>" + "<span style='color: springgreen;'> [MAX]</span>";
    } else {
        document.getElementById("passive-income-int-reduction-lvl-output").innerHTML = " <span style='color: yellow; font-weight: bold; font-family: monospace, sans-serif;'>UPGRADE LEVEL >> [" + store_slot_1_passive_income_cashout_int_reduction_lvl + "/" + store_slot_1_upgrade_max_lvl + "]</span>";
    }

    //END
}, 250);

let trivia_reloader = setInterval( function() {
    document.getElementById("trivia-score-output").innerHTML = "SCORE > " + user_trivia_score;
    document.getElementById("trivia-match-cash-total-output").innerHTML = "CASH WON > $" + user_trivia_match_cash_won_total.toFixed(2);
    document.getElementById("trivia-attempts-output").innerHTML = "ATTEMPTS > " + user_trivia_attempts;
    document.getElementById("trivia-high-score-output").innerHTML = "HIGH SCORE > " + user_trivia_high_score;
    
    if (user_trivia_attempts >= 3) {
        document.getElementById("trivia-attempts-output").style.color = "lime";
    } else if (user_trivia_attempts === 2) {
        document.getElementById("trivia-attempts-output").style.color = "darkorange";
    } else if (user_trivia_attempts === 1) {
        document.getElementById("trivia-attempts-output").style.color = "rgb(255, 106, 173)";
    } else if (user_trivia_attempts === 0) {
        setTimeout(() => { triviaGameOverAudio(); }, 250);
        user_trivia_attempts = 999;
        game_total = user_trivia_match_cash_won_total * trivia_reward_multiplier;
        player_cash_balance += game_total;
        total_trivia_matches++;
        setTimeout(() => { trivia_reward_multiplier = 0; }, 3000)
        timed_dif_question_timer_value = 30000;
        timer_mod_inp.value = 30;
        input_value = 30;
        timed_dif_active = false;
        match_active = false;
        clearInterval(timed_dif_question_timer);
        notificationDialog("You received $" + game_total.toFixed(2) + "from " + user_set_trivia_dif_txt + " trivia match!");

        if (user_set_trivia_dif_txt === "EASY") { total_easy_matches++; }
        if (user_set_trivia_dif_txt === "MEDIUM") { total_medium_matches++; }
        if (user_set_trivia_dif_txt === "HARD") { total_hard_matches++; }
        if (user_set_trivia_dif_txt === "TIMED") { total_timed_matches++; }

        inventory_slot_11_use_booster_opt.disabled = false;
        inventory_slot_11_use_booster_opt.style.opacity = "1";
        inventory_slot_11_use_booster_opt.style.cursor = "pointer";

        if (task_7_active) {
            if (user_trivia_score >= 75) {
                task_7_progress = increaseProgressValue(task_7_progress, task_7_progress_bar, 75);
                task_7_progress_bar.value = 75;
            }
        }

        let reset_int = setInterval(() => {
            easy_dif_active = false;
            medium_dif_active = false;
            hard_dif_active = false;
            timed_dif_active = false;
            trivia_answer_reveal_tool.disabled = false;
            trivia_answer_reveal_tool.style.opacity = "1";
            trivia_answer_reveal_tool.style.cursor = "pointer";
            auto_next_question_trigger_preference.disabled = false;
            auto_next_question_trigger_preference.style.opacity = "1";
            auto_next_question_trigger_preference.style.cursor = "pointer";
        }, 100)
        setTimeout(() => {
            document.getElementById("start-trivia-btn").style.display = "none";
            document.getElementById("trivia-main-panel").style.display = "none";
            document.getElementById("trivia-info-panel").style.display = "flex";
            document.getElementById("trivia-stats").style.display = "none";
            document.getElementById("trivia-score-output").style.display = "none";
            document.getElementById("trivia-tools-panel").style.display = "flex";
            document.getElementById("trivia-attempts-output").style.display = "none";
            document.getElementById("question-panel").style.display = "none";
            document.getElementById("trivia-match-cash-total-output").style.display = "none";
            document.getElementById('reveal-answer').style.display = "none";
            document.getElementById("next-question-btn").style.display = "none";
            document.getElementById("trivia-title").style.display = "block";
            document.getElementById("start-trivia-btn").disabled = true;
        }, 100)
        setTimeout(() => { clearInterval(reset_int); }, 1500)
        setTimeout(() => {
            setTimeout(() => { modified_match = false; user_set_trivia_dif_txt = ""; }, 2000)
            document.getElementById("selected-dif-output-2").innerHTML = "<span style='color: aquamarine;'>MATCH DIFFICULTY > " + user_set_trivia_dif_txt + "</span>";
            document.getElementById("match-total-cash-output").innerHTML = "CASH WON > <span style='color: yellow'>$" + formatMoneyValue(user_trivia_match_cash_won_total) + "</span>";
            document.getElementById("winnings-multiplier-output").innerHTML = "CASH MULTIPLIER > <span style='color: yellow'>" + trivia_reward_multiplier + "</span> x <span style='color: yellow'>(cash win)</span>";
            document.getElementById("match-score-output").innerHTML = "<span style='color: aquamarine'>SCORE > " + user_trivia_score + " POINTS </span>";
            document.getElementById("match-total-output").innerHTML = "<span style='color: lime'>TOTAL</span> > <span style='color: yellow'>$" + formatMoneyValue(game_total) + "</span> ---- <span style='color: yellow'>" + trivia_reward_multiplier + "</span> X <span style='color: yellow'>$" + user_trivia_match_cash_won_total.toFixed(2) + "</span>";
            document.getElementById("match-results-panel").style.display = "flex";
        
            for (let dd = 0; dd < triviaDifBtnsStorage.length; dd++) {
                triviaDifBtnsStorage[dd].disabled = true;
                triviaDifBtnsStorage[dd].style.cursor = "not-allowed";
                triviaDifBtnsStorage[dd].style.opacity = "0.5";
                setTimeout( function() {
                    document.getElementById("difficulty-tab").style.display = "flex";
                    triviaDifBtnsStorage[dd].disabled = false;
                    triviaDifBtnsStorage[dd].style.display = "block";
                    triviaDifBtnsStorage[dd].style.cursor = "pointer";
                    triviaDifBtnsStorage[dd].style.opacity = "1";
                }, 2000)
            }

            if (user_trivia_score > user_trivia_high_score) {
                user_trivia_high_score = user_trivia_score;
                notificationDialog("You have a new high score!", 3500);
            }
            document.getElementById("trivia-high-score-output").textContent = "HIGH SCORE : " + user_trivia_high_score;

            if (user_trivia_high_score > 0) {
                document.getElementById("trivia-high-score-output").style.display = "block";
            }
        }, 2000)
    }
}, 500);

setInterval(function() {
    autoSave();
}, 1000);

let stat_reloader_int_2 = setInterval( function() {
    updateFundFarmCashAmounts();

    if (player_cash_balance <= 0) { document.getElementById("cash-balance-output").style.color = "red"; 

    } else { 
        document.getElementById("cash-balance-output").style.color = "springgreen";
    } 

    if (total_passive_income_pool <= 0) { document.getElementById("passive-income-pool-output").style.color = "red"; 

    } else { 
        document.getElementById("passive-income-pool-output").style.color = "springgreen";
    }

    // STORE SLOT 1 UPGRADE LVL CHECKER

    if (store_slot_1_passive_income_cashout_int_reduction_lvl >= store_slot_1_upgrade_max_lvl) {
        store_slot_1_upgrade_max_lvl_state = true;
        document.getElementById("store-slot-1-upgrade-btn").disabled = true;
        document.getElementById("store-slot-1-upgrade-btn").style.cursor = "not-allowed";
        document.getElementById("store-slot-1-upgrade-btn").style.opacity = "0.5";
    } else {

    }
}, 500)
