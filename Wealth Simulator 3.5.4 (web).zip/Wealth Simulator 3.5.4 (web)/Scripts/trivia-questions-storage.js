const trivia_questions_storage = [
  {
    "question": "WHAT IS THE CAPITAL CITY OF EGYPT?",
    "options": [
      "BUDAPEST",
      "CAIRO",
      "LONDON",
      "ROME"
    ],
    "correctAnswer": "CAIRO"
  },
  {
    "question": "WHAT IS EARTH'S LARGEST CONTINENT?",
    "options": [
      "AFRICA",
      "INDIA",
      "UNITED KINGDOM",
      "ASIA"
    ],
    "correctAnswer": "ASIA"
  },
  {
    "question": "WHAT IS THE LEGAL CURRENCY IN FRANCE?",
    "options": [
      "RUBLE",
      "EURO (€)",
      "POUNDS (GBP)",
      "DOLLAR ($)"
    ],
    "correctAnswer": "EURO (€)"
  },
  {
    "question": "WHAT IS THE CLOSEST PLANET TO THE SUN?",
    "options": [
      "VENUS",
      "MERCURY",
      "PLUTO",
      "EARTH"
    ],
    "correctAnswer": "MERCURY"
  },
  {
    "question": "WHICH 2 COMBINED METALS FORM BRONZE?",
    "options": [
      "NICKEL + IRON",
      "COPPER + TIN",
      "ALUMINIUM + TIN",
      "COPPER + LEAD"
    ],
    "correctAnswer": "COPPER + TIN"
  },
  {
    "question": "WHAT DOES HTML STAND FOR?",
    "options": [
      "HYPER TELETEXT MAIL LANGUAGE",
      "HYPER TEXT MARKUP LANGUAGE",
      "HYPERTENSION MAIN LINE",
      "NONE OF THE ABOVE"
    ],
    "correctAnswer": "HYPER TEXT MARKUP LANGUAGE"
  },
  {
    "question": "WHICH IS THE LARGEST STORAGE VALUE?",
    "options": [
      "100KB",
      "500MB",
      "1TB",
      "1500MB"
    ],
    "correctAnswer": "1TB"
  },
  {
    "question": "HOW DOES PI BEGIN IN NUMERIC FORM",
    "options": [
      "2.14",
      "7.44",
      "1.75",
      "3.14"
    ],
    "correctAnswer": "3.14"
  },
  {
    "question": "WHICH OF THE FOLLOWING IS NOT A SCRIPTING LANGUAGE?",
    "options": [
      "CSS",
      "PYTHON",
      "C++",
      "JAVASCRIPT"
    ],
    "correctAnswer": "CSS"
  },
  {
    "question": "WHAT DOES THE ELEMENT [AU] REPRESENT ON THE PERIODIC TABLE?",
    "options": [
      "ARGON",
      "HELIUM",
      "POTASIUM",
      "GOLD"
    ],
    "correctAnswer": "GOLD"
  },
  {
    "question": "Which is the tallest mountain on Earth?",
    "options": [
      "MOUNT FUJI",
      "OLYMPIA",
      "MOUNT OLYMPUS",
      "MOUNT EVEREST"
    ],
    "correctAnswer": "MOUNT EVEREST"
  },
  {
    "question": "Which 2 primary colors would form purple?",
    "options": [
      "YELLOW + BLUE",
      "RED + BLUE",
      "ORANGE + BROWN",
      "RED + GREEN"
    ],
    "correctAnswer": "RED + BLUE"
  },
  {
    "question": "What is the square root of 49?",
    "options": [
      "7",
      "12",
      "6",
      "16"
    ],
    "correctAnswer": "7"
  },
  {
    "question": "How many planets reside in our solar system?",
    "options": [
      "6",
      "9",
      "10",
      "8"
    ],
    "correctAnswer": "8"
  },
  {
    "question": "Which is the largest ocean on Earth?",
    "options": [
      "INDIAN OCEAN",
      "ATLANTIC OCEAN",
      "PACIFIC OCEAN",
      "ARCTIC OCEAN"
    ],
    "correctAnswer": "PACIFIC OCEAN"
  },
  {
    "question": "Which is the smallest continent?",
    "options": [
      "AUSTRALIA",
      "AFRICA",
      "NORTH AMERICA",
      "SOUTH AMERICA"
    ],
    "correctAnswer": "AUSTRALIA"
  },
  {
    "question": "Who directed the Lord of the Rings trilogy?",
    "options": [
      "J.K ROWLING",
      "STEVEN SPIELBERG",
      "PETER JACKSON",
      "CHRISTOPHER NOLAN"
    ],
    "correctAnswer": "PETER JACKSON"
  },
  {
    "question": "How many continents are there in the world?",
    "options": [
      "7",
      "5",
      "9",
      "8"
    ],
    "correctAnswer": "7"
  },
  {
    "question": "How many bones do sharks have?",
    "options": [
      "27",
      "9",
      "0",
      "12"
    ],
    "correctAnswer": "0"
  },
  {
    "question": "Can you name the three primary colours?",
    "options": [
      "RED, GREEN, BLUE",
      "RED, PURPLE, YELLOW",
      "RED, YELLOW, BLUE",
      "BROWN, GREEN, BROWN"
    ],
    "correctAnswer": "RED, YELLOW, BLUE"
  },
  {
    "question": "What is the smallest country in the world by area?",
    "options": [
      "VATICAN CITY",
      "NEW YORK",
      "MEXICO CITY",
      "TEXAS"
    ],
    "correctAnswer": "VATICAN CITY"
  },
  {
    "question": "Who painted the Mona Lisa?",
    "options": [
      "PABLO PICASSO",
      "MICHELANGELO",
      "LEONARDO DA VINCI",
      "VAN GOGH"
    ],
    "correctAnswer": "LEONARDO DA VINCI"
  },
  {
    "question": "Who is known as the “Father of Modern Physics”?",
    "options": [
      "ISAAC NEWTON",
      "NIKOLA TESLA",
      "ALBERT EINSTEIN",
      "THOMAS EDISON"
    ],
    "correctAnswer": "ALBERT EINSTEIN"
  },
  {
    "question": "Which planet is known as the Red Planet?",
    "options": [
      "MARS",
      "MERCURY",
      "JUPITER",
      "EARTH"
    ],
    "correctAnswer": "MARS"
  },
  {
    "question": "In what year did the Titanic sink?",
    "options": [
      "1910",
      "1912",
      "1945",
      "1911"
    ],
    "correctAnswer": "1912"
  },
  {
    "question": "What is the hardest natural substance on Earth?",
    "options": [
      "GRAPHITE",
      "DIAMOND",
      "STEEL",
      "TITANIUM"
    ],
    "correctAnswer": "DIAMOND"
  },
  {
    "question": "How many bones are in the adult human body?",
    "options": [
      "206",
      "212",
      "208",
      "230"
    ],
    "correctAnswer": "206"
  },
  {
    "question": "Which is the longest river in the world?",
    "options": [
      "THE NILE",
      "AMAZON",
      "CONGO",
      "DANUBE"
    ],
    "correctAnswer": "THE NILE"
  },
  {
    "question": "Who is known as the “King of Pop”?",
    "options": [
      "MICHAEL JACKSON",
      "TAYLOR SWIFT",
      "BILLIE EILISH",
      "BRUNO MARS"
    ],
    "correctAnswer": "MICHAEL JACKSON"
  },
  {
    "question": "In what year did YouTube launch?",
    "options": [
      "1999",
      "2003",
      "2007",
      "2010"
    ],
    "correctAnswer": "2007"
  },
  {
    "question": "Which animal is known as the “King of the Jungle”?",
    "options": [
      "HIPPO",
      "ELEPHANT",
      "LION",
      "GUERRILA"
    ],
    "correctAnswer": "LION"
  },
  {
    "question": "What do caterpillars turn into?",
    "options": [
      "MOTHS",
      "BUTTERFLIES",
      "BEES",
      "FLIES"
    ],
    "correctAnswer": "BUTTERFLIES"
  },
  {
    "question": "What’s the powerhouse of a living cell?",
    "options": [
      "MITOCHONDRIA",
      "NUCLEUS",
      "CYTOPLASM",
      "CHLOROPLASTS"
    ],
    "correctAnswer": "MITOCHONDRIA"
  },
  {
    "question": "Which scientist proposed the three laws of motion?",
    "options": [
      "ALBERT EINSTEIN",
      "THOMAS EDISON",
      "ISAAC NEWTON",
      "NIKOLA TESLA"
    ],
    "correctAnswer": "ISAAC NEWTON"
  },
  {
    "question": "What’s the process plants use to convert sunlight into food?",
    "options": [
      "PHOTOSYNTHESIS",
      "OSMOSIS",
      "CONDUCTION",
      "CONVECTION"
    ],
    "correctAnswer": "PHOTOSYNTHESIS"
  },
  {
    "question": "What is the only country that spans both Europe and Asia?",
    "options": [
      "RUSSIA",
      "GERMANY",
      "FINLAND",
      "CHINA"
    ],
    "correctAnswer": "RUSSIA"
  },
  {
    "question": "What gas do humans exhale that plants absorb?",
    "options": [
      "CARBON MONOXIDE",
      "NITROGEN",
      "CARBON DIOXIDE",
      "OXYGEN"
    ],
    "correctAnswer": "CARBON DIOXIDE"
  },
  {
    "question": "What’s the largest planet in our solar system?",
    "options": [
      "EARTH",
      "NEPTUNE",
      "VENUS",
      "JUPITER"
    ],
    "correctAnswer": "JUPITER"
  },
  {
    "question": "Which country’s parliament is called the Bundestag?",
    "options": [
      "GERMANY",
      "FINLAND",
      "BOLIVIA",
      "SLOVAKIA"
    ],
    "correctAnswer": "GERMANY"
  },
  {
    "question": "What is the fastest land animal in the world?",
    "options": [
      "TIGER",
      "PANTHER",
      "DEER",
      "CHEETAH"
    ],
    "correctAnswer": "CHEETAH"
  },
  {
    "question": "How many legs does a spider have?",
    "options": [
      "6",
      "8",
      "10",
      "4"
    ],
    "correctAnswer": "8"
  },
  {
    "question": "How many days does it take for the Earth to orbit the Sun?",
    "options": [
      "356",
      "360",
      "365",
      "345"
    ],
    "correctAnswer": "365"
  },
  {
    "question": "Who wrote the famous play \"Romeo and Juliet\"?",
    "options": [
      "LEONARDO DA VINCI",
      "WILLIAM SHAKESPEARE",
      "MICHEALANGELO",
      "CHARLES DICKENS"
    ],
    "correctAnswer": "WILLIAM SHAKESPEARE"
  },
  {
    "question": "What is the name of Harry Potter's owl?",
    "options": [
      "HEDWIG",
      "GEORGE",
      "RONNY",
      "HARRY"
    ],
    "correctAnswer": "HEDWIG"
  },
  {
    "question": "How many weeks are there in a year?",
    "options": [
      "47",
      "56",
      "52",
      "60"
    ],
    "correctAnswer": "52"
  },
  {
    "question": "GOOD LUCK! YOU WILL NEED ;)",
    "options": [
      "WTF?!",
      "OH, HELL NAH",
      "DON'T KNOW...",
      "SERIOUSLY??"
    ],
    "correctAnswer": "WTF?!"
  },
  {
    "question": "Which country is known as the Land of the Rising Sun?",
    "options": [
      "CHINA",
      "THAILAND",
      "ALASKA",
      "JAPAN"
    ],
    "correctAnswer": "JAPAN"
  },
  {
    "question": "What is the currency of the United Kingdom?",
    "options": [
      "DOLLAR ($)",
      "EURO (€)",
      "POUND STERLING (£)",
      "RUBLE"
    ],
    "correctAnswer": "POUND STERLING (£)"
  },
  {
    "question": "What is the most abundant gas in Earth’s atmosphere?",
    "options": [
      "ARGON",
      "NITROGEN",
      "OXYGEN",
      "CARBON DIOXIDE"
    ],
    "correctAnswer": "NITROGEN"
  },
  {
    "question": "What is the largest island in the world?",
    "options": [
      "GREENLAND",
      "ICELAND",
      "HAWAII",
      "MARSHALL ISLANDS"
    ],
    "correctAnswer": "GREENLAND"
  },
  {
    "question": "What is the deepest point in the world’s oceans?",
    "options": [
      "BERMUDA TRIANGLE",
      "MARIANA TRENCH",
      "POINT BLUE",
      "POINT NEMO"
    ],
    "correctAnswer": "MARIANA TRENCH"
  },
  {
    "question": "Who played the role of Tony Stark in the Marvel movies?",
    "options": [
      "ROBERT DOWNEY .JR",
      "SAMUEL L JACKSON",
      "CHRIS EVANS",
      "CHRIS HEMSWORTH"
    ],
    "correctAnswer": "ROBERT DOWNEY .JR"
  },
  {
    "question": "WHAT IS THE SQUARE ROOT OF 144",
    "options": [
      "12",
      "16",
      "8",
      "18"
    ],
    "correctAnswer": "12"
  },
  {
    "question": "Which organ in the body produces insulin?",
    "options": [
      "PANCREAS",
      "LIVER",
      "SMALL INTESTINES",
      "HEART"
    ],
    "correctAnswer": "PANCREAS"
  },
  {
    "question": "What is the world’s largest internal organ?",
    "options": [
      "LUNGS",
      "LARGE INTESTINES",
      "SPLEEN",
      "LIVER"
    ],
    "correctAnswer": "LIVER"
  },
  {
    "question": "What is the only food that never spoils?",
    "options": [
      "HONEY",
      "JAM",
      "ONION",
      "GARLIC"
    ],
    "correctAnswer": "HONEY"
  },
  {
    "question": "What connects muscles to bones?",
    "options": [
      "LIGAMENTS",
      "TENDONS",
      "BLOOD VESSLES",
      "SKIN"
    ],
    "correctAnswer": "TENDONS"
  },
  {
    "question": "What is the hottest planet in our solar system?",
    "options": [
      "MERCURY",
      "MARS",
      "VENUS",
      "SUN"
    ],
    "correctAnswer": "VENUS"
  },
  {
    "question": "True or false: Animal cells contain chloroplasts.",
    "options": [
      "TRUE",
      "FALSE"
    ],
    "correctAnswer": "FALSE"
  },
  {
    "question": "What is the term for the change of a solid directly into a gas?",
    "options": [
      "SUBLIMATION",
      "CONDENSATION",
      "CONVECTION",
      "REFRACTION"
    ],
    "correctAnswer": "SUBLIMATION"
  },
  {
    "question": "What is the rarest naturally occurring element on Earth?",
    "options": [
      "DIAMOND",
      "PLATINUM",
      "ASTATINE",
      "RUBY"
    ],
    "correctAnswer": "ASTATINE"
  },
  {
    "question": "What is the process by which species adapt and change over generations?",
    "options": [
      "REVOLUTION",
      "MATURITY",
      "EVOLUTION",
      "ADAPTION"
    ],
    "correctAnswer": "EVOLUTION"
  },
  {
    "question": "What is the largest land animal on Earth?",
    "options": [
      "AFRICAN ELEPHANT",
      "RHINO",
      "HIPPO",
      "GIRRAFFE"
    ],
    "correctAnswer": "AFRICAN ELEPHANT"
  },
  {
    "question": "What animal can regenerate its lost limbs?",
    "options": [
      "LIZARDS",
      "RATS",
      "JELLYFISH",
      "STARFISH"
    ],
    "correctAnswer": "STARFISH"
  },
  {
    "question": "In what year did the first manned moon landing occur?",
    "options": [
      "1972",
      "1969",
      "1967",
      "1975"
    ],
    "correctAnswer": "1969"
  },
  {
    "question": "What is the speed of light?",
    "options": [
      "INFINITE",
      "APPROX. 350,000 KM/s",
      "APPROX. 300,000 KM/s",
      "APPROX. 530,000 KM/s"
    ],
    "correctAnswer": "APPROX. 300,000 KM/s"
  },
  {
    "question": "Which planet has the most moons?",
    "options": [
      "JUPITER",
      "EARTH",
      "NEPTUNE",
      "SATURN"
    ],
    "correctAnswer": "SATURN"
  },
  {
    "question": "How many elements are there in the periodic table?",
    "options": [
      "118",
      "112",
      "116",
      "120"
    ],
    "correctAnswer": "118"
  },
  {
    "question": "What is the center of an atom called?",
    "options": [
      "PROTON",
      "NEUTRON",
      "NUCLEUS",
      "ELECTRON"
    ],
    "correctAnswer": "NUCLEUS"
  },
  {
    "question": "Who was the first President of the United States?",
    "options": [
      "JOHN ADAMS",
      "THOMAS JEFFERSON",
      "JAMES MADISON",
      "GEORGE WASHINGTON"
    ],
    "correctAnswer": "GEORGE WASHINGTON"
  },
  {
    "question": "In which year did the First World War end?",
    "options": [
      "1920",
      "1918",
      "1945",
      "1939"
    ],
    "correctAnswer": "1918"
  },
  {
    "question": "What is the largest bird in the world?",
    "options": [
      "OSTRICH",
      "EMU",
      "BALD EAGLE",
      "HAWK"
    ],
    "correctAnswer": "OSTRICH"
  },
  {
    "question": "What is the chemical symbol for cobalt?",
    "options": [
      "C",
      "AU",
      "CO",
      "k"
    ],
    "correctAnswer": "CO"
  },
  {
    "question": "What is the only country that borders the United Kingdom?",
    "options": [
      "WALES",
      "FRANCE",
      "SCOTLAND",
      "IRELAND"
    ],
    "correctAnswer": "IRELAND"
  },
  {
    "question": "What sport did David Beckham play?",
    "options": [
      "FOOTBALL",
      "TENNIS",
      "RUGBY",
      "BADMINTON"
    ],
    "correctAnswer": "FOOTBALL"
  },
  {
    "question": "Which element has the chemical symbol Fe?",
    "options": [
      "POTTASIUM",
      "IRON",
      "INDIUM",
      "ZINC"
    ],
    "correctAnswer": "IRON"
  },
  {
    "question": "How many sides does a decagon have?",
    "options": [
      "10",
      "12",
      "8",
      "14"
    ],
    "correctAnswer": "10"
  },
  {
    "question": "What is acrophobia a fear of?",
    "options": [
      "DARKNESS",
      "TIGHT SPACES",
      "HEIGHTS",
      "LONG WORDS"
    ],
    "correctAnswer": "HEIGHTS"
  },
  {
    "question": "Who was the first Roman Emperor?",
    "options": [
      "COMMODUS",
      "JULIUS CAESAR",
      "AUGUSTUS CAESAR",
      "MARCUS AURELIUS"
    ],
    "correctAnswer": "AUGUSTUS CAESAR"
  },
  {
    "question": "What is the cube root of 64?",
    "options": [
      "6",
      "4",
      "8",
      "12"
    ],
    "correctAnswer": "4"
  },
  {
    "question": "What is the cube root of 125?",
    "options": [
      "6",
      "4",
      "5",
      "12"
    ],
    "correctAnswer": "5"
  },
  {
    "question": "The largest hot desert in the world is the Sahara Desert.",
    "options": [
      "TRUE",
      "FALSE"
    ],
    "correctAnswer": "TRUE"
  },
  {
    "question": "Cleopatra was the last Pharaoh of Ancient Egypt.",
    "options": [
      "TRUE",
      "FALSE"
    ],
    "correctAnswer": "TRUE"
  },
  {
    "question": "The symbol for the chemical element gold is Gd.",
    "options": [
      "TRUE",
      "FALSE"
    ],
    "correctAnswer": "FALSE"
  },
  {
    "question": "DNA stands for Deoxyribonucleic Acid.",
    "options": [
      "TRUE",
      "FALSE"
    ],
    "correctAnswer": "TRUE"
  },
  {
    "question": "What is the name of the first man to walk on the moon?",
    "options": [
      "CHARLES DUKE",
      "NEIL ARMSTRONG",
      "EUGENE CERNAN",
      "ALAN BEAN"
    ],
    "correctAnswer": "NEIL ARMSTRONG"
  },
  {
    "question": "What is the capital city of Russia?",
    "options": [
      "ST. PETERSBURG",
      "NOVOSIBIRSK",
      "MOSCOW",
      "VLADIVOSTOK"
    ],
    "correctAnswer": "MOSCOW"
  },
  {
    "question": "Which vegetable is known for making people cry when chopped?",
    "options": [
      "GARLIC",
      "ONION",
      "LEEKS",
      "CHIVES"
    ],
    "correctAnswer": "ONION"
  },
  {
    "question": "Sound travels faster than light.",
    "options": [
      "TRUE",
      "FALSE"
    ],
    "correctAnswer": "FALSE"
  },
  {
    "question": "Lightning is hotter than the surface of the sun.",
    "options": [
      "TRUE",
      "FALSE"
    ],
    "correctAnswer": "TRUE"
  },
  {
    "question": "The perimeter of a shape is defined as the total length of its boundary.",
    "options": [
      "TRUE",
      "FALSE"
    ],
    "correctAnswer": "TRUE"
  },
  {
    "question": "If a centimetre equates to roughly 0.4 inches, how many inches is 10cm?",
    "options": [
      "6",
      "4",
      "2",
      "8"
    ],
    "correctAnswer": "4"
  },
  {
    "question": "How many seconds are there in 5 minutes?",
    "options": [
      "300s",
      "280s",
      "350s",
      "400s"
    ],
    "correctAnswer": "300s"
  },
  {
    "question": "Who is the main character of the \"Breaking Bad\" series?",
    "options": [
      "JESSE PINKMAN",
      "WALTER WHITE",
      "GUS FRING",
      "SAUL GOODMAN"
    ],
    "correctAnswer": "WALTER WHITE"
  },
  {
    "question": "How many Pyramids of Giza were made?",
    "options": [
      "4",
      "2",
      "3",
      "2"
    ],
    "correctAnswer": "3"
  },
  {
    "question": "Which city is the biggest in the world?",
    "options": [
      "TOKYO",
      "SHANGHAI",
      "MOSCOW",
      "ISTANBUL"
    ],
    "correctAnswer": "TOKYO"
  },
  {
    "question": "Can you solve: 8÷2×(2+4)",
    "options": [
      "22",
      "18",
      "24",
      "16"
    ],
    "correctAnswer": "24"
  },
  {
    "question": "????????????",
    "options": [
      "PICK ME",
      "NOO! PICK ME",
      "I'M THE ONE YOU WANT",
      "AM I INVISIBLE?"
    ],
    "correctAnswer": "PICK ME"
  },
  {
    "question": "Work out: 5×5×4÷2-30",
    "options": [
      "20",
      "50",
      "30",
      "60"
    ],
    "correctAnswer": "20"
  },
  {
    "question": "What is the color of an emerald?",
    "options": [
      "RED",
      "GREEN",
      "TRANSPARENT",
      "BLUE"
    ],
    "correctAnswer": "GREEN"
  },
  {
    "question": "In what year was the Internet opened to the public?",
    "options": [
      "1987",
      "1993",
      "1990",
      "1991"
    ],
    "correctAnswer": "1993"
  },
  {
    "question": "When did Facebook first launch?",
    "options": [
      "2006",
      "2004",
      "2000",
      "1999"
    ],
    "correctAnswer": "2004"
  },
  {
    "question": "In what year did World War II officially end?",
    "options": [
      "1940",
      "1918",
      "1942",
      "1945"
    ],
    "correctAnswer": "1945"
  },
  {
    "question": "How many sides does a octagon have?",
    "options": [
      "6",
      "7",
      "8",
      "12"
    ],
    "correctAnswer": "8"
  },
  {
    "question": "What empire did Turkey belong to during WWI?",
    "options": [
      "ROMAN EMPIRE",
      "PRUSSIAN EMPIRE",
      "BRITISH EMPIRE",
      "OTTOMAN EMPIRE"
    ],
    "correctAnswer": "OTTOMAN EMPIRE"
  },
  {
    "question": "Where did the Aztec civilization originate from?",
    "options": [
      "MEXICO",
      "BRAZIL",
      "GUATEMALA",
      "EGYPT"
    ],
    "correctAnswer": "MEXICO"
  },
  {
    "question": "What is the capital city of Scotland?",
    "options": [
      "EDINBURGH",
      "GLASGOW",
      "ABERDEEN"
    ],
    "correctAnswer": "GLASGOW"
  },
  {
    "question": "In what year was the first iPhone released?",
    "options": [
      "2008",
      "2007",
      "2005",
      "2000"
    ],
    "correctAnswer": "2007"
  },
  {
    "question": "What is the name of the first MCU movie released in 2008?",
    "options": [
      "CAPTAIN AMERICA: THE FIRST AVENGER",
      "THOR",
      "IRON MAN",
      "HULK"
    ],
    "correctAnswer": "CAPTAIN AMERICA: THE FIRST AVENGER"
  },
  {
    "question": "WHAT IS THE CUBE ROOT OF 1000?",
    "options": [
      "20",
      "25",
      "5",
      "10"
    ],
    "correctAnswer": "10"
  },
  {
    "question": "Who invented the telephone?",
    "options": [
      "ALEXANDER GRAHAM BELL",
      "Nikola Tesla",
      "Thomas Edison",
      "Isaac Newton"
    ],
    "correctAnswer": "ALEXANDER GRAHAM BELL"
  },
  {
    "question": "What political ideology did the Soviet Union follow?",
    "options": [
      "Capitalism",
      "Communism",
      "Socialism",
      "Monarchy"
    ],
    "correctAnswer": "Communism"
  },
  {
    "question": "What city was once called Byzantium?",
    "options": [
      "Athens",
      "Istanbul",
      "Rome",
      "Alexandria"
    ],
    "correctAnswer": "Istanbul"
  },
  {
    "question": "What country was once known as Persia?",
    "options": [
      "Egypt",
      "Turkey",
      "Iraq",
      "Iran"
    ],
    "correctAnswer": "Iran"
  },
  {
    "question": "What is the chemical symbol for water?",
    "options": [
      "O2",
      "H2O",
      "CO2",
      "O3"
    ],
    "correctAnswer": "H2O"
  },
  {
    "question": "What type of rock is formed from volcanic activity?",
    "options": [
      "Sedimentary",
      "Metamorphic",
      "Igneous",
      "Limestone"
    ],
    "correctAnswer": "Igneous"
  },
  {
    "question": "[ Developer ]: Hello ;) if you found this well done. Try out the code | 8181 | in the code console ;)",
    "options": [
      "CONTINUE"
    ],
    "correctAnswer": "CONTINUE"
  },
  {
    "question": "WHAT IS 30% OF 100?",
    "options": [
      "30",
      "20",
      "15",
      "10"
    ],
    "correctAnswer": "30"
  },
  {
    "question": "WHAT IS 35% OF 1000?",
    "options": [
      "250",
      "200",
      "350",
      "300"
    ],
    "correctAnswer": "350"
  },
  {
    "question": "HOW MANY COLLECTION POINTS EXIST IN THE FARM TABLES?",
    "options": [
      "8",
      "7",
      "6"
    ],
    "correctAnswer": "6"
  },
  {
    "question": "How many legs does a centipede generally have?",
    "options": [
      "10",
      "100",
      "1000",
      "50"
    ],
    "correctAnswer": "100"
  },
  {
    "question": "What is the square root of 400?",
    "options": [
      "30",
      "20",
      "40",
      "60"
    ],
    "correctAnswer": "20"
  },
  {
    "question": "How many years does a century consist of?",
    "options": [
      "100",
      "50",
      "1000",
      "50"
    ],
    "correctAnswer": "100"
  },
  {
    "question": "How many years does a millenium consist of?",
    "options": [
      "500",
      "100",
      "200",
      "1000"
    ],
    "correctAnswer": "1000"
  },
  {
    "question": "What is 1/2 (half) of 7.5?",
    "options": [
      "3.5",
      "3.65",
      "3.75",
      "2.75"
    ],
    "correctAnswer": "3.75"
  },
  {
    "question": "What is considered to be a computer's brain?",
    "options": [
      "GPU",
      "CPU",
      "RAM",
      "HDD"
    ],
    "correctAnswer": "CPU"
  },
  {
    "question": "What is the closest planet to Earth?",
    "options": [
      "MARS",
      "SATURN",
      "MERCURY",
      "VENUS"
    ],
    "correctAnswer": "VENUS"
  },
  {
    "question": "How many inches are in a foot?",
    "options": [
      "12",
      "8",
      "6",
      "14"
    ],
    "correctAnswer": "12"
  },
  {
    "question": "Convert 65cm to millimetres",
    "options": [
      "600mm",
      "650mm",
      "500mm"
    ],
    "correctAnswer": "650mm"
  },
  {
    "question": "How many days are in 3 fortnights?",
    "options": [
      "38",
      "40",
      "42",
      "45"
    ],
    "correctAnswer": "42"
  },
  {
    "question": "Work out 20÷10×5−15",
    "options": [
      "5",
      "-5",
      "15",
      "10"
    ],
    "correctAnswer": "-5"
  },
  {
    "question": "What is 1/4 (1 quarter) of 1,500?",
    "options": [
      "500",
      "750",
      "375",
      "350"
    ],
    "correctAnswer": "375"
  },
  {
    "question": "How many hours are there 6 days?",
    "options": [
      "128",
      "124",
      "112",
      "144"
    ],
    "correctAnswer": "144"
  },
  {
    "question": "How many minutes are there in 12 hours?",
    "options": [
      "680mins",
      "720mins",
      "500mins",
      "480mins"
    ],
    "correctAnswer": "720mins"
  },
  {
    "question": "Which is the most dense metal on Earth?",
    "options": [
      "STEEL",
      "TUNGSTEN",
      "TITANIUM",
      "DIAMOND"
    ],
    "correctAnswer": "TUNGSTEN"
  },
  {
    "question": "How many stars does the USA flag contain?",
    "options": [
      "50",
      "52",
      "48",
      "54"
    ],
    "correctAnswer": "50"
  },
  {
    "question": "Which element (metal) never rusts?",
    "options": [
      "IRON",
      "COPPER",
      "TIN",
      "PLATINUM"
    ],
    "correctAnswer": "PLATINUM"
  },
  {
    "question": "What is 5:30pm in the 24-hour format?",
    "options": [
      "17:30pm",
      "15:30pm",
      "17:00pm"
    ],
    "correctAnswer": "17:30pm"
  },
  {
    "question": "Which of the following can provide interactivity to a web page?",
    "options": [
      "HTML",
      "CSS",
      "SQL",
      "JAVASCRIPT"
    ],
    "correctAnswer": "JAVASCRIPT"
  },
  {
    "question": "The perimeter of a circle is known as the circumference.",
    "options": [
      "TRUE",
      "FALSE"
    ],
    "correctAnswer": "TRUE"
  },
  {
    "question": "What is Superman's true name?",
    "options": [
      "CLARK KENT",
      "JOR EL",
      "BRUCE WAYNE",
      "KAL EL"
    ],
    "correctAnswer": "KAL EL"
  },
  {
    "question": "Who is the main protagonist in “The Lord of the Rings”?",
    "options": [
      "FRODO BAGGINS",
      "HARRY POTTER",
      "GANDALF",
      "SAURON"
    ],
    "correctAnswer": "FRODO BAGGINS"
  },
  {
    "question": "Who played the role of Hermione Granger in the Harry Potter film series?",
    "options": [
      "Emma Roberts",
      "Emma Watson",
      "Emma Stone"
    ],
    "correctAnswer": "Emma Watson"
  },
  {
    "question": "In which country would you find the Great Wall?",
    "options": [
      "China",
      "United States",
      "India",
      "japan"
    ],
    "correctAnswer": "China"
  },
  {
    "question": "What company makes the Xperia model of smartphone?",
    "options": [
      "SAMSUNG",
      "SONY",
      "NOKIA"
    ],
    "correctAnswer": "SONY"
  },
  {
    "question": "Where was the first example of paper money used?",
    "options": [
      "CHINA",
      "TURKEY",
      "GREECE"
    ],
    "correctAnswer": "CHINA"
  },
  {
    "question": "What Italian city is famous for its system of canals?",
    "options": [
      "ROME",
      "NAPLES",
      "VENICE"
    ],
    "correctAnswer": "VENICE"
  },
  {
    "question": "What is the strongest muscle in the human body?",
    "options": [
      "JAW",
      "HEART",
      "GLUTES",
      "BICEPS"
    ],
    "correctAnswer": "JAW"
  },
  {
    "question": "Where was tea invented?",
    "options": [
      "USA",
      "CHINA",
      "ENGLAND"
    ],
    "correctAnswer": "CHINA"
  },
  {
    "question": "WORK OUT 70 - 175",
    "options": [
      "-70",
      "-75",
      "-100"
    ],
    "correctAnswer": "-100"
  },
  {
    "question": "The fear of insects is known as what phobia?",
    "options": [
      "Entomophobia",
      "Chilopodophobia",
      "Arachnophobia",
      "Ailurophobia"
    ],
    "correctAnswer": "Entomophobia"
  },
  {
    "question": "What is the largest desert in the world?",
    "options": [
      "Sahara",
      "Antarctica",
      "Arctic",
      "Arabian"
    ],
    "correctAnswer": "Antarctica"
  },
  {
    "question": "How many colors are in the rainbow?",
    "options": [
      "6",
      "7",
      "8",
      "9"
    ],
    "correctAnswer": "7"
  },
  {
    "question": "Who was the longest raining monarch in British history?",
    "options": [
      "Queen Victoria",
      "Queen Elizabeth II",
      "King Philip II"
    ],
    "correctAnswer": "Queen Elizabeth II"
  },
  {
    "question": "I don't know...",
    "options": [
      "$$$$$$",
      "$$$$$$",
      "$$$$$$",
      "$$$$$$"
    ],
    "correctAnswer": "$$$$$$"
  },
  {
    "question": "What makes up 3 dimensions?",
    "options": [
      "X and Y",
      "X, Y and Z",
      "X, Y and Yaw"
    ],
    "correctAnswer": "X, Y and Z"
  },
  {
    "question": "How many zeros does 1 trillion consist of?",
    "options": [
      "6",
      "7",
      "12",
      "9"
    ],
    "correctAnswer": "12"
  },
  {
    "question": "How many centuries are in 2 millenia?",
    "options": [
      "20",
      "10",
      "40"
    ],
    "correctAnswer": "20"
  },
  {
    "question": "What percentage of the Earth's surface is covered by oceans?",
    "options": [
      "80%",
      "95%",
      "Approximately 71%",
      "99%"
    ],
    "correctAnswer": "Approximately 71%"
  },
  {
    "question": "What's the only fruit with outside seeds?",
    "options": [
      "Strawberry",
      "Raspberry",
      "Kiwi",
      "Watermelon"
    ],
    "correctAnswer": "Strawberry"
  },
  {
    "question": "How many hearts does an octopus have?",
    "options": [
      "1",
      "2",
      "3"
    ],
    "correctAnswer": "3"
  },
  {
    "question": "What color cards are used by referees in soccer?",
    "options": [
      "Blue & Red",
      "Green & Yellow",
      "Yellow & Red"
    ],
    "correctAnswer": "Yellow & Red"
  },
  {
    "question": "How many cards are in a standard deck of playing cards?",
    "options": [
      "50",
      "48",
      "52"
    ],
    "correctAnswer": "52"
  },
  {
    "question": "What is the smallest unit of matter?",
    "options": [
      "Atom",
      "Cell",
      "Electron",
      "Neutron"
    ],
    "correctAnswer": "Atom"
  },
  {
    "question": "What is the name of the region at the centre of a black hole?",
    "options": [
      "Singularity",
      "Void",
      "Wormhole",
      "Eternity"
    ],
    "correctAnswer": "Singularity"
  },
  {
    "question": "Hg is chemical symbol for which element?",
    "options": [
      "Mercury",
      "Helium",
      "Hydrogen",
      "Argon"
    ],
    "correctAnswer": "Mercury"
  },
  {
    "question": "Which country is Prague located in?",
    "options": [
      "Croatia",
      "Slovakia",
      "Czech Republic"
    ],
    "correctAnswer": "Czech Republic"
  },
  {
    "question": "Google Chrome, Safari, Firefox, and Explorer are different types of what?",
    "options": [
      "Code Editors",
      "Web Browsers",
      "Websites"
    ],
    "correctAnswer": "Web Browsers"
  },
  {
    "question": "What is the chemical symbol for Potassium?",
    "options": [
      "K",
      "Hg",
      "Au",
      "CO"
    ],
    "correctAnswer": "K"
  },
  {
    "question": "How long is an eon in the context of geology?",
    "options": [
      "1 Million Years",
      "1 Billion Years",
      "1000 Years",
      "100 Years"
    ],
    "correctAnswer": "1 Billion Years"
  },
  {
    "question": "What does \"HTTP\" stand for?",
    "options": [
      "HyperText Translation Protocol",
      "HyperText Transfer Partition",
      "HyperText Transfer Protocol"
    ],
    "correctAnswer": "HyperText Transfer Protocol"
  },
  {
    "question": "Which subatomic particle has no electric charge?",
    "options": [
      "Neutron",
      "Proton",
      "Electron",
      "Nucleus"
    ],
    "correctAnswer": "Neutron"
  },
  {
    "question": "How many ribs are in a human body?",
    "options": [
      "18",
      "20",
      "22",
      "24"
    ],
    "correctAnswer": "24"
  },
  {
    "question": "Which animal has rectangular pupils?",
    "options": [
      "Cat",
      "Horse",
      "Goat",
      "Rabbit"
    ],
    "correctAnswer": "Goat"
  },
  {
    "question": "A group of crows is called a…",
    "options": [
      "Murder",
      "Gang",
      "Pack",
      "Midst"
    ],
    "correctAnswer": "Murder"
  },
  {
    "question": "Which body part has unique prints in addition to your fingers?",
    "options": [
      "Nose",
      "Elbow",
      "Ear",
      "Togue"
    ],
    "correctAnswer": "Togue"
  },
  {
    "question": "How many Infinity Stones are there in the Marvel Cinematic Universe?",
    "options": [
      "4",
      "5",
      "6",
      "7"
    ],
    "correctAnswer": "6"
  },
  {
    "question": "What is the name of the pub in The Simpsons?",
    "options": [
      "The Rusty Nail",
      "Moe's Tavern",
      "The Springfield Arms"
    ],
    "correctAnswer": "Moe's Tavern"
  },
  {
    "question": "How many chromosomes do humans have?",
    "options": [
      "22",
      "46",
      "44",
      "36"
    ],
    "correctAnswer": "46"
  },
  {
    "question": "What is the boiling point of water at sea level in Celsius?",
    "options": [
      "90 degrees",
      "95 degrees",
      "100 degrees"
    ],
    "correctAnswer": null
  },
  {
    "question": "What is the smallest planet in our solar system?",
    "options": [
      "Mercury",
      "Venus",
      "Earth",
      "Uranus"
    ],
    "correctAnswer": "Mercury"
  },
  {
    "question": "How many teeth does an adult human have?",
    "options": [
      "28",
      "30",
      "32",
      "34"
    ],
    "correctAnswer": "32"
  },
  {
    "question": "What is the process by which water turns into vapor called?",
    "options": [
      "Condensation",
      "Sublimation",
      "Evaporation"
    ],
    "correctAnswer": "Evaporation"
  },
  {
    "question": "Which blood cells carry oxygen around the body?",
    "options": [
      "Platelets",
      "Red blood cells",
      "White blood cells",
      "Plasma"
    ],
    "correctAnswer": "Red blood cells"
  },
  {
    "question": "What is the unit used to measure frequency?",
    "options": [
      "Hertz",
      "Volt",
      "Watt"
    ],
    "correctAnswer": "Hertz"
  },
  {
    "question": "What is the capital city of Japan?",
    "options": [
      "Tokyo",
      "Osaka",
      "Kyoto"
    ],
    "correctAnswer": "Tokyo"
  },
  {
    "question": "Which gas do humans need to breathe in order to survive?",
    "options": [
      "Oxygen",
      "Carbon Dioxide",
      "Nitrogen",
      "Argon"
    ],
    "correctAnswer": "Oxygen"
  },
  {
    "question": "Which animal is the tallest on Earth?",
    "options": [
      "Camel",
      "Giraffe",
      "Elephant"
    ],
    "correctAnswer": "Camel"
  },
  {
    "question": "What color do you get by mixing blue and yellow paint?",
    "options": [
      "Green",
      "Red",
      "Blue"
    ],
    "correctAnswer": "Green"
  },
  {
    "question": "True or False: The Pacific Ocean is larger than the Atlantic Ocean.",
    "options": [
      "True",
      "False"
    ],
    "correctAnswer": "True"
  },
  {
    "question": "Which instrument has 88 keys?",
    "options": [
      "Piano",
      "Violin",
      "Guitar"
    ],
    "correctAnswer": "Piano"
  },
  {
    "question": "How many sides does a hexagon have?",
    "options": [
      "6",
      "7",
      "8"
    ],
    "correctAnswer": "6"
  },
  {
    "question": "Which country is home to the pyramids of Giza?",
    "options": [
      "Greece",
      "Egypt",
      "Rome"
    ],
    "correctAnswer": "Egypt"
  },
  {
    "question": "What is the freezing point of water in Celsius?",
    "options": [
      "0 degrees",
      "100 degrees",
      "-10 degrees"
    ],
    "correctAnswer": "0 degrees"
  },
  {
    "question": "Which animal can live both on land and in water?",
    "options": [
      "Frog",
      "Eagle",
      "Shark"
    ],
    "correctAnswer": "Frog"
  },
  {
    "question": "What do bees collect from flowers to make honey?",
    "options": [
      "Nectar",
      "Pollen",
      "Water"
    ],
    "correctAnswer": "Nectar"
  },
  {
    "question": "What is the longest bone in the human body?",
    "options": [
      "Humerus",
      "Tibia",
      "Femur"
    ],
    "correctAnswer": "Femur"
  },
  {
    "question": "True or False: A square has four equal sides.",
    "options": [
      "True",
      "False"
    ],
    "correctAnswer": "True"
  },
  {
    "question": "Which planet is famous for its rings?",
    "options": [
      "Saturn",
      "Jupiter",
      "Uranus"
    ],
    "correctAnswer": "Saturn"
  }
];
