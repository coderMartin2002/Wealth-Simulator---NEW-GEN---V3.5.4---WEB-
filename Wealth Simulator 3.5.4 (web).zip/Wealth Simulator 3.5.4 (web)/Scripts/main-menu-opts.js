let guessing_game_opt_btn = document.getElementById("digit-guessing-game-menu-opt");
let fund_farms_opt_btn = document.getElementById("fund-farms-menu-opt");
let gambling_hub_menu_opt_btn = document.getElementById("gambling-hub-menu-opt");
let upgrades_menu_opt_btn = document.getElementById("upgrades-hub-menu-opt");
let store_menu_opt_btn = document.getElementById("store-menu-opt");
let progress_menu_opt_btn = document.getElementById("progress-menu-opt");
let settings_menu_opt_btn = document.getElementById("settings-menu-opt");
let inventory_menu_opt_btn = document.getElementById("inventory-menu-opt");
let console_ui_menu_opt = document.getElementById("console-ui-btn");
let upgrades_hub_ui = document.getElementById("upgrades-hub-ui");
let settings_menu_opt = document.getElementById("settings-menu-opt");
let close_guessing_game_btn = document.getElementById("close-guessing-game-ui");
let close_fund_farms_btn = document.getElementById("close-fund-farms-ui");
let close_upgrades_hub_ui_opt = document.getElementById("close-upgrades-hub-ui-btn");
let close_store_ui_opt = document.getElementById("close-store-ui-btn");
let close_inventory_ui_opt = document.getElementById("close-inventory-ui-btn");
let close_progress_ui_opt = document.getElementById("close-progress-ui-btn");
let close_gambling_hub_ui_opt = document.getElementById("close-gambling-hub-ui-btn");
let close_console_ui_opt = document.getElementById("close-console-ui-btn");
let close_settings_ui_opt = document.getElementById("close-settings-ui-btn");
let console_ui = document.getElementById("console-ui");
let settings_ui = document.getElementById("settings-ui");
let close_settings_ui_btn = document.getElementById("close-settings-ui-btn");

function UiClosure() {
    document.getElementById("settings-ui").style.display = "none";
    document.getElementById("fund-farms-ui").style.display = "none";
    document.getElementById("guessing-game-ui").style.display = "none";
    document.getElementById("upgrades-hub-ui").style.display = "none";
    document.getElementById("store-ui").style.display = "none";
    document.getElementById("inventory-ui").style.display = "none";
    document.getElementById("gambling-hub-ui").style.display = "none";
    document.getElementById("gambling-hub-ui-2").style.display = "none";
    document.getElementById("gambling-hub-ui-3").style.display = "none";
    document.getElementById("slot-selection-dialog-overlay").style.display = "none";
    document.getElementById("timed-dif-timer-mod-dialog-overlay").style.display = "none";
    document.getElementById("dif-info-panel").style.display = "none";
    document.getElementById("welcome-screen").style.display = "none";
    document.getElementById("booster-info-dialog-overlay").style.display = "none";
    document.getElementById("gambling-bet-dialog-overlay").style.display = "none";
    document.getElementById("gambling-bet-dialog-overlay-2").style.display = "none";
    document.getElementById("gambling-vip-dialog-overlay").style.display = "none";
    document.getElementById("gambling-vip-dialog-overlay-2").style.display = "none";
    document.getElementById("bank-hub-selection-dialog-overlay").style.display = "none";
    document.getElementById("auto-spin-countdown-dialog-overlay").style.display = "none";
    document.getElementById("15-reel-auto-spin-dialog-overlay").style.display = "none";
    document.getElementById("mystery-booster-dialog-overlay").style.display = "none";
    document.getElementById("bank-loans-ui").style.display = "none";
    match_boards_ui.style.display = "none";
    savings_hub_ui.style.display = "none";
    passive_income_details_dialog_overlay.style.display = "none";
    perks_station_ui.style.display = "none";
    trivia_hub_ui.style.display = "none";
    updates_hub_ui.style.display = "none";
    challenge_hub_ui.style.display = "none";
    console_ui.style.display = "none";
    mods_access_dialog_overlay.style.display = "none";
    mods_ui.style.display = "none";
    bank_hub_selection_dialog_overlay.style.display = "none";

    for (let i = 0; i < board_slot_income_upgrade_opts_storage.length; i++) { 
        board_slot_income_upgrade_opts_storage[i].disabled = false;
        board_slot_income_upgrade_opts_storage[i].style.opacity = "1";
        board_slot_income_upgrade_opts_storage[i].style.cursor = "pointer"; 
    }
    for (let i = 0; i < purchase_dialog_overlays_storage.length; i++) { purchase_dialog_overlays_storage[i].style.display = "none"; }
    if (auto_spin_2_active) { document.getElementById("auto-spin-countdown-dialog-overlay").style.display = "flex"; }
}

settings_menu_opt.onclick = function() { setTimeout(() => { settings_ui.style.display = "flex"; }, 250); UiClosure(); }
console_ui_menu_opt.onclick = function() { setTimeout(() => { console_ui.style.display = "flex"; }, 250); UiClosure(); }
upgrades_menu_opt_btn.onclick = function() { setTimeout(() => { upgrades_hub_ui.style.display = "flex"; }, 250); UiClosure(); }
store_menu_opt_btn.onclick = function() { setTimeout(() => { document.getElementById("store-ui").style.display = "flex"; }, 250); UiClosure(); }
inventory_menu_opt_btn.onclick = function() { setTimeout(() => { document.getElementById("inventory-ui").style.display = "flex"; }, 250); UiClosure(); }
progress_menu_opt_btn.onclick = function() { setTimeout(() => { document.getElementById("progress-dialog-overlay").style.display = "flex"; }, 250); UiClosure(); }

fund_farms_opt_btn.onclick = function() {
    setTimeout(() => { document.getElementById("fund-farms-ui").style.display = "flex"; }, 250);
    setTimeout(() => { document.getElementById("fund-farms-ui").style.opacity = "1"; }, 250)
    UiClosure();
}

guessing_game_opt_btn.onclick = function() {
    setTimeout(() => { document.getElementById("guessing-game-ui").style.display = "flex"; }, 250);
    setTimeout(() => { document.getElementById("guessing-game-ui").style.opacity = "1"; }, 250)
    UiClosure();
}

gambling_hub_menu_opt_btn.onclick = function() {
    setTimeout(() => { document.getElementById("slot-selection-dialog-overlay").style.display = "flex"; }, 250);
    setTimeout(() => { document.getElementById("gambling-hub-ui").style.opacity = "1"; }, 250)
    UiClosure();
}

document.getElementById("3-reel-slot-opt").onclick = function() { setTimeout(() => { 
    document.getElementById("gambling-hub-ui").style.display = "flex"; }, 250); UiClosure(); 
}

document.getElementById("15-reel-slot-opt").onclick = function() { setTimeout(() => { 
    document.getElementById("gambling-hub-ui-2").style.display = "flex"; }, 250); UiClosure(); 
    //if (auto_spin_2_active) { document.getElementById("auto-spin-countdown-dialog-overlay").style.display = "flex"; }
}

document.getElementById("mystery-picks-opt").onclick = function() {
    setTimeout(() => { document.getElementById("mystery-booster-dialog-overlay").style.display = "flex"; }, 250);
    UiClosure();
}

document.getElementById("close-slot-selection-overlay-btn").onclick = function() {
    document.getElementById("slot-selection-dialog-overlay").style.display = "none";
}

close_console_ui_opt.onclick = function() { console_ui.style.display = "none"; UiClosure(); }
close_inventory_ui_opt.onclick = function() { document.getElementById("inventory-ui").style.display = "none"; UiClosure(); }
close_store_ui_opt.onclick = function() { document.getElementById("store-ui").style.display = "none"; UiClosure(); }
close_progress_ui_opt.onclick = function() { document.getElementById("progress-dialog-overlay").style.display = "none"; UiClosure(); }

close_fund_farms_btn.onclick = function() {
    document.getElementById("fund-farms-ui").style.opacity = "0";
    setTimeout(() => { document.getElementById("fund-farms-ui").style.display = "none"; }, 500)
    UiClosure();
}

close_gambling_hub_ui_opt.onclick = function () {
    document.getElementById("gambling-hub-ui").style.opacity = "0";
    setTimeout(() => { document.getElementById("gambling-hub-ui").style.display = "none"; }, 500)
    UiClosure();
}

close_guessing_game_btn.onclick = function() {
    document.getElementById("guessing-game-ui").style.opacity = "0";
    setTimeout(() => { document.getElementById("guessing-game-ui").style.display = "none"; }, 500)
    UiClosure();
}

close_settings_ui_opt.onclick = function() {
    document.getElementById("settings-ui").style.display = "none";
    UiClosure();
}

close_upgrades_hub_ui_opt.onclick = function() {
    upgrades_hub_ui.style.display = "none";
    UiClosure();
}

close_inventory_ui_opt.onclick = function() { document.getElementById("inventory-ui").style.display = "none"; UiClosure(); }

close_store_ui_opt.onclick = function() { 
    document.getElementById("store-ui").style.display = "none";
    document.getElementById("store-ui-slot-board").style.display = "flex";
    document.getElementById("store-ui-slot-board-2").style.display = "none";
    document.getElementById("store-ui-slot-board-3").style.display = "none"; 
    UiClosure();
}

close_progress_ui_opt.onclick = function() { document.getElementById("progress-dialog-overlay").style.display = "none"; UiClosure(); }