let bet_2 = 1;
let cash_win_2 = 2;
let diamond_win_2 = 1;
let coin_win_2 = 1;
let coin_cluster_win = 3;

let jack_win_2 = 0.50;   // small win for three Jacks
let queen_win_2 = 0.50;  // medium win for three Queens
let king_win_2 = 1.00;   // larger win for three Kings
let ace_win_2 = 1.50;
let seven_win_2 = 10;      // jackpot win for three Sevens
let cherry_win_2 = 2;    // win for three Cherries

let triple_coins_probability = 30;
let free_spins_bonus_probability = 100; // FREE SPINS BONUS PROBABILITY (DEF 100)
let free_spins_bonus_spins = 0;

// BASE SYMBOL PROBABILITIES

let cash_2_probability = 12; // DEF 10
let coin_2_probability = 15; // DEF 15
let diamond_2_probability = 45; // DEF 50
let seven_probability = 999;
let cherry_probability = 20;

let jack_2_probability = 8;
let queen_2_probability = 8;
let king_2_probability = 10;
let ace_2_probability = 10;

let star_probability = 400;

let free_spins_3_reel_grant = 10;
let free_spins_4_reel_grant = 12;
let free_spins_5_reel_grant = 15;
let free_spins_6_reel_grant = 20;

let free_spins_granted = null;

let free_spins_bonus_active = false;
let free_spins_won_counter = 0;

let free_spins_bonus_cash_win_total = 0;
let free_spins_bonus_coin_win_total = 0;
let free_spins_bonus_diamond_win_total = 0;

let spin_btn_2 = document.getElementById("spin-btn-2");
let auto_spin_btn_2 = document.getElementById("auto-spin-2");
let set_custom_auto_spin_count_opt = document.getElementById("set-custom-auto-spin-count-opt");
let auto_spin_2_active = false;
let auto_spin_2_int;
let custom_auto_spin_count = 5;
let custom_auto_spin_count_limit = 0;
let spin_2_initiation_status;
let security_control_disable_int_2;
let stop_auto_spin_2_btn = document.getElementById("stop-auto-spin-2");
let bet_btn_2 = document.getElementById("bet-btn-2");
let max_bet_btn_2 = document.getElementById("max-bet-2");
let bet_selector_slider_2 = document.getElementById("bet-selector-slider-2");
let manual_auto_spin_count_slider = document.getElementById("auto-spin-count-selector-slider");
let bet_based_cash_win_2 = bet_2 * cash_win_2;
let bet_based_cash_win_output_2 = document.getElementById("bet-based-cash-win-output-2");
let bet_step_interval_opts_2 = [document.getElementById("2-step-2"), document.getElementById("5-step-2"), document.getElementById("10-step-2"), document.getElementById("20-step-2")];
let current_bet_output_2 = document.getElementById("current-bet-output-2");


let manual_bet_increment_btn_2 = document.getElementById("manual-bet-increment-opt-2");
let manual_bet_decrement_btn_2 = document.getElementById("manual-bet-decrement-opt-2");

let manual_auto_spin_count_increment = document.getElementById("manual-auto-spin-count-increment-opt");
let manual_auto_spin_count_decrement = document.getElementById("manual-auto-spin-count-decrement-opt");

let multi_reels_spin_int_max = 250; // DEF 200
let multi_reels_spin_int_min = 250; // DEF 160
let multi_reel_spin_time = 3700;

let column_sector_1_timeout = 500;
let column_sector_2_timeout = 1250;
let column_sector_3_timeout = 2000;
let column_sector_4_timeout = 2750;
let column_sector_5_timeout = 3500;

let column_sectors_reel_int = 150;

let high_roller_bets_storage_2 = [high_roller_250_bet_opt, high_roller_500_bet_opt, high_roller_1000_bet_opt, high_roller_2500_bet_opt, high_roller_5000_bet_opt, high_roller_10000_bet_opt];
let high_roller_2_active = false;
let high_roller_opt_2 = document.getElementById("vip-2");
let high_roller_disable_opt_2 = document.getElementById("disable-high-roller");

let multi_reel_slot_1 = document.getElementById("multi-gambling-slot-1");
let multi_reel_slot_2 = document.getElementById("multi-gambling-slot-2");
let multi_reel_slot_3 = document.getElementById("multi-gambling-slot-3");
let multi_reel_slot_4 = document.getElementById("multi-gambling-slot-4");
let multi_reel_slot_5 = document.getElementById("multi-gambling-slot-5");
let multi_reel_slot_6 = document.getElementById("multi-gambling-slot-6");
let multi_reel_slot_7 = document.getElementById("multi-gambling-slot-7");
let multi_reel_slot_8 = document.getElementById("multi-gambling-slot-8");
let multi_reel_slot_9 = document.getElementById("multi-gambling-slot-9");
let multi_reel_slot_10 = document.getElementById("multi-gambling-slot-10");
let multi_reel_slot_11 = document.getElementById("multi-gambling-slot-11");
let multi_reel_slot_12 = document.getElementById("multi-gambling-slot-12");
let multi_reel_slot_13 = document.getElementById("multi-gambling-slot-13");
let multi_reel_slot_14 = document.getElementById("multi-gambling-slot-14");
let multi_reel_slot_15 = document.getElementById("multi-gambling-slot-15");

// slot symbols imgs

let multi_slot_symbol_1 = document.getElementById("multi-slot-symbol-1");
let multi_slot_symbol_2 = document.getElementById("multi-slot-symbol-2");
let multi_slot_symbol_3 = document.getElementById("multi-slot-symbol-3");
let multi_slot_symbol_4 = document.getElementById("multi-slot-symbol-4");
let multi_slot_symbol_5 = document.getElementById("multi-slot-symbol-5");
let multi_slot_symbol_6 = document.getElementById("multi-slot-symbol-6");
let multi_slot_symbol_7 = document.getElementById("multi-slot-symbol-7");
let multi_slot_symbol_8 = document.getElementById("multi-slot-symbol-8");
let multi_slot_symbol_9 = document.getElementById("multi-slot-symbol-9");
let multi_slot_symbol_10 = document.getElementById("multi-slot-symbol-10");
let multi_slot_symbol_11 = document.getElementById("multi-slot-symbol-11");
let multi_slot_symbol_12 = document.getElementById("multi-slot-symbol-12");
let multi_slot_symbol_13 = document.getElementById("multi-slot-symbol-13");
let multi_slot_symbol_14 = document.getElementById("multi-slot-symbol-14");
let multi_slot_symbol_15 = document.getElementById("multi-slot-symbol-15");

// FINAL REEL OUTPUT ID's

let final_multi_slot_1_id = document.getElementById("multi-slot-symbol-1");
let final_multi_slot_2_id = document.getElementById("multi-slot-symbol-2");
let final_multi_slot_3_id = document.getElementById("multi-slot-symbol-3");
let final_multi_slot_4_id = document.getElementById("multi-slot-symbol-4");
let final_multi_slot_5_id = document.getElementById("multi-slot-symbol-5");
let final_multi_slot_6_id = document.getElementById("multi-slot-symbol-6");
let final_multi_slot_7_id = document.getElementById("multi-slot-symbol-7");
let final_multi_slot_8_id = document.getElementById("multi-slot-symbol-8");
let final_multi_slot_9_id = document.getElementById("multi-slot-symbol-9");
let final_multi_slot_10_id = document.getElementById("multi-slot-symbol-10");
let final_multi_slot_11_id = document.getElementById("multi-slot-symbol-11");
let final_multi_slot_12_id = document.getElementById("multi-slot-symbol-12");
let final_multi_slot_13_id = document.getElementById("multi-slot-symbol-13");
let final_multi_slot_14_id = document.getElementById("multi-slot-symbol-14");
let final_multi_slot_15_id = document.getElementById("multi-slot-symbol-15");

let multi_slot_1_int;
let multi_slot_2_int;
let multi_slot_3_int;
let multi_slot_4_int;
let multi_slot_5_int;
let multi_slot_6_int;
let multi_slot_7_int;
let multi_slot_8_int;
let multi_slot_9_int;
let multi_slot_10_int;
let multi_slot_11_int;
let multi_slot_12_int;
let multi_slot_13_int;
let multi_slot_14_int;
let multi_slot_15_int;

let high_roller_250_bet_opt_2 = document.getElementById("250-bet-2");
let high_roller_500_bet_opt_2 = document.getElementById("500-bet-2");
let high_roller_1000_bet_opt_2 = document.getElementById("1000-bet-2");
let high_roller_2500_bet_opt_2 = document.getElementById("2500-bet-2");
let high_roller_5000_bet_opt_2 = document.getElementById("5000-bet-2");
let high_roller_10000_bet_opt_2 = document.getElementById("10000-bet-2");
let high_roller_25000_bet_opt_2 = document.getElementById("25000-bet-2");
let high_roller_50000_bet_opt_2 = document.getElementById("50000-bet-2");
let high_roller_100000_bet_opt_2 = document.getElementById("100000-bet-2");
let high_roller_500000_bet_opt_2 = document.getElementById("500000-bet-2");
let high_roller_1000000_bet_opt_2 = document.getElementById("1000000-bet-2");
let high_roller_2500000_bet_opt_2 = document.getElementById("2500000-bet-2");
let high_roller_1000000000_bet_opt_2 = document.getElementById("1000000000-bet-2");

let bet_slider_step_refs_storage_2 = [document.getElementById('1-step-2'), document.getElementById('2-step-2'), document.getElementById('5-step-2'), document.getElementById('10-step-2'), document.getElementById('20-step-2')];
let final_multi_slot_id_storage_center_reels = [final_multi_slot_7_id, final_multi_slot_8_id, final_multi_slot_9_id];
let final_multi_slot_id_storage_surrounding_reels = [final_multi_slot_4_id, final_multi_slot_5_id, final_multi_slot_6_id, final_multi_slot_10_id, final_multi_slot_11_id, final_multi_slot_12_id];
let final_multi_slot_id_storage = [final_multi_slot_1_id, final_multi_slot_2_id, final_multi_slot_3_id, final_multi_slot_4_id, final_multi_slot_5_id, final_multi_slot_6_id, final_multi_slot_7_id, final_multi_slot_8_id, final_multi_slot_9_id, final_multi_slot_10_id, final_multi_slot_11_id, final_multi_slot_12_id, final_multi_slot_13_id, final_multi_slot_14_id, final_multi_slot_15_id,];

let base_symbol_refs = ["Images/Cash-balance-icon.png", "Images/Tycoon-score-balance-icon.png", "Images/Points-cluster.png", "Images/cherry-symbol.svg"];

let multi_slot_symbols = [multi_slot_symbol_1, multi_slot_symbol_2, multi_slot_symbol_3, multi_slot_symbol_4, multi_slot_symbol_5, multi_slot_symbol_6, multi_slot_symbol_7, multi_slot_symbol_8, multi_slot_symbol_9, multi_slot_symbol_10, multi_slot_symbol_11, multi_slot_symbol_12, multi_slot_symbol_13, multi_slot_symbol_14, multi_slot_symbol_15];
let multi_reels_storage = [multi_reel_slot_1, multi_reel_slot_2, multi_reel_slot_3, multi_reel_slot_4, multi_reel_slot_5, multi_reel_slot_6, multi_reel_slot_7, multi_reel_slot_8, multi_reel_slot_9, multi_reel_slot_10, multi_reel_slot_11, multi_reel_slot_12, multi_reel_slot_13, multi_reel_slot_14, multi_reel_slot_15];
let multi_spin_counter = 0;

for (let i = 0; i < bet_slider_step_refs_storage_2.length; i++) {
    bet_slider_step_refs_storage_2[i].addEventListener("click", () => {
        buttonPressAudio();
    });
}

function betSliderResetMeasure2() {
    manual_bet_increment_btn_2.disabled = false; manual_bet_increment_btn_2.style.cursor = "pointer"; manual_bet_increment_btn_2.style.opacity = "1";
    manual_bet_decrement_btn_2.disabled = true; manual_bet_decrement_btn_2.style.cursor = "not-allowed"; manual_bet_decrement_btn_2.style.opacity = "0.5";
} betSliderResetMeasure2();

function initiateReelRotation() {
    if (!reel_alternation_animation_preference_active) return;

    [...multi_reels_storage, ...reels_storage, ...booster_reels_storage].forEach((reel) => {
        reel.style.animation = "none";
        void reel.offsetWidth;
        reel.style.animation = "reel-rotation 1s ease-in-out";
    });
}

function endReelRotation() {
    multi_reels_storage.forEach(reel => { reel.style.animation = "none"; });
    reels_storage.forEach(reel => { reel.style.animation = "none"; });
    booster_reels_storage.forEach(reel => { reel.style.animation = "none"; });
}

document.getElementById("close-gambling-bet-dialog-btn-2").onclick = function() {
    document.getElementById("gambling-bet-dialog-overlay-2").style.display = "none";
}

document.getElementById("close-gambling-hub-ui-btn-2").onclick = function() {
    document.getElementById("gambling-hub-ui-2").style.display = "none";
}

document.getElementById("15-reel-slot-shortcut-btn").onclick = function() {
    document.getElementById("15-reel-slot-opt").click();
}

high_roller_opt_2.onclick = function() {
    document.getElementById("gambling-vip-dialog-overlay-2").style.display = "flex";
}

document.getElementById("close-gambling-vip-dialog-overlay-btn-2").onclick = function() {
    document.getElementById("gambling-vip-dialog-overlay-2").style.display = "none";
}

function highRollerBetSet2(high_roller_bet_opt, high_roller_bet_value) {
    high_roller_disable_opt_2.style.display = "block";
    high_roller_2_active = true;
    bet_2 = high_roller_bet_value;
    keyboardClickAudio();
    notificationDialog("[- HIGH ROLLER ACTIVE -]", 3000);
}

high_roller_250_bet_opt_2.onclick = function() { highRollerBetSet2(this, 250); }
high_roller_500_bet_opt_2.onclick = function() { highRollerBetSet2(this, 500); }
high_roller_1000_bet_opt_2.onclick = function() { highRollerBetSet2(this, 1000); }
high_roller_5000_bet_opt_2.onclick = function() { highRollerBetSet2(this, 5000); }
high_roller_10000_bet_opt_2.onclick = function() { highRollerBetSet2(this, 10000); }
high_roller_25000_bet_opt_2.onclick = function() { highRollerBetSet2(this, 25000); }
high_roller_50000_bet_opt_2.onclick = function() { highRollerBetSet2(this, 50000); }
high_roller_100000_bet_opt_2.onclick = function() { highRollerBetSet2(this, 100000); }
high_roller_500000_bet_opt_2.onclick = function() { highRollerBetSet2(this, 500000); }
high_roller_1000000_bet_opt_2.onclick = function() { highRollerBetSet2(this, 1000000); }

function manualBetOptDisable2() {
    manual_bet_increment_btn_2.disabled = false; manual_bet_increment_btn_2.style.cursor = "pointer"; manual_bet_increment_btn_2.style.opacity = "1";
    manual_bet_decrement_btn_2.disabled = false; manual_bet_decrement_btn_2.style.cursor = "pointer"; manual_bet_decrement_btn_2.style.opacity = "1";
}

function manualAutoSpinCountOptDisable() {
    manual_auto_spin_count_increment.disabled = false; manual_auto_spin_count_increment.style.cursor = "pointer"; manual_auto_spin_count_increment.style.opacity = "1";
    manual_auto_spin_count_decrement.disabled = false; manual_auto_spin_count_decrement.style.cursor = "pointer"; manual_auto_spin_count_decrement.style.opacity = "1";
}

function manualAutoSpinCountIncrement() {
    oscClickAudio();

    if (custom_auto_spin_count + Number(manual_auto_spin_count_slider.step) > Number(manual_auto_spin_count_slider.max)) {
        notificationDialog("Auto-Spin count cannot exceed $" + formatMoneyValue(Number(manual_auto_spin_count_slider.max)) + "!", 3000);
    } else if (manual_auto_spin_count_slider.value >= Number(manual_auto_spin_count_slider.max)) {
        manual_auto_spin_count_increment.disabled = true; manual_auto_spin_count_increment.style.cursor = "not-allowed"; manual_auto_spin_count_increment.style.opacity = "0.5";
    } else {
        manual_auto_spin_count_increment.disabled = false; manual_auto_spin_count_increment.style.cursor = "pointer"; manual_auto_spin_count_increment.style.opacity = "1"; 
        custom_auto_spin_count += Number(manual_auto_spin_count_slider.step);
        manual_auto_spin_count_slider.value = custom_auto_spin_count;
        document.getElementById("set-custom-auto-spin-count-opt").innerHTML = "TRIGGER > <span style='margin-left: 8px; color: yellow;'> " + custom_auto_spin_count + " FREE SPINS";
    
    }

    if (custom_auto_spin_count >= Number(manual_auto_spin_count_slider.max)) {
        manual_auto_spin_count_increment.disabled = true; manual_auto_spin_count_increment.style.cursor = "not-allowed"; manual_auto_spin_count_increment.style.opacity = "0.5";
    } else {
        manual_auto_spin_count_decrement.disabled = false; manual_auto_spin_count_decrement.style.cursor = "pointer"; manual_auto_spin_count_decrement.style.opacity = "1";
    }
}

function manualAutoSpinCountDecrement() {
    const minimumSpins = Number(manual_auto_spin_count_slider.min);
    const AutoSpinStep = Number(manual_auto_spin_count_slider.step);
    oscClickAudio();

    if (custom_auto_spin_count - AutoSpinStep < minimumSpins) {
        notificationDialog("Auto-Spin count cannot be less than " + formatDisplayNumber(minimumSpins) + "!", 3000);
        custom_auto_spin_count = minimumSpins;
    } else {
        custom_auto_spin_count -= AutoSpinStep;
        manual_auto_spin_count_slider.value = custom_auto_spin_count;
        document.getElementById("set-custom-auto-spin-count-opt").innerHTML = "TRIGGER > <span style='margin-left: 8px; color: yellow;'> " + custom_auto_spin_count + " FREE SPINS";
        updateBetDisplay();
    }

    if (custom_auto_spin_count <= minimumSpins) {
        manual_auto_spin_count_decrement.disabled = true; manual_auto_spin_count_decrement.style.cursor = "not-allowed"; manual_auto_spin_count_decrement.style.opacity = "0.5";
    } else {
        manual_auto_spin_count_increment.disabled = false; manual_auto_spin_count_increment.style.cursor = "pointer"; manual_auto_spin_count_increment.style.opacity = "1"; 
    }
}

manual_auto_spin_count_slider.oninput = function() { 
    custom_auto_spin_count = Number(manual_auto_spin_count_slider.value); 
    document.getElementById("set-custom-auto-spin-count-opt").innerHTML = "TRIGGER > <span style='margin-left: 8px; color: yellow;'> " + custom_auto_spin_count + " <span style='color: yellow;'>AUTO-SPINS</span>";
    document.getElementById("auto-spin-count-output").innerHTML = "Auto-Spins > " + formatDisplayNumber(custom_auto_spin_count);
    oscClickAudio(); 

    if (custom_auto_spin_count >= Number(manual_auto_spin_count_slider.max)) { 
        manual_auto_spin_count_increment.disabled = true; manual_auto_spin_count_increment.style.cursor = "not-allowed"; manual_auto_spin_count_increment.style.opacity = "0.5";
    } else { 
        manual_auto_spin_count_increment.disabled = false; manual_auto_spin_count_increment.style.cursor = "pointer"; manual_auto_spin_count_increment.style.opacity = "1"; 
    }

    if (custom_auto_spin_count <= Number(manual_auto_spin_count_slider.min)) { 
        manual_auto_spin_count_decrement.disabled = true; manual_auto_spin_count_decrement.style.cursor = "not-allowed"; manual_auto_spin_count_decrement.style.opacity = "0.5"; 
    } else { 
        manual_auto_spin_count_decrement.disabled = false; manual_auto_spin_count_decrement.style.cursor = "pointer"; manual_auto_spin_count_decrement.style.opacity = "1";
    }
}

function manualBetIncrement2() {
    oscClickAudio();

    if (bet_2 + Number(bet_selector_slider_2.step) > Number(bet_selector_slider_2.max)) {
        notificationDialog("Bet cannot exceed $" + formatMoneyValue(Number(bet_selector_slider_2.max)) + "!", 3000);
    } else if (bet_selector_slider_2.value >= Number(bet_selector_slider_2.max)) {
        manual_bet_increment_btn_2.disabled = true; manual_bet_increment_btn_2.style.cursor = "not-allowed"; manual_bet_increment_btn_2.style.opacity = "0.5";
    } else {
        bet_2 += Number(bet_selector_slider_2.step);
        bet_selector_slider_2.value = bet_2;
        current_bet_output_2.innerHTML = "Current Bet : $" + formatMoneyValue(bet_2);
        updateBetDisplay();
    }

    if (bet_2 >= Number(bet_selector_slider_2.max)) {
        manual_bet_increment_btn_2.disabled = true; manual_bet_increment_btn_2.style.cursor = "not-allowed"; manual_bet_increment_btn_2.style.opacity = "0.5";
    } else {
        manualBetOptDisable2();
    }
}

function manualBetDecrement2() {
    const minimumBet = Number(bet_selector_slider_2.min);
    const betStep = Number(bet_selector_slider_2.step);
    oscClickAudio();

    if (bet_2 - betStep < minimumBet) {
        notificationDialog("Bet cannot be less than $" + formatMoneyValue(minimumBet) + "!", 3000);
        bet_2 = minimumBet;
    } else {
        bet_2 -= betStep;
        bet_selector_slider_2.value = bet_2;
        current_bet_output_2.innerHTML = "Current Bet : $" + formatMoneyValue(bet_2);
        updateBetDisplay();
    }

    if (bet_2 <= minimumBet) {
        manual_bet_decrement_btn_2.disabled = true; manual_bet_decrement_btn_2.style.cursor = "not-allowed"; manual_bet_decrement_btn_2.style.opacity = "0.5";
    } else {
        manualBetOptDisable2();
    }
}

function disableBetOpt2() {
    bet_btn_2.disabled = true;
    bet_btn_2.style.cursor = "not-allowed";
    bet_btn_2.style.opacity = "0.5";
    max_bet_btn_2.disabled = true;
    max_bet_btn_2.style.cursor = "not-allowed";
    max_bet_btn_2.style.opacity = "0.5";
}

function enableBetOpt2() {
    bet_btn_2.disabled = false;
    bet_btn_2.style.cursor = "pointer";
    bet_btn_2.style.opacity = "1";
    max_bet_btn_2.disabled = false;
    max_bet_btn_2.style.cursor = "pointer";
    max_bet_btn_2.style.opacity = "1";
}

function disableGamblingControls2() {
    document.getElementById("gambling-bet-dialog-overlay-2").style.display = "none";
    auto_spin_btn_2.disabled = true; auto_spin_btn_2.style.cursor = "not-allowed"; auto_spin_btn_2.style.opacity = "0.5";
    spin_btn_2.disabled = true; spin_btn_2.style.cursor = "not-allowed"; spin_btn_2.style.opacity = "0.5";
    bet_btn_2.disabled = true; bet_btn_2.style.cursor = "not-allowed"; bet_btn_2.style.opacity = "0.5";
    max_bet_btn_2.disabled = true; max_bet_btn_2.style.cursor = "not-allowed"; max_bet_btn_2.style.opacity = "0.5";
    document.getElementById("vip-2").disabled = true; document.getElementById("vip-2").style.cursor = "not-allowed"; document.getElementById("vip-2").style.opacity = "0.5";
}

function enableGamblingControls2() {
    auto_spin_btn_2.disabled = false; auto_spin_btn_2.style.cursor = "pointer"; auto_spin_btn_2.style.opacity = "1";
    spin_btn_2.disabled = false; spin_btn_2.style.cursor = "pointer"; spin_btn_2.style.opacity = "1";
    bet_btn_2.disabled = false; bet_btn_2.style.cursor = "pointer"; bet_btn_2.style.opacity = "1";
    max_bet_btn_2.disabled = false; max_bet_btn_2.style.cursor = "pointer"; max_bet_btn_2.style.opacity = "1";
    document.getElementById("vip-2").disabled = false; document.getElementById("vip-2").style.cursor = "pointer"; document.getElementById("vip-2").style.opacity = "1";
}

spin_btn_2.onclick = function() { // SPIN VALIDATION
    if (free_spins_bonus_active || player_cash_balance >= bet_2) {
        spin_2_initiation_status = true;
        free_spins_symbols_counter = 0;
        addPlayerLvlXp(bet_2 * 2);

        if (free_spins_bonus_active) { player_cash_balance -= 0; }
        if (!free_spins_bonus_active) { player_cash_balance -= bet_2; }

        initiateMultiSpin();
        spinningReelsAudio();
        disableGamblingControls2();
    } else {
        upgradePurchaseFailedAudio();
        notificationDialog("Insufficient Funds!", 3000)
    }
}

// BET SLIDER STEP INTERVAL OPTS

document.getElementById("1-step-2").onclick = function() { betProgressStepInt2(1); manualBetOptDisable2(); betSliderResetMeasure2(); }
document.getElementById("2-step-2").onclick = function() { betProgressStepInt2(2); manualBetOptDisable2(); betSliderResetMeasure2(); }
document.getElementById("5-step-2").onclick = function() { betProgressStepInt2(5); manualBetOptDisable2(); betSliderResetMeasure2(); }
document.getElementById("10-step-2").onclick = function() { betProgressStepInt2(10); manualBetOptDisable2(); betSliderResetMeasure2(); }
document.getElementById("20-step-2").onclick = function() { betProgressStepInt2(20); manualBetOptDisable2(); betSliderResetMeasure2(); }

// UNIVERSAL BET SLIDER STEP INTERVAL APLICATOR

function betProgressStepInt2(bet_step_amount_2) {
    bet_2 = bet_step_amount_2;
    bet_selector_slider_2.step = bet_step_amount_2;
    bet_selector_slider_2.min = bet_step_amount_2;
    bet_selector_slider_2.value = bet_step_amount_2;
    updateBetDisplay2();
}

bet_btn_2.onclick = function() {
    document.getElementById("gambling-bet-dialog-overlay-2").style.display = "flex";
    //high_roller_disable_opt_2.click();
}

max_bet_btn_2.onclick = function() {
    bet_2 = 100;
    bet_selector_slider_2.value = 100;
    updateBetDisplay2();
}

// SLIDER FOR BET SELECTIONS

bet_selector_slider_2.oninput = function() {
    bet_2 = Number(bet_selector_slider_2.value);
    updateBetDisplay2();
    oscClickAudio();

    if (bet_2 >= Number(bet_selector_slider_2.max)) {
        manual_bet_increment_btn_2.disabled = true; manual_bet_increment_btn_2.style.cursor = "not-allowed"; manual_bet_increment_btn_2.style.opacity = "0.5";
    } else {
        manualBetOptDisable2();
    }

    if (bet_2 <= Number(bet_selector_slider_2.min)) {
        manual_bet_decrement_btn_2.disabled = true; manual_bet_decrement_btn_2.style.cursor = "not-allowed"; manual_bet_decrement_btn_2.style.opacity = "0.5";
    }
}

function updateBetDisplay2() {
    current_bet_output_2.innerHTML = "Current Bet : $" + bet_2.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
    bet_based_cash_win_2 = calculateBetBasedCashWin(bet_2);
    bet_based_cash_win_output_2.innerHTML = "Cash Win : $" + bet_based_cash_win_2.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function autoSpin2() { // AUTO-SPIN INITIATION
    initiateMultiSpin();
    auto_spin_2_int = setInterval(() => {
        if (free_spins_bonus_active || player_cash_balance >= bet_2) {
            if (free_spins_bonus_active) { player_cash_balance -= 0; }
            if (!free_spins_bonus_active) { player_cash_balance -= bet_2; }
            addPlayerLvlXp(bet_2 * 2);
            initiateMultiSpin();
            spinningReelsAudio();
        } else {
            clearInterval(auto_spin_2_int);
            stop_auto_spin_2_btn.style.display = "none";
            auto_spin_2_active = false;
            terminateAutoSpin2();
            notificationDialog("[AUTO-SPIN STOPPED]: Insufficient Funds!", 2000);
        }
    }, 4500)     
}

auto_spin_btn_2.onclick = function() { // AUTO-SPIN VALIDATION
    document.getElementById("15-reel-auto-spin-dialog-overlay").style.display = "flex";
}

document.getElementById("indefinite-auto-spin-trigger-opt").onclick = function() {
    keyboardClickAudio();
    if (player_cash_balance >= bet_2) {
        document.getElementById("indefinite-auto-spin-trigger-opt").disabled = true; document.getElementById("indefinite-auto-spin-trigger-opt").style.opacity = "0.5"; document.getElementById("indefinite-auto-spin-trigger-opt").style.cursor = "not-allowed";
        customAutoSpinOptDisable();
        setTimeout(() => {
            autoSpin2();
            addPlayerLvlXp(bet_2 * 2);
            spinningReelsAudio();
            custom_auto_spin_count_limit = 999999999999;

            if (free_spins_bonus_active) { player_cash_balance -= 0; }
            if (!free_spins_bonus_active) { player_cash_balance -= bet_2; }

            auto_spin_2_active = true;
            stop_auto_spin_2_btn.style.display = "block"; stop_auto_spin_2_btn.disabled = true; stop_auto_spin_2_btn.style.cursor = "not-allowed";
            stop_auto_spin_2_btn.disabled = true; stop_auto_spin_2_btn.style.cursor = "not-allowed"; stop_auto_spin_2_btn.style.opacity = "0.5";
            document.getElementById("15-reel-auto-spin-dialog-overlay").style.display = "none";
            document.getElementById("auto-spin-countdown-dialog-overlay").style.display = "flex";
            setTimeout(() => { stop_auto_spin_2_btn.disabled = false; stop_auto_spin_2_btn.style.cursor = "pointer"; stop_auto_spin_2_btn.style.opacity = "1"; }, 1000)
        }, 500)
    } else {
        notificationDialog("INSUFFICIENT FUNDS!", 3000);
        upgradePurchaseFailedAudio();
    }
}

function customAutoSpinOptDisable() {
    set_custom_auto_spin_count_opt.disabled = true; set_custom_auto_spin_count_opt.style.opacity = "0.5"; set_custom_auto_spin_count_opt.style.cursor = "not-allowed";
}

function customAutoSpinOptEnable() {
    set_custom_auto_spin_count_opt.disabled = false; set_custom_auto_spin_count_opt.style.opacity = "1"; set_custom_auto_spin_count_opt.style.cursor = "pointer";
}

set_custom_auto_spin_count_opt.onclick = function() {
    if (custom_auto_spin_count > Number(manual_auto_spin_count_slider.max)) {
        notificationDialog("[ERROR] > Spin counts exceeds maximum!", 3000);
        upgradePurchaseFailedAudio();
    } else if (custom_auto_spin_count < Number(manual_auto_spin_count_slider.min)) {
        notificationDialog("[ERROR] > Spin counts is below the minimum!", 3000);
        upgradePurchaseFailedAudio();
    } else if (player_cash_balance >= bet_2) {
        notificationDialog(custom_auto_spin_count + " AUTO-SPINS TRIGGERED!", 3000);
        customAutoSpinOptDisable();
        disableGamblingControls2();
        spinningReelsAudio();
        addPlayerLvlXp(bet_2 * 2);
        setTimeout(() => { autoSpin2(); }, 500)

        if (free_spins_bonus_active) { player_cash_balance -= 0; }
        if (!free_spins_bonus_active) { player_cash_balance -= bet_2; }

        auto_spin_2_active = true;
        stop_auto_spin_2_btn.style.display = "block"; stop_auto_spin_2_btn.disabled = true; stop_auto_spin_2_btn.style.cursor = "not-allowed";
        stop_auto_spin_2_btn.disabled = true; stop_auto_spin_2_btn.style.cursor = "not-allowed"; stop_auto_spin_2_btn.style.opacity = "0.5";
        document.getElementById("indefinite-auto-spin-trigger-opt").disabled = true; document.getElementById("indefinite-auto-spin-trigger-opt").style.opacity = "0.5"; document.getElementById("indefinite-auto-spin-trigger-opt").style.cursor = "not-allowed";
        setTimeout(() => {
            stop_auto_spin_2_btn.disabled = false;
            stop_auto_spin_2_btn.style.cursor = "pointer";
            stop_auto_spin_2_btn.style.opacity = "1";
        }, 1000)

        setTimeout(() => { document.getElementById("close-15-reel-auto-spin-dialog-overlay").click(); document.getElementById("auto-spin-countdown-dialog-overlay").style.display = "flex"; }, 1000)
    } else {
        notificationDialog("INSUFFICIENT FUNDS!", 3000);
        upgradePurchaseFailedAudio();
    }
}

document.getElementById("close-15-reel-auto-spin-dialog-overlay").onclick = function() {
    document.getElementById("15-reel-auto-spin-dialog-overlay").style.display = "none";
}

stop_auto_spin_2_btn.onclick = function() { // MANUAL AUTO-SPIN INTERVAL TERMINATION
    terminateAutoSpin2();
    custom_auto_spin_count_limit = 0;
    custom_auto_spin_count = 5;
    autoSpinsCompletedAudio();
    setTimeout(() => { document.getElementById("auto-spin-countdown-dialog-overlay").style.display = "none"; }, 1500)
    document.getElementById("indefinite-auto-spin-trigger-opt").disabled = false; document.getElementById("indefinite-auto-spin-trigger-opt").style.opacity = "1"; document.getElementById("indefinite-auto-spin-trigger-opt").style.cursor = "pointer";
}

function initiateFreeSpinsBonus() { // FREE SPINS BONUS INITIATION SEQUENCE
    free_spins_bonus_active = true;
    terminateAutoSpin2();
    enableGamblingControls2();
    stop_auto_spin_2_btn.click();

    setTimeout(() => {
        free_spins_bonus_probability = null;
        free_spins_bonus_spins = 0;

        jack_2_probability = null;
        queen_2_probability = null;
        king_2_probability = null;
        cash_2_probability = null;

        triple_coins_probability = 8;
        cherry_probability = 8;
        seven_probability = 20;
        diamond_2_probability = 20;
        star_probability = 350;
        
        diamond_win_2 = diamond_win_2 * 1.5;
        coin_cluster_win = coin_cluster_win * 1.5;

        lvlUpAudio();
        keyboardClickAudio();
        bet_btn_2.style.display = "none";
        max_bet_btn_2.style.display = "none";
        high_roller_opt_2.style.display = "none";
        inventory_slot_4_use_booster_opt.disabled = true;
        inventory_slot_4_use_booster_opt.style.opacity = "0.5";
        inventory_slot_4_use_booster_opt.style.cursor = "not-allowed";
        inventory_slot_5_use_booster_opt.disabled = true;
        inventory_slot_5_use_booster_opt.style.opacity = "0.5";
        inventory_slot_5_use_booster_opt.style.cursor = "not-allowed";
        setTimeout(() => { 
            document.getElementById("free-spins-bonus-spins-output").style.display = "block";
            document.getElementById("slot-selection-dialog-overlay").style.display = "none";
        }, 1000)
    }, 50)
}

document.getElementById("start-free-spins-bonus-dialog-overlay-btn").onclick = function() {
    document.getElementById("free-spins-bonus-start-dialog-overlay").style.display = "none";
    enableGamblingControls2();
    document.getElementById("slot-selection-dialog-overlay").style.display = "none";
    document.getElementById("15-reel-slot-opt").click();
    setTimeout(() => { clearInterval(security_control_disable_int_2); }, 1000)
    initiateFreeSpinsBonus();
}

document.getElementById("close-free-spins-bonus-end-overlay-btn").onclick = function() {
    document.getElementById("free-spins-bonus-end-dialog-overlay").style.display = "none";
    free_spins_bonus_cash_win_total = 0;
    free_spins_bonus_coin_win_total = 0;
    free_spins_bonus_diamond_win_total = 0;
}

function triggerFreeSpins() {
    stop_auto_spin_2_btn.click();
    setTimeout(() => {
        document.getElementById("free-spins-bonus-start-dialog-overlay").style.display = "flex";
        setTimeout(() => { disableGamblingControls2(); }, 500)
        setTimeout(() => { disableGamblingControls2(); }, 5600)
    }, 2500)
}

// STOP / TERMINATE AUTO-SPIN INTERVAL

function terminateAutoSpin2() {
    clearInterval(auto_spin_2_int);
    auto_spin_2_active = false;
    setTimeout(() => {
        enableGamblingControls2();
        customAutoSpinOptEnable();
        document.getElementById("indefinite-auto-spin-trigger-opt").disabled = false; document.getElementById("indefinite-auto-spin-trigger-opt").style.opacity = "1"; document.getElementById("indefinite-auto-spin-trigger-opt").style.cursor = "pointer";
    }, 5500)
    stop_auto_spin_2_btn.style.display = "none";
}

function rareWinsRNG2(slot_reel) { // RARE WIN RNG
    let free_spins_win = Math.floor(Math.random() * free_spins_bonus_probability);
    let triple_coins = Math.floor(Math.random() * triple_coins_probability);

    // BASE SYMBOLS

    let cash_2 = Math.floor(Math.random() * cash_2_probability);
    let coin_2 = Math.floor(Math.random() * coin_2_probability);
    let diamond_2 = Math.floor(Math.random() * diamond_2_probability);
    let jack_2 = Math.floor(Math.random() * jack_2_probability);
    let queen_2 = Math.floor(Math.random() * queen_2_probability);
    let ace_2 = Math.floor(Math.random() * ace_2_probability);
    let king_2 = Math.floor(Math.random() * king_2_probability);
    let seven_2 = Math.floor(Math.random() * seven_probability);
    let cherry_2 = Math.floor(Math.random() * cherry_probability);

    let star = Math.floor(Math.random() * star_probability);

    if (cash_2 === 1) {
        slot_reel.src = "Images/Cash-balance-icon.png";
    } else if (coin_2 === 1) {
        slot_reel.src = "Images/Tycoon-score-balance-icon.png";
    } else if (diamond_2 === 1) {
        slot_reel.src = "Images/Diamond-icon.png";
    } else if (jack_2 === 1) {
        slot_reel.src = "Images/j-symbol.svg";
    } else if (queen_2 === 1) {
        slot_reel.src = "Images/q-symbol.svg";
    } else if (ace_2 === 1) {
        slot_reel.src = "Images/a-symbol.svg";
    } else if (king_2 === 1) {
        slot_reel.src = "Images/k-symbol.svg";
    } else if (star === 1) {
        slot_reel.src = "Images/star-symbol.svg";
    } else if (seven_2 === 1) {
        slot_reel.src = "Images/triple-777-jackpot-green.svg";
    } else if (cherry_2 === 1) {
        slot_reel.src = "Images/cherry-symbol.svg";
    }

    if (free_spins_win === 1) {
        slot_reel.src = "Images/free-spins.svg";
    } else if (triple_coins === 1) {
        slot_reel.src = "Images/Points-cluster.png";
    }
}

// Math.floor(Math.random() * multi_reels_spin_int_max) + multi_reels_spin_int_min

function initiateMultiSpin() {  // SPIN INITIATION SEQUENCE
    setTimeout(() => { // COLUMN SECTOR 1 (reels: 1, 6, 11)
        multi_slot_1_int = setInterval(() => {
            rareWinsRNG2(document.getElementById("multi-slot-symbol-1"));
        }, column_sectors_reel_int)
        multi_slot_6_int = setInterval(() => {
            rareWinsRNG2(document.getElementById("multi-slot-symbol-6"));
        }, column_sectors_reel_int)
        multi_slot_11_int = setInterval(() => {
            rareWinsRNG2(document.getElementById("multi-slot-symbol-11"));
        }, column_sectors_reel_int)
    }, column_sector_1_timeout)
    setTimeout(() => { // COLUMN SECTOR 2 (reels: 2, 7, 12)
        multi_slot_2_int = setInterval(() => {
            rareWinsRNG2(document.getElementById("multi-slot-symbol-2"));
        }, column_sectors_reel_int)
        multi_slot_7_int = setInterval(() => {
            rareWinsRNG2(document.getElementById("multi-slot-symbol-7"));
        }, column_sectors_reel_int)
        multi_slot_12_int = setInterval(() => {
            rareWinsRNG2(document.getElementById("multi-slot-symbol-12"));
        }, column_sectors_reel_int)
    }, column_sector_2_timeout)
    setTimeout(() => { // COLUMN SECTOR 3 (reels: 3, 8, 13)
        multi_slot_3_int = setInterval(() => {
            rareWinsRNG2(document.getElementById("multi-slot-symbol-3"));
        }, column_sectors_reel_int)
        multi_slot_8_int = setInterval(() => {
            rareWinsRNG2(document.getElementById("multi-slot-symbol-8"));
        }, column_sectors_reel_int)
        multi_slot_13_int = setInterval(() => {
            rareWinsRNG2(document.getElementById("multi-slot-symbol-13"));
        }, column_sectors_reel_int)
    }, column_sector_3_timeout)
    setTimeout(() => { // COLUMN SECTOR 4 (reels: 4, 9, 14)
        multi_slot_4_int = setInterval(() => { 
            rareWinsRNG2(document.getElementById("multi-slot-symbol-4"));
        }, column_sectors_reel_int)
        multi_slot_9_int = setInterval(() => {
            rareWinsRNG2(document.getElementById("multi-slot-symbol-9"));
        }, column_sectors_reel_int)
        multi_slot_14_int = setInterval(() => {
            rareWinsRNG2(document.getElementById("multi-slot-symbol-14"));
        }, column_sectors_reel_int)
    }, column_sector_4_timeout)
    setTimeout(() => { // COLUMN SECTOR 5 (reels: 5, 10, 15)
        multi_slot_5_int = setInterval(() => {
            rareWinsRNG2(document.getElementById("multi-slot-symbol-5"));
        }, column_sectors_reel_int)
        multi_slot_10_int = setInterval(() => {
            rareWinsRNG2(document.getElementById("multi-slot-symbol-10"));
        }, column_sectors_reel_int)
        multi_slot_15_int = setInterval(() => {
            rareWinsRNG2(document.getElementById("multi-slot-symbol-15"));
        }, column_sectors_reel_int)
    }, column_sector_5_timeout)

    if (auto_spin_2_active) { custom_auto_spin_count_limit++; }

    if (auto_spin_2_active) {
        if (custom_auto_spin_count === custom_auto_spin_count_limit) {
            notificationDialog("[NOTE] > " + custom_auto_spin_count + " AUTO-SPINS COMPLETED!", 3500);
            autoSpinsCompletedAudio();
            setTimeout(() => { 
                document.getElementById("auto-spin-countdown-dialog-overlay").style.display = "none";
                document.getElementById("indefinite-auto-spin-trigger-opt").disabled = false; document.getElementById("indefinite-auto-spin-trigger-opt").style.opacity = "1"; document.getElementById("indefinite-auto-spin-trigger-opt").style.cursor = "pointer";
            }, 1000)
            terminateAutoSpin2();
            customAutoSpinOptEnable();
            custom_auto_spin_count_limit = 0;
            auto_spin_2_active = false;
        }
    }

    for (let i = 0; i < final_multi_slot_id_storage.length; i++) {
        final_multi_slot_id_storage[i].src = "Images/slot-placeholder.svg";
    }

    initiateReelRotation();
    customAutoSpinOptDisable();

    document.getElementById("free-spins-bonus-start-dialog-overlay").style.display = "none";
    document.getElementById("slot-selection-dialog-overlay").style.display = "none";
    document.getElementById("gambling-vip-dialog-overlay-2").style.display = "none";

    for (let i = 0; i < multi_reels_storage.length; i++) { multi_reels_storage[i].style.border = "none"; }
    for (let i = 0; i < final_multi_slot_id_storage.length; i++) { final_multi_slot_id_storage[i].style.border = "none"; }

    if (free_spins_bonus_active) { free_spins_bonus_spins++; }
    if (task_5_active) {
        task_5_progress = increaseProgressValue(task_5_progress, task_5_progress_bar, );
        task_5_progress_bar.value = Math.min(Number(task_5_progress_bar.value) + 1, Number(task_5_progress_bar.max) || 100);
    }

    setTimeout(() => {
        customAutoSpinOptEnable();

        clearInterval(multi_slot_1_int);
        clearInterval(multi_slot_2_int);
        clearInterval(multi_slot_3_int);
        clearInterval(multi_slot_4_int);
        clearInterval(multi_slot_5_int);
        clearInterval(multi_slot_6_int);
        clearInterval(multi_slot_7_int);
        clearInterval(multi_slot_8_int);
        clearInterval(multi_slot_9_int);
        clearInterval(multi_slot_10_int);
        clearInterval(multi_slot_11_int);
        clearInterval(multi_slot_12_int);
        clearInterval(multi_slot_13_int);
        clearInterval(multi_slot_14_int);
        clearInterval(multi_slot_15_int);

        function fullScreenBonus() {
            let bonus_rng = Math.floor(Math.random() * 777);

            if (bonus_rng === 1) {
                for (let i = 0; i < final_multi_slot_id_storage.length; i++) {
                    final_multi_slot_id_storage[i].src = "Images/free-spins.svg";
                }
            }
        } fullScreenBonus();

        function fullScreenCherries() {
            let cherry_rng = Math.floor(Math.random() * 500);

            if (cherry_rng === 1) {
                for (let i = 0; i < final_multi_slot_id_storage.length; i++) {
                    final_multi_slot_id_storage[i].src = "Images/cherry-symbol.svg";
                }
            }
        } fullScreenCherries();

        function fullScreenStars() {
            let star_rng = Math.floor(Math.random() * 5000);

            if (star_rng === 1) {
                for (let i = 0; i < final_multi_slot_id_storage.length; i++) {
                    final_multi_slot_id_storage[i].src = "Images/star-symbol.svg";
                }
            }
        } fullScreenStars();

        multi_spin_active = false;
        
        if (spin_2_initiation_status) { setTimeout(() => { enableGamblingControls2(); }, 500); }

        buff_3_spin_counter++;
        spin_2_initiation_status = false;

        // FREE SPINS BONUS CHECKER

        let free_spins_symbols_counter = 0;

        for (let i = 0; i < final_multi_slot_id_storage.length; i++) {
            if (final_multi_slot_id_storage[i].src.includes("Images/free-spins.svg")) {
                final_multi_slot_id_storage[i].style.border = "6px solid lime";
                collectFarmAudio();
                free_spins_symbols_counter++;
            }
        }

        if (free_spins_symbols_counter === 3) {
            free_spins_granted += free_spins_3_reel_grant;
            free_spins_won_counter++;
            setTimeout(() => { notificationDialog("You've received " + free_spins_3_reel_grant + " free spins with a $" + bet_2.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 4000); }, 500)
            bonusWinAudio();
            triggerFreeSpins();
        } else if (free_spins_symbols_counter === 4) {
            free_spins_granted += free_spins_4_reel_grant;
            free_spins_won_counter++;
            setTimeout(() => { notificationDialog("You've received " + free_spins_4_reel_grant + " free spins with a $" + bet_2.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 4000); }, 500)
            bonusWinAudio();
            triggerFreeSpins();
        } else if (free_spins_symbols_counter === 5) {
            free_spins_granted += free_spins_5_reel_grant;
            free_spins_won_counter++;
            setTimeout(() => { notificationDialog("You've received " + free_spins_5_reel_grant + " free spins with a $" + bet_2.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 4000); }, 500)
            bonusWinAudio();
            triggerFreeSpins();
        } else if (free_spins_symbols_counter === 6) {
            free_spins_granted += 50;
            free_spins_won_counter++;
            setTimeout(() => { notificationDialog("You've received " + free_spins_6_reel_grant + " free spins with a $" + bet_2.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 4000); }, 500)
            bonusWinAudio();
            triggerFreeSpins();
        } else if (free_spins_symbols_counter === 15) {
            free_spins_granted += 50;
            free_spins_won_counter++;
            bonusWinAudio();
            triggerFreeSpins();
            setTimeout(() => { notificationDialog("You've received " + 50 + " free spins with a $" + bet_2.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 4000); }, 500)
            
        }

        total_spins_cash_lost += bet_2;
        total_spins++;

        // Log board snapshot for debugging which combos fired vs actual board
        multi_spin_counter++;
        const spinId = multi_spin_counter;
        const boardSnapshot = [
            final_multi_slot_1_id,
            final_multi_slot_2_id,
            final_multi_slot_3_id,
            final_multi_slot_4_id,
            final_multi_slot_5_id,
            final_multi_slot_6_id,
            final_multi_slot_7_id,
            final_multi_slot_8_id,
            final_multi_slot_9_id,
            final_multi_slot_10_id,
            final_multi_slot_11_id,
            final_multi_slot_12_id,
            final_multi_slot_13_id,
            final_multi_slot_14_id,
            final_multi_slot_15_id
        ].map(el => {
            try { return el.src.split('/').pop(); } catch (e) { return String(el && el.src); }
        });
        console.log("[SPIN " + spinId + "] BOARD SNAPSHOT:", boardSnapshot);

        // CASH PAYOUT COMBOS

        if (final_multi_slot_1_id.src.includes("Cash-balance-icon.png") && final_multi_slot_2_id.src.includes("Cash-balance-icon.png") && final_multi_slot_3_id.src.includes("Cash-balance-icon.png") && final_multi_slot_4_id.src.includes("Cash-balance-icon.png") && final_multi_slot_5_id.src.includes("Cash-balance-icon.png")) { // 5 REEL CASH ROW 1
            console.log("[5 REEL] CASH [ROW 1]");
            player_cash_balance += bet_2 * cash_win_2 * 2;
            total_spins_cash_earned += bet_2 * cash_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * cash_win_2 * 2;
            multi_reel_slot_1.style.border = "5px solid lime";
            multi_reel_slot_2.style.border = "5px solid lime";
            multi_reel_slot_5.style.border = "5px solid lime";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("CASH WIN: $" + (bet_2 * cash_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_1_id.src.includes("Cash-balance-icon.png") && final_multi_slot_2_id.src.includes("Cash-balance-icon.png") && final_multi_slot_3_id.src.includes("Cash-balance-icon.png") && final_multi_slot_4_id.src.includes("Cash-balance-icon.png")) { // 4 REEL CASH ROW 1
            player_cash_balance += bet_2 * cash_win_2 * 1.5;
            total_spins_cash_earned += bet_2 * cash_win_2 * 1.5;
            free_spins_bonus_cash_win_total += bet_2 * cash_win_2 * 1.5;
            multi_reel_slot_1.style.border = "5px solid lime";
            multi_reel_slot_2.style.border = "5px solid lime";
            multi_reel_slot_3.style.border = "5px solid lime";
            multi_reel_slot_4.style.border = "5px solid lime";
            console.log("[4 REEL] CASH [ROW 1]");
            smallDingAudio();
            cashWinVisual();
            notificationDialog("CASH WIN: $" + (bet_2 * cash_win_2 * 1.5).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_1_id.src.includes("Cash-balance-icon.png") && final_multi_slot_2_id.src.includes("Cash-balance-icon.png") && final_multi_slot_3_id.src.includes("Cash-balance-icon.png")) { // 3 REEL CASH ROW 1
            player_cash_balance += bet_2 * cash_win_2;
            total_spins_cash_earned += bet_2 * cash_win_2;
            free_spins_bonus_cash_win_total += bet_2 * cash_win_2;
            multi_reel_slot_1.style.border = "5px solid lime";
            multi_reel_slot_2.style.border = "5px solid lime";
            multi_reel_slot_3.style.border = "5px solid lime";
            console.log("[3 REEL] CASH [ROW 1]");
            smallDingAudio();
            cashWinVisual();
            notificationDialog("CASH WIN: $" + (bet_2 * cash_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }
        if (final_multi_slot_6_id.src.includes("Cash-balance-icon.png") && final_multi_slot_7_id.src.includes("Cash-balance-icon.png") && final_multi_slot_8_id.src.includes("Cash-balance-icon.png") && final_multi_slot_9_id.src.includes("Cash-balance-icon.png") && final_multi_slot_10_id.src.includes("Cash-balance-icon.png")) { // 5 REEL CASH ROW 2
            console.log("[5 REEL] CASH [ROW 2]");
            player_cash_balance += bet_2 * cash_win_2 * 2;
            total_spins_cash_earned += bet_2 * cash_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * cash_win_2 * 2;
            multi_reel_slot_6.style.border = "5px solid lime";
            multi_reel_slot_7.style.border = "5px solid lime";
            multi_reel_slot_8.style.border = "5px solid lime";
            multi_reel_slot_9.style.border = "5px solid lime";
            multi_reel_slot_10.style.border = "5px solid lime";
            
            smallDingAudio();
            cashWinVisual();
            notificationDialog("CASH WIN: $" + (bet_2 * cash_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_6_id.src.includes("Cash-balance-icon.png") && final_multi_slot_7_id.src.includes("Cash-balance-icon.png") && final_multi_slot_8_id.src.includes("Cash-balance-icon.png") && final_multi_slot_9_id.src.includes("Cash-balance-icon.png")) { // 4 REEL CASH ROW 2
            player_cash_balance += bet_2 * cash_win_2 * 1.5;
            total_spins_cash_earned += bet_2 * cash_win_2 * 1.5;
            free_spins_bonus_cash_win_total += bet_2 * cash_win_2 * 1.5;
            multi_reel_slot_6.style.border = "5px solid lime";
            multi_reel_slot_7.style.border = "5px solid lime";
            multi_reel_slot_8.style.border = "5px solid lime";
            multi_reel_slot_9.style.border = "5px solid lime";
            console.log("[4 REEL] CASH [ROW 2]");
            smallDingAudio();
            cashWinVisual();
            notificationDialog("CASH WIN: $" + (bet_2 * cash_win_2 * 1.5).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_6_id.src.includes("Cash-balance-icon.png") && final_multi_slot_7_id.src.includes("Cash-balance-icon.png") && final_multi_slot_8_id.src.includes("Cash-balance-icon.png")) { // 3 REEL CASH ROW 2
            player_cash_balance += bet_2 * cash_win_2;
            total_spins_cash_earned += bet_2 * cash_win_2;
            free_spins_bonus_cash_win_total += bet_2 * cash_win_2;
            multi_reel_slot_6.style.border = "5px solid lime";
            multi_reel_slot_7.style.border = "5px solid lime";
            multi_reel_slot_8.style.border = "5px solid lime";
            console.log("[3 REEL] CASH [ROW 2]");
            smallDingAudio();
            cashWinVisual();
            notificationDialog("CASH WIN: $" + (bet_2 * cash_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }
        if (final_multi_slot_11_id.src.includes("Cash-balance-icon.png") && final_multi_slot_12_id.src.includes("Cash-balance-icon.png") && final_multi_slot_13_id.src.includes("Cash-balance-icon.png") && final_multi_slot_14_id.src.includes("Cash-balance-icon.png") && final_multi_slot_15_id.src.includes("Cash-balance-icon.png")) { // 5 REEL CASH ROW 3
            console.log("[5 REEL] CASH [ROW 3]");
            player_cash_balance += bet_2 * cash_win_2 * 2;
            total_spins_cash_earned += bet_2 * cash_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * cash_win_2 * 2;
            multi_reel_slot_11.style.border = "5px solid lime";
            multi_reel_slot_12.style.border = "5px solid lime";
            multi_reel_slot_13.style.border = "5px solid lime";
            multi_reel_slot_14.style.border = "5px solid lime";
            multi_reel_slot_15.style.border = "5px solid lime";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("CASH WIN: $" + (bet_2 * cash_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_11_id.src.includes("Cash-balance-icon.png") && final_multi_slot_12_id.src.includes("Cash-balance-icon.png") && final_multi_slot_13_id.src.includes("Cash-balance-icon.png") && final_multi_slot_14_id.src.includes("Cash-balance-icon.png")) { // 4 REEL CASH ROW 3
            player_cash_balance += bet_2 * cash_win_2 * 1.5;
            total_spins_cash_earned += bet_2 * cash_win_2 * 1.5;
            free_spins_bonus_cash_win_total += bet_2 * cash_win_2 * 1.5;
            multi_reel_slot_11.style.border = "5px solid lime";
            multi_reel_slot_12.style.border = "5px solid lime";
            multi_reel_slot_13.style.border = "5px solid lime";
            multi_reel_slot_14.style.border = "5px solid lime";
            console.log("[4 REEL] CASH [ROW 3]");
            smallDingAudio();
            cashWinVisual();
            notificationDialog("CASH WIN: $" + (bet_2 * cash_win_2 * 1.5).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_11_id.src.includes("Cash-balance-icon.png") && final_multi_slot_12_id.src.includes("Cash-balance-icon.png") && final_multi_slot_13_id.src.includes("Cash-balance-icon.png")) { // 3 REEL CASH ROW 3
            player_cash_balance += bet_2 * cash_win_2;
            total_spins_cash_earned += bet_2 * cash_win_2;
            free_spins_bonus_cash_win_total += bet_2 * cash_win_2;
            multi_reel_slot_11.style.border = "5px solid lime";
            multi_reel_slot_12.style.border = "5px solid lime";
            multi_reel_slot_13.style.border = "5px solid lime";
            console.log("[3 REEL] CASH [ROW 3]");
            smallDingAudio();
            cashWinVisual();
            notificationDialog("CASH WIN: $" + (bet_2 * cash_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }
        if (final_multi_slot_1_id.src.includes("Cash-balance-icon.png") && final_multi_slot_7_id.src.includes("Cash-balance-icon.png") && final_multi_slot_13_id.src.includes("Cash-balance-icon.png") && final_multi_slot_9_id.src.includes("Cash-balance-icon.png") && final_multi_slot_5_id.src.includes("Cash-balance-icon.png")) { // 5 REEL CASH ROW 1,2,3 [diagonal 5 of a kind] [slots 1,7,13,9,5]
            console.log("[5 REEL] CASH [ROW 1,2,3] [diagonal 5 of a kind] [slots 1,7,13,9,5]");
            player_cash_balance += bet_2 * cash_win_2 * 2;
            total_spins_cash_earned += bet_2 * cash_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * cash_win_2 * 2;
            multi_reel_slot_1.style.border = "5px solid lime";
            multi_reel_slot_7.style.border = "5px solid lime";
            multi_reel_slot_13.style.border = "5px solid lime";
            multi_reel_slot_9.style.border = "5px solid lime";
            multi_reel_slot_5.style.border = "5px solid lime";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("CASH WIN: $" + (bet_2 * cash_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_1_id.src.includes("Cash-balance-icon.png") && final_multi_slot_7_id.src.includes("Cash-balance-icon.png") && final_multi_slot_13_id.src.includes("Cash-balance-icon.png")) { // 3 REEL CASH ROW 1,2,3 [diagonal] [slots 1,7,13]
            player_cash_balance += bet_2 * cash_win_2;
            total_spins_cash_earned += bet_2 * cash_win_2;
            free_spins_bonus_cash_win_total += bet_2 * cash_win_2;
            multi_reel_slot_1.style.border = "5px solid lime";
            multi_reel_slot_7.style.border = "5px solid lime";
            multi_reel_slot_13.style.border = "5px solid lime";
            console.log("[3 REEL] CASH [ROW 1,2,3] [diagonal] [slots 1,7,13]");
            smallDingAudio();
            cashWinVisual();
            notificationDialog("CASH WIN: $" + (bet_2 * cash_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }
        if (final_multi_slot_11_id.src.includes("Cash-balance-icon.png") && final_multi_slot_7_id.src.includes("Cash-balance-icon.png") && final_multi_slot_3_id.src.includes("Cash-balance-icon.png") && final_multi_slot_9_id.src.includes("Cash-balance-icon.png") && final_multi_slot_15_id.src.includes("Cash-balance-icon.png")) { // 5 REEL CASH ROW 1,2,3 [diagonal reverse 5 of a kind] [slots 11,7,3,9,15]
            console.log("[5 REEL] CASH [ROW 1,2,3] [diagonal reverse 5 of a kind] [slots 11,7,3,9,15]");
            player_cash_balance += bet_2 * cash_win_2 * 2;
            total_spins_cash_earned += bet_2 * cash_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * cash_win_2 * 2;
            multi_reel_slot_11.style.border = "5px solid lime";
            multi_reel_slot_7.style.border = "5px solid lime";
            multi_reel_slot_3.style.border = "5px solid lime";
            multi_reel_slot_9.style.border = "5px solid lime";
            multi_reel_slot_15.style.border = "5px solid lime";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("CASH WIN: $" + (bet_2 * cash_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " COINS", 3500);
        } else if (final_multi_slot_11_id.src.includes("Cash-balance-icon.png") && final_multi_slot_7_id.src.includes("Cash-balance-icon.png") && final_multi_slot_3_id.src.includes("Cash-balance-icon.png")) { // 3 REEL CASH ROW 1,2,3 [diagonal reverse] [slots 11,7,3]
            player_cash_balance += bet_2 * cash_win_2;
            total_spins_cash_earned += bet_2 * cash_win_2;
            free_spins_bonus_cash_win_total += bet_2 * cash_win_2;
            multi_reel_slot_11.style.border = "5px solid lime";
            multi_reel_slot_7.style.border = "5px solid lime";
            multi_reel_slot_3.style.border = "5px solid lime";
            console.log("[3 REEL] CASH [ROW 1,2,3] [diagonal reverse] [slots 11,7,3]");
            smallDingAudio();
            cashWinVisual();
            notificationDialog("CASH WIN: $" + (bet_2 * cash_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }

        if (final_multi_slot_11_id.src.includes("Cash-balance-icon.png") && final_multi_slot_7_id.src.includes("Cash-balance-icon.png") && final_multi_slot_8_id.src.includes("Cash-balance-icon.png") && final_multi_slot_9_id.src.includes("Cash-balance-icon.png") && final_multi_slot_5_id.src.includes("Cash-balance-icon.png")) { // 5 REEL CASH ROW 3,2 [diagonal zigzag 5 of a kind] [slots 11,7,8,9,5]
            player_cash_balance += bet_2 * cash_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * cash_win_2 * 2;
            multi_reel_slot_11.style.border = "5px solid lime";
            multi_reel_slot_7.style.border = "5px solid lime";
            multi_reel_slot_8.style.border = "5px solid lime";
            multi_reel_slot_9.style.border = "5px solid lime";
            multi_reel_slot_5.style.border = "5px solid lime";
            console.log("[5 REEL] CASH [ROW 3,2] [diagonal zigzag 5 of a kind] [slots 11,7,8,9,5]");
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > CASH > $" + bet_2 * cash_win_2 * 2, 3500);
        }

        if (final_multi_slot_1_id.src.includes("Cash-balance-icon.png") && final_multi_slot_7_id.src.includes("Cash-balance-icon.png") && final_multi_slot_8_id.src.includes("Cash-balance-icon.png") && final_multi_slot_9_id.src.includes("Cash-balance-icon.png") && final_multi_slot_15_id.src.includes("Cash-balance-icon.png")) { // 5 REEL CASH ROW 2,1 [diagonal reverse zigzag 5 of a kind] [slots 1,7,8,9,15]
            player_cash_balance += bet_2 * cash_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * cash_win_2 * 2;
            multi_reel_slot_1.style.border = "5px solid lime";
            multi_reel_slot_7.style.border = "5px solid lime";
            multi_reel_slot_8.style.border = "5px solid lime";
            multi_reel_slot_9.style.border = "5px solid lime";
            multi_reel_slot_15.style.border = "5px solid lime";
            console.log("[5 REEL] CASH [ROW 2,1] [diagonal reverse zigzag 5 of a kind] [slots 1,7,8,9,15]");
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > CASH > $" + bet_2 * cash_win_2 * 2, 3500);
        }

        // COIN PAYOUT COMBOS

        if (final_multi_slot_1_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_2_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_3_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_4_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_5_id.src.includes("Tycoon-score-balance-icon.png")) { // 5 REEL COIN ROW 1
            console.log("[5 REEL] COIN [ROW 1]");
            player_coins_balance += bet_2 * coin_win_2 * 2;
            free_spins_bonus_coin_win_total += bet_2 * coin_win_2 * 2;
            multi_reel_slot_1.style.border = "5px solid yellow";
            multi_reel_slot_2.style.border = "5px solid yellow";
            multi_reel_slot_3.style.border = "5px solid yellow";
            multi_reel_slot_4.style.border = "5px solid yellow";
            multi_reel_slot_5.style.border = "5px solid yellow";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("COIN WIN > " + formatDisplayNumber(bet_2 * coin_win_2 * 2) + " COINS", 3500);
        } else if (final_multi_slot_1_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_2_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_3_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_4_id.src.includes("Tycoon-score-balance-icon.png")) { // 4 REEL COIN ROW 1
            console.log("[4 REEL] COIN [ROW 1]");
            player_coins_balance += bet_2 * coin_win_2 * 1.5;
            free_spins_bonus_coin_win_total += bet_2 * coin_win_2 * 1.5;
            multi_reel_slot_1.style.border = "5px solid yellow";
            multi_reel_slot_2.style.border = "5px solid yellow";
            multi_reel_slot_3.style.border = "5px solid yellow";
            multi_reel_slot_4.style.border = "5px solid yellow";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + formatDisplayNumber(bet_2 * coin_win_2 * 1.5) + " COINS", 3500);
        } else if (final_multi_slot_1_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_2_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_3_id.src.includes("Tycoon-score-balance-icon.png")) { // 3 REEL COIN ROW 1
            console.log("[3 REEL] COIN [ROW 1]");
            player_coins_balance += bet_2 * coin_win_2;
            free_spins_bonus_coin_win_total += bet_2 * coin_win_2;
            multi_reel_slot_1.style.border = "5px solid yellow";
            multi_reel_slot_2.style.border = "5px solid yellow";
            multi_reel_slot_3.style.border = "5px solid yellow";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + formatDisplayNumber(bet_2 * coin_win_2) + " COINS", 3500);
        }
        if (final_multi_slot_6_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_7_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_8_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_9_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_10_id.src.includes("Tycoon-score-balance-icon.png")) { // 5 REEL COIN ROW 2
            console.log("[5 REEL] COIN [ROW 2]");
            player_coins_balance += bet_2 * coin_win_2 * 2;
            free_spins_bonus_coin_win_total += bet_2 * coin_win_2 * 2;
            multi_reel_slot_6.style.border = "5px solid yellow";
            multi_reel_slot_7.style.border = "5px solid yellow";
            multi_reel_slot_8.style.border = "5px solid yellow";
            multi_reel_slot_9.style.border = "5px solid yellow";
            multi_reel_slot_10.style.border = "5px solid yellow";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + formatDisplayNumber(bet_2 * coin_win_2 * 2) + " COINS", 3500);
        } else if (final_multi_slot_6_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_7_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_8_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_9_id.src.includes("Tycoon-score-balance-icon.png")) { // 4 REEL COIN ROW 2
            console.log("[4 REEL] COIN [ROW 2]");
            player_coins_balance += bet_2 * coin_win_2 * 1.5;
            free_spins_bonus_coin_win_total += bet_2 * coin_win_2 * 1.5;
            multi_reel_slot_6.style.border = "5px solid yellow";
            multi_reel_slot_7.style.border = "5px solid yellow";
            multi_reel_slot_8.style.border = "5px solid yellow";
            multi_reel_slot_9.style.border = "5px solid yellow";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("COIN WIN > " + formatDisplayNumber(bet_2 * coin_win_2 * 1.5) + " COINS", 3500);
        } else if (final_multi_slot_6_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_7_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_8_id.src.includes("Tycoon-score-balance-icon.png")) { // 3 REEL COIN ROW 2
            console.log("[3 REEL] COIN [ROW 2]");
            player_coins_balance += bet_2 * coin_win_2;
            free_spins_bonus_coin_win_total += bet_2 * coin_win_2;
            multi_reel_slot_6.style.border = "5px solid yellow";
            multi_reel_slot_7.style.border = "5px solid yellow";
            multi_reel_slot_8.style.border = "5px solid yellow";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + formatDisplayNumber(bet_2 * coin_win_2) + " COINS", 3500);
        }
        if (final_multi_slot_11_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_12_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_13_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_14_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_15_id.src.includes("Tycoon-score-balance-icon.png")) { // 5 REEL COIN ROW 3
            console.log("[5 REEL] COIN [ROW 3]");
            player_coins_balance += bet_2 * coin_win_2 * 2;
            free_spins_bonus_coin_win_total += bet_2 * coin_win_2 * 2;
            multi_reel_slot_11.style.border = "5px solid yellow";
            multi_reel_slot_12.style.border = "5px solid yellow";
            multi_reel_slot_13.style.border = "5px solid yellow";
            multi_reel_slot_14.style.border = "5px solid yellow";
            multi_reel_slot_15.style.border = "5px solid yellow";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + formatDisplayNumber(bet_2 * coin_win_2 * 2) + " COINS", 3500);
        } else if (final_multi_slot_11_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_12_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_13_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_14_id.src.includes("Tycoon-score-balance-icon.png")) { // 4 REEL COIN ROW 3
            console.log("[4 REEL] COIN [ROW 3]");
            player_coins_balance += bet_2 * coin_win_2 * 1.5;
            free_spins_bonus_coin_win_total += bet_2 * coin_win_2 * 1.5;
            multi_reel_slot_11.style.border = "5px solid yellow";
            multi_reel_slot_12.style.border = "5px solid yellow";
            multi_reel_slot_13.style.border = "5px solid yellow";
            multi_reel_slot_14.style.border = "5px solid yellow";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + formatDisplayNumber(bet_2 * coin_win_2 * 1.5) + " COINS", 3500);
        } else if (final_multi_slot_11_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_12_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_13_id.src.includes("Tycoon-score-balance-icon.png")) { // 3 REEL COIN ROW 3
            console.log("[3 REEL] COIN [ROW 3]");
            player_coins_balance += bet_2 * coin_win_2;
            free_spins_bonus_coin_win_total += bet_2 * coin_win_2;
            multi_reel_slot_11.style.border = "5px solid yellow";
            multi_reel_slot_12.style.border = "5px solid yellow";
            multi_reel_slot_13.style.border = "5px solid yellow";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + formatDisplayNumber(bet_2 * coin_win_2) + " COINS", 3500);
        }
        if (final_multi_slot_1_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_7_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_13_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_9_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_5_id.src.includes("Tycoon-score-balance-icon.png")) { // 5 REEL COIN ROW 1,2,3 [diagonal 5 of a kind] [slots 1,7,13,9,5]
            console.log("[5 REEL] COIN [ROW 1,2,3] [diagonal 5 of a kind] [slots 1,7,13,9,5]");
            player_coins_balance += bet_2 * coin_win_2 * 1.5;
            free_spins_bonus_coin_win_total += bet_2 * coin_win_2 * 1.5;
            multi_reel_slot_1.style.border = "5px solid yellow";
            multi_reel_slot_7.style.border = "5px solid yellow";
            multi_reel_slot_13.style.border = "5px solid yellow";
            multi_reel_slot_9.style.border = "5px solid yellow";
            multi_reel_slot_5.style.border = "5px solid yellow";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + formatDisplayNumber(bet_2 * coin_win_2 * 1.5) + " COINS", 3500);
        } else if (final_multi_slot_1_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_7_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_13_id.src.includes("Tycoon-score-balance-icon.png")) { // 3 REEL COIN ROW 1,2,3 [diagonal] [slots 1,7,13]
            console.log("[3 REEL] COIN [ROW 1,2,3] [diagonal] [slots 1,7,13]");
            player_coins_balance += bet_2 * coin_win_2;
            free_spins_bonus_coin_win_total += bet_2 * coin_win_2;
            multi_reel_slot_1.style.border = "5px solid yellow";
            multi_reel_slot_7.style.border = "5px solid yellow";
            multi_reel_slot_13.style.border = "5px solid yellow";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("COIN WIN > " + formatDisplayNumber(bet_2 * coin_win_2) + " COINS", 3500);
        }
        if (final_multi_slot_11_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_7_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_3_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_9_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_15_id.src.includes("Tycoon-score-balance-icon.png")) { // 5 REEL COIN ROW 1,2,3 [diagonal reverse 5 of a kind] [slots 11,7,3,9,15]
            console.log("[5 REEL] COIN [ROW 1,2,3] [diagonal reverse 5 of a kind] [slots 11,7,3,9,15]");
            player_coins_balance += bet_2 * coin_win_2 * 2;
            free_spins_bonus_coin_win_total += bet_2 * coin_win_2 * 2;
            multi_reel_slot_11.style.border = "5px solid yellow";
            multi_reel_slot_7.style.border = "5px solid yellow";
            multi_reel_slot_3.style.border = "5px solid yellow";
            multi_reel_slot_9.style.border = "5px solid yellow";
            multi_reel_slot_15.style.border = "5px solid yellow";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + formatDisplayNumber(bet_2 * coin_win_2 * 2) + " COINS", 3500);
        } else if (final_multi_slot_11_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_7_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_3_id.src.includes("Tycoon-score-balance-icon.png")) { // 3 REEL COIN ROW 1,2,3 [diagonal reverse] [slots 11,7,3]
            console.log("[3 REEL] COIN [ROW 1,2,3] [diagonal reverse] [slots 11,7,3]");
            player_coins_balance += bet_2 * coin_win_2;
            free_spins_bonus_coin_win_total += bet_2 * coin_win_2;
            multi_reel_slot_11.style.border = "5px solid yellow";
            multi_reel_slot_7.style.border = "5px solid yellow";
            multi_reel_slot_3.style.border = "5px solid yellow";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + formatDisplayNumber(bet_2 * coin_win_2) + " COINS", 3500);
        }

        if (final_multi_slot_11_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_7_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_8_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_9_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_5_id.src.includes("Tycoon-score-balance-icon.png")) { // 5 REEL COIN ROW 3,2 [diagonal zigzag 5 of a kind] [slots 11,7,8,9,5]
            console.log("[5 REEL] COIN [ROW 3,2] [diagonal zigzag 5 of a kind] [slots 11,7,8,9,5]");
            player_coins_balance += bet_2 * coin_win_2 * 2;
            free_spins_bonus_coin_win_total += bet_2 * coin_win_2 * 2;
            multi_reel_slot_11.style.border = "5px solid yellow";
            multi_reel_slot_7.style.border = "5px solid yellow";
            multi_reel_slot_8.style.border = "5px solid yellow";
            multi_reel_slot_9.style.border = "5px solid yellow";
            multi_reel_slot_5.style.border = "5px solid yellow";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + formatDisplayNumber(bet_2 * coin_win_2 * 2) + " COINS", 3500);
        }

        if (final_multi_slot_1_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_7_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_8_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_9_id.src.includes("Tycoon-score-balance-icon.png") && final_multi_slot_15_id.src.includes("Tycoon-score-balance-icon.png")) { // 5 REEL COIN ROW 2,1 [diagonal reverse zigzag 5 of a kind] [slots 1,7,8,9,15]
            console.log("[5 REEL] COIN [ROW 2,1] [diagonal reverse zigzag 5 of a kind] [slots 1,7,8,9,15]");
            player_coins_balance += bet_2 * coin_win_2 * 2;
            free_spins_bonus_coin_win_total += bet_2 * coin_win_2 * 2;
            multi_reel_slot_1.style.border = "5px solid yellow";
            multi_reel_slot_7.style.border = "5px solid yellow";
            multi_reel_slot_8.style.border = "5px solid yellow";
            multi_reel_slot_9.style.border = "5px solid yellow";
            multi_reel_slot_15.style.border = "5px solid yellow";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + formatDisplayNumber(bet_2 * coin_win_2 * 2) + " COINS", 3500);
        }

        // DIAMOND PAYOUT COMBOS

        if (final_multi_slot_1_id.src.includes("Diamond-icon.png") && final_multi_slot_2_id.src.includes("Diamond-icon.png") && final_multi_slot_3_id.src.includes("Diamond-icon.png") && final_multi_slot_4_id.src.includes("Diamond-icon.png") && final_multi_slot_5_id.src.includes("Diamond-icon.png")) { // 5 REEL DIAMOND ROW 1
            console.log("[5 REEL] DIAMOND [ROW 1]");
            player_diamond_balance += 3;
            free_spins_bonus_diamond_win_total += 3;
            multi_reel_slot_1.style.border = "5px solid aquamarine";
            multi_reel_slot_2.style.border = "5px solid aquamarine";
            multi_reel_slot_3.style.border = "5px solid aquamarine";
            multi_reel_slot_4.style.border = "5px solid aquamarine";
            multi_reel_slot_5.style.border = "5px solid aquamarine";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + 3 + " DIAMOND", 3500);
        } else if (final_multi_slot_1_id.src.includes("Diamond-icon.png") && final_multi_slot_2_id.src.includes("Diamond-icon.png") && final_multi_slot_3_id.src.includes("Diamond-icon.png") && final_multi_slot_4_id.src.includes("Diamond-icon.png")) { // 4 REEL DIAMOND ROW 1
            console.log("[4 REEL] DIAMOND [ROW 1]");
            player_diamond_balance += 2;
            free_spins_bonus_diamond_win_total += 2;
            multi_reel_slot_1.style.border = "5px solid aquamarine";
            multi_reel_slot_2.style.border = "5px solid aquamarine";
            multi_reel_slot_3.style.border = "5px solid aquamarine";
            multi_reel_slot_4.style.border = "5px solid aquamarine";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + 2 + " DIAMOND", 3500);
        } else if (final_multi_slot_1_id.src.includes("Diamond-icon.png") && final_multi_slot_2_id.src.includes("Diamond-icon.png") && final_multi_slot_3_id.src.includes("Diamond-icon.png")) { // 3 REEL DIAMOND ROW 1
            console.log("[3 REEL] DIAMOND [ROW 1]");
            player_diamond_balance += 1;
            free_spins_bonus_diamond_win_total++;
            multi_reel_slot_1.style.border = "5px solid aquamarine";
            multi_reel_slot_2.style.border = "5px solid aquamarine";
            multi_reel_slot_3.style.border = "5px solid aquamarine";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + 1 + " DIAMOND", 3500);
        }
        if (final_multi_slot_6_id.src.includes("Diamond-icon.png") && final_multi_slot_7_id.src.includes("Diamond-icon.png") && final_multi_slot_8_id.src.includes("Diamond-icon.png") && final_multi_slot_9_id.src.includes("Diamond-icon.png") && final_multi_slot_10_id.src.includes("Diamond-icon.png")) { // 5 REEL DIAMOND ROW 2
            console.log("[5 REEL] DIAMOND [ROW 2]");
            player_diamond_balance += 3;
            free_spins_bonus_diamond_win_total += 3;
            multi_reel_slot_6.style.border = "5px solid aquamarine";
            multi_reel_slot_7.style.border = "5px solid aquamarine";
            multi_reel_slot_8.style.border = "5px solid aquamarine";
            multi_reel_slot_9.style.border = "5px solid aquamarine";
            multi_reel_slot_10.style.border = "5px solid aquamarine";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + 3 + " DIAMONDS", 3500);
        } else if (final_multi_slot_6_id.src.includes("Diamond-icon.png") && final_multi_slot_7_id.src.includes("Diamond-icon.png") && final_multi_slot_8_id.src.includes("Diamond-icon.png") && final_multi_slot_9_id.src.includes("Diamond-icon.png")) { // 4 REEL DIAMOND ROW 2
            console.log("[4 REEL] DIAMOND [ROW 2]");
            player_diamond_balance += 2;
            free_spins_bonus_diamond_win_total += 2;
            multi_reel_slot_6.style.border = "5px solid aquamarine";
            multi_reel_slot_7.style.border = "5px solid aquamarine";
            multi_reel_slot_8.style.border = "5px solid aquamarine";
            multi_reel_slot_9.style.border = "5px solid aquamarine";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + 2 + " DIAMOND", 3500);
        } else if (final_multi_slot_6_id.src.includes("Diamond-icon.png") && final_multi_slot_7_id.src.includes("Diamond-icon.png") && final_multi_slot_8_id.src.includes("Diamond-icon.png")) { // 3 REEL DIAMOND ROW 2
            console.log("[3 REEL] DIAMOND [ROW 2]");
            player_diamond_balance += 1;
            free_spins_bonus_diamond_win_total++;
            multi_reel_slot_6.style.border = "5px solid aquamarine";
            multi_reel_slot_7.style.border = "5px solid aquamarine";
            multi_reel_slot_8.style.border = "5px solid aquamarine";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + 1 + " DIAMOND", 3500);
        }
        if (final_multi_slot_11_id.src.includes("Diamond-icon.png") && final_multi_slot_12_id.src.includes("Diamond-icon.png") && final_multi_slot_13_id.src.includes("Diamond-icon.png") && final_multi_slot_14_id.src.includes("Diamond-icon.png") && final_multi_slot_15_id.src.includes("Diamond-icon.png")) { // 5 REEL DIAMOND ROW 3
            console.log("[5 REEL] DIAMOND [ROW 3]");
            player_diamond_balance += 3;
            free_spins_bonus_diamond_win_total += 3;
            multi_reel_slot_11.style.border = "5px solid aquamarine";
            multi_reel_slot_12.style.border = "5px solid aquamarine";
            multi_reel_slot_13.style.border = "5px solid aquamarine";
            multi_reel_slot_14.style.border = "5px solid aquamarine";
            multi_reel_slot_15.style.border = "5px solid aquamarine";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + 3 + " DIAMONDS", 3500);
        } else if (final_multi_slot_11_id.src.includes("Diamond-icon.png") && final_multi_slot_12_id.src.includes("Diamond-icon.png") && final_multi_slot_13_id.src.includes("Diamond-icon.png") && final_multi_slot_14_id.src.includes("Diamond-icon.png")) { // 4 REEL DIAMOND ROW 3
            console.log("[4 REEL] DIAMOND [ROW 3]");
            player_diamond_balance += 2;
            free_spins_bonus_diamond_win_total += 2;
            multi_reel_slot_11.style.border = "5px solid aquamarine";
            multi_reel_slot_12.style.border = "5px solid aquamarine";
            multi_reel_slot_13.style.border = "5px solid aquamarine";
            multi_reel_slot_14.style.border = "5px solid aquamarine";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + 2 + " DIAMONDS", 3500);
        } else if (final_multi_slot_11_id.src.includes("Diamond-icon.png") && final_multi_slot_12_id.src.includes("Diamond-icon.png") && final_multi_slot_13_id.src.includes("Diamond-icon.png")) { // 3 REEL DIAMOND ROW 3
            console.log("[3 REEL] DIAMOND [ROW 3]");
            player_diamond_balance += 1;
            free_spins_bonus_diamond_win_total++;
            multi_reel_slot_11.style.border = "5px solid aquamarine";
            multi_reel_slot_12.style.border = "5px solid aquamarine";
            multi_reel_slot_13.style.border = "5px solid aquamarine";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + 1 + " DIAMOND", 3500);
        }
        if (final_multi_slot_11_id.src.includes("Diamond-icon.png") && final_multi_slot_7_id.src.includes("Diamond-icon.png") && final_multi_slot_3_id.src.includes("Diamond-icon.png") && final_multi_slot_9_id.src.includes("Diamond-icon.png") && final_multi_slot_15_id.src.includes("Diamond-icon.png")) { // 5 REEL DIAMOND ROW 1,2,3 [diagonal 5 of a kind] [slots 11.7.3.9.15]
            console.log("[5 REEL] DIAMOND [ROW 1,2,3] [diagonal 5 of a kind] [slots 11.7.3.9.15]");
            player_diamond_balance += 3;
            free_spins_bonus_diamond_win_total += 3;
            multi_reel_slot_11.style.border = "5px solid aquamarine";
            multi_reel_slot_7.style.border = "5px solid aquamarine";
            multi_reel_slot_3.style.border = "5px solid aquamarine";
            multi_reel_slot_9.style.border = "5px solid aquamarine";
            multi_reel_slot_15.style.border = "5px solid aquamarine";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + 3 + " DIAMONDS", 3500);
        } else if (final_multi_slot_11_id.src.includes("Diamond-icon.png") && final_multi_slot_7_id.src.includes("Diamond-icon.png") && final_multi_slot_3_id.src.includes("Diamond-icon.png")) { // 3 REEL DIAMOND ROW 1,2,3 [diagonal reverse] [slots 11.7.3]
            console.log("[3 REEL] DIAMOND [ROW 1,2,3] [diagonal reverse] [slots 11.7.3]");
            player_diamond_balance += 1;
            free_spins_bonus_diamond_win_total++;
            multi_reel_slot_11.style.border = "5px solid aquamarine";
            multi_reel_slot_7.style.border = "5px solid aquamarine";
            multi_reel_slot_3.style.border = "5px solid aquamarine";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + 1 + " DIAMOND", 3500);
        }
        if (final_multi_slot_1_id.src.includes("Diamond-icon.png") && final_multi_slot_7_id.src.includes("Diamond-icon.png") && final_multi_slot_13_id.src.includes("Diamond-icon.png") && final_multi_slot_9_id.src.includes("Diamond-icon.png") && final_multi_slot_5_id.src.includes("Diamond-icon.png")) { // 5 REEL DIAMOND ROW 1,2,3 [diagonal reverse 5 of a kind] [slots 1.7.13.9.5]
            console.log("[5 REEL] DIAMOND [ROW 1,2,3] [diagonal reverse 5 of a kind] [slots 1.7.13.9.5]");
            player_diamond_balance += 3;
            free_spins_bonus_diamond_win_total += 3;
            multi_reel_slot_1.style.border = "5px solid aquamarine";
            multi_reel_slot_7.style.border = "5px solid aquamarine";
            multi_reel_slot_13.style.border = "5px solid aquamarine";
            multi_reel_slot_9.style.border = "5px solid aquamarine";
            multi_reel_slot_5.style.border = "5px solid aquamarine";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + 3 + " DIAMONDS", 3500);
        } else if (final_multi_slot_1_id.src.includes("Diamond-icon.png") && final_multi_slot_7_id.src.includes("Diamond-icon.png") && final_multi_slot_13_id.src.includes("Diamond-icon.png")) { // 3 REEL DIAMOND ROW 1,2,3 [diagonal] [slots 1.7.13]
            console.log("[3 REEL] DIAMOND [ROW 1,2,3] [diagonal] [slots 1.7.13]");
            player_diamond_balance += 1;
            free_spins_bonus_diamond_win_total++;
            multi_reel_slot_1.style.border = "5px solid aquamarine";
            multi_reel_slot_7.style.border = "5px solid aquamarine";
            multi_reel_slot_13.style.border = "5px solid aquamarine";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + 1 + " DIAMOND", 3500);
        }

        if (final_multi_slot_11_id.src.includes("Diamond-icon.png") && final_multi_slot_7_id.src.includes("Diamond-icon.png") && final_multi_slot_8_id.src.includes("Diamond-icon.png") && final_multi_slot_9_id.src.includes("Diamond-icon.png") && final_multi_slot_5_id.src.includes("Diamond-icon.png")) { // 5 REEL DIAMOND ROW 3,2 [diagonal zigzag 5 of a kind] [slots 11,7,8,9,5]
            console.log("[5 REEL] DIAMOND [ROW 3,2] [diagonal zigzag 5 of a kind] [slots 11,7,8,9,5]");
            player_diamond_balance += 3;
            free_spins_bonus_diamond_win_total += 3;
            multi_reel_slot_11.style.border = "5px solid aquamarine";
            multi_reel_slot_7.style.border = "5px solid aquamarine";
            multi_reel_slot_8.style.border = "5px solid aquamarine";
            multi_reel_slot_9.style.border = "5px solid aquamarine";
            multi_reel_slot_5.style.border = "5px solid aquamarine";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + 3 + " DIAMONDS", 3500);
        }

        if (final_multi_slot_1_id.src.includes("Diamond-icon.png") && final_multi_slot_7_id.src.includes("Diamond-icon.png") && final_multi_slot_8_id.src.includes("Diamond-icon.png") && final_multi_slot_9_id.src.includes("Diamond-icon.png") && final_multi_slot_15_id.src.includes("Diamond-icon.png")) { // 5 REEL DIAMOND ROW 2,1 [diagonal reverse zigzag 5 of a kind] [slots 1,7,8,9,15]
            console.log("[5 REEL] DIAMOND [ROW 2,1] [diagonal reverse zigzag 5 of a kind] [slots 1,7,8,9,15]");
            player_diamond_balance += 3;
            free_spins_bonus_diamond_win_total += 3;
            multi_reel_slot_1.style.border = "5px solid aquamarine";
            multi_reel_slot_7.style.border = "5px solid aquamarine";
            multi_reel_slot_8.style.border = "5px solid aquamarine";
            multi_reel_slot_9.style.border = "5px solid aquamarine";
            multi_reel_slot_15.style.border = "5px solid aquamarine";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > " + 3 + " DIAMONDS", 3500);
        }

        // JACKS PAYOUT COMBOS

        if (final_multi_slot_1_id.src.includes("j-symbol.svg") && final_multi_slot_2_id.src.includes("j-symbol.svg") && final_multi_slot_3_id.src.includes("j-symbol.svg") && final_multi_slot_4_id.src.includes("j-symbol.svg") && final_multi_slot_5_id.src.includes("j-symbol.svg")) { // 5 REEL JACKS ROW 1
            console.log("[5 REEL] JACKS [ROW 1]");
            player_cash_balance += bet_2 * jack_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * jack_win_2 * 2;
            multi_reel_slot_1.style.border = "5px solid orange";
            multi_reel_slot_2.style.border = "5px solid orange";
            multi_reel_slot_3.style.border = "5px solid orange";
            multi_reel_slot_4.style.border = "5px solid orange";
            multi_reel_slot_5.style.border = "5px solid orange";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > JACKS > $" + (bet_2 * jack_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_1_id.src.includes("j-symbol.svg") && final_multi_slot_2_id.src.includes("j-symbol.svg") && final_multi_slot_3_id.src.includes("j-symbol.svg") && final_multi_slot_4_id.src.includes("j-symbol.svg")) { // 4 REEL JACKS ROW 1
            console.log("[4 REEL] JACKS [ROW 1]");
            player_cash_balance += bet_2 * jack_win_2 * 1.5;
            free_spins_bonus_cash_win_total += bet_2 * jack_win_2 * 1.5;
            multi_reel_slot_1.style.border = "5px solid orange";
            multi_reel_slot_2.style.border = "5px solid orange";
            multi_reel_slot_3.style.border = "5px solid orange";
            multi_reel_slot_4.style.border = "5px solid orange";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > JACKS > $" + (bet_2 * jack_win_2 * 1.5).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_1_id.src.includes("j-symbol.svg") && final_multi_slot_2_id.src.includes("j-symbol.svg") && final_multi_slot_3_id.src.includes("j-symbol.svg")) { // 3 REEL JACKS ROW 1
            console.log("[3 REEL] JACKS [ROW 1]");
            player_cash_balance += bet_2 * jack_win_2;
            free_spins_bonus_cash_win_total += bet_2 * jack_win_2;
            multi_reel_slot_1.style.border = "5px solid orange";
            multi_reel_slot_2.style.border = "5px solid orange";
            multi_reel_slot_3.style.border = "5px solid orange";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > JACKS > $" + (bet_2 * jack_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }
        if (final_multi_slot_6_id.src.includes("j-symbol.svg") && final_multi_slot_7_id.src.includes("j-symbol.svg") && final_multi_slot_8_id.src.includes("j-symbol.svg") && final_multi_slot_9_id.src.includes("j-symbol.svg") && final_multi_slot_10_id.src.includes("j-symbol.svg")) { // 5 REEL JACKS ROW 2
            console.log("[5 REEL] JACKS [ROW 2]");
            player_cash_balance += bet_2 * jack_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * jack_win_2 * 2;
            multi_reel_slot_6.style.border = "5px solid orange";
            multi_reel_slot_7.style.border = "5px solid orange";
            multi_reel_slot_8.style.border = "5px solid orange";
            multi_reel_slot_9.style.border = "5px solid orange";
            multi_reel_slot_10.style.border = "5px solid orange";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > JACKS > $" + (bet_2 * jack_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_6_id.src.includes("j-symbol.svg") && final_multi_slot_7_id.src.includes("j-symbol.svg") && final_multi_slot_8_id.src.includes("j-symbol.svg") && final_multi_slot_9_id.src.includes("j-symbol.svg")) { // 4 REEL JACKS ROW 2
            console.log("[4 REEL] JACKS [ROW 2]");
            player_cash_balance += bet_2 * jack_win_2 * 1.5;
            free_spins_bonus_cash_win_total += bet_2 * jack_win_2 * 1.5;
            multi_reel_slot_6.style.border = "5px solid orange";
            multi_reel_slot_7.style.border = "5px solid orange";
            multi_reel_slot_8.style.border = "5px solid orange";
            multi_reel_slot_9.style.border = "5px solid orange";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > JACKS > $" + (bet_2 * jack_win_2 * 1.5).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_6_id.src.includes("j-symbol.svg") && final_multi_slot_7_id.src.includes("j-symbol.svg") && final_multi_slot_8_id.src.includes("j-symbol.svg")) { // 3 REEL JACKS ROW 2
            console.log("[3 REEL] JACKS [ROW 2]");
            player_cash_balance += bet_2 * jack_win_2;
            free_spins_bonus_cash_win_total += bet_2 * jack_win_2;
            multi_reel_slot_6.style.border = "5px solid orange";
            multi_reel_slot_7.style.border = "5px solid orange";
            multi_reel_slot_8.style.border = "5px solid orange";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > JACKS > $" + (bet_2 * jack_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }
        if (final_multi_slot_11_id.src.includes("j-symbol.svg") && final_multi_slot_12_id.src.includes("j-symbol.svg") && final_multi_slot_13_id.src.includes("j-symbol.svg") && final_multi_slot_14_id.src.includes("j-symbol.svg") && final_multi_slot_15_id.src.includes("j-symbol.svg")) { // 5 REEL JACKS ROW 3
            console.log("[5 REEL] JACKS [ROW 3]");
            player_cash_balance += bet_2 * jack_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * jack_win_2 * 2;
            multi_reel_slot_11.style.border = "5px solid orange";
            multi_reel_slot_12.style.border = "5px solid orange";
            multi_reel_slot_13.style.border = "5px solid orange";
            multi_reel_slot_14.style.border = "5px solid orange";
            multi_reel_slot_15.style.border = "5px solid orange";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > JACKS > $" + (bet_2 * jack_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_11_id.src.includes("j-symbol.svg") && final_multi_slot_12_id.src.includes("j-symbol.svg") && final_multi_slot_13_id.src.includes("j-symbol.svg") && final_multi_slot_14_id.src.includes("j-symbol.svg")) { // 4 REEL JACKS ROW 3
            console.log("[4 REEL] JACKS [ROW 3]");
            player_cash_balance += bet_2 * jack_win_2 * 1.5;
            free_spins_bonus_cash_win_total += bet_2 * jack_win_2 * 1.5;
            multi_reel_slot_11.style.border = "5px solid orange";
            multi_reel_slot_12.style.border = "5px solid orange";
            multi_reel_slot_13.style.border = "5px solid orange";
            multi_reel_slot_14.style.border = "5px solid orange";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > JACKS > $" + (bet_2 * jack_win_2 * 1.5).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_11_id.src.includes("j-symbol.svg") && final_multi_slot_12_id.src.includes("j-symbol.svg") && final_multi_slot_13_id.src.includes("j-symbol.svg")) { // 3 REEL JACKS ROW 3
            console.log("[3 REEL] JACKS [ROW 3]");
            player_cash_balance += bet_2 * jack_win_2;
            free_spins_bonus_cash_win_total += bet_2 * jack_win_2;
            multi_reel_slot_11.style.border = "5px solid orange";
            multi_reel_slot_12.style.border = "5px solid orange";
            multi_reel_slot_13.style.border = "5px solid orange";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > JACKS > $" + (bet_2 * jack_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }
        if (final_multi_slot_11_id.src.includes("j-symbol.svg") && final_multi_slot_7_id.src.includes("j-symbol.svg") && final_multi_slot_3_id.src.includes("j-symbol.svg") && final_multi_slot_9_id.src.includes("j-symbol.svg") && final_multi_slot_15_id.src.includes("j-symbol.svg")) { // 5 REEL JACKS ROW 1,2,3 [diagonal 5 of a kind] [slots 11.7.3.9.15]
            console.log("[5 REEL] JACKS [ROW 1,2,3] [diagonal 5 of a kind] [slots 11.7.3.9.15]");
             player_cash_balance += bet_2 * jack_win_2 * 2;
             free_spins_bonus_cash_win_total += bet_2 * jack_win_2 * 2;
            multi_reel_slot_11.style.border = "5px solid orange";
            multi_reel_slot_7.style.border = "5px solid orange";
            multi_reel_slot_3.style.border = "5px solid orange";
            multi_reel_slot_9.style.border = "5px solid orange";
            multi_reel_slot_15.style.border = "5px solid orange";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > JACKS > $" + (bet_2 * jack_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_11_id.src.includes("j-symbol.svg") && final_multi_slot_7_id.src.includes("j-symbol.svg") && final_multi_slot_3_id.src.includes("j-symbol.svg")) { // 3 REEL JACKS ROW 1,2,3 [diagonal reverse] [slots 11.7.3]
            console.log("[3 REEL] JACKS [ROW 1,2,3] [diagonal reverse] [slots 11.7.3]");
            player_cash_balance += bet_2 * jack_win_2;
            free_spins_bonus_cash_win_total += bet_2 * jack_win_2;
            multi_reel_slot_11.style.border = "5px solid orange";
            multi_reel_slot_7.style.border = "5px solid orange";
            multi_reel_slot_3.style.border = "5px solid orange";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > JACKS > $" + (bet_2 * jack_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }
        if (final_multi_slot_1_id.src.includes("j-symbol.svg") && final_multi_slot_7_id.src.includes("j-symbol.svg") && final_multi_slot_13_id.src.includes("j-symbol.svg") && final_multi_slot_9_id.src.includes("j-symbol.svg") && final_multi_slot_5_id.src.includes("j-symbol.svg")) { // 5 REEL JACKS ROW 1,2,3 [diagonal reverse 5 of a kind] [slots 1.7.13.9.5]
            console.log("[5 REEL] JACKS [ROW 1,2,3] [diagonal reverse 5 of a kind] [slots 1.7.13.9.5]");
             player_cash_balance += bet_2 * jack_win_2 * 2;
             free_spins_bonus_cash_win_total += bet_2 * jack_win_2 * 2;
            multi_reel_slot_1.style.border = "5px solid orange";
            multi_reel_slot_7.style.border = "5px solid orange";
            multi_reel_slot_13.style.border = "5px solid orange";
            multi_reel_slot_9.style.border = "5px solid orange";
            multi_reel_slot_5.style.border = "5px solid orange";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > JACKS > $" + (bet_2 * jack_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_1_id.src.includes("j-symbol.svg") && final_multi_slot_7_id.src.includes("j-symbol.svg") && final_multi_slot_13_id.src.includes("j-symbol.svg")) { // 3 REEL JACKS ROW 1,2,3 [diagonal] [slots 1.7.13]
            console.log("[3 REEL] JACKS [ROW 1,2,3] [diagonal] [slots 1.7.13]");
            player_cash_balance += bet_2 * jack_win_2;
            free_spins_bonus_cash_win_total += bet_2 * jack_win_2;
            multi_reel_slot_1.style.border = "5px solid orange";
            multi_reel_slot_7.style.border = "5px solid orange";
            multi_reel_slot_13.style.border = "5px solid orange";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > JACKS > $" + (bet_2 * jack_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }

        if (final_multi_slot_11_id.src.includes("j-symbol.svg") && final_multi_slot_7_id.src.includes("j-symbol.svg") && final_multi_slot_8_id.src.includes("j-symbol.svg") && final_multi_slot_9_id.src.includes("j-symbol.svg") && final_multi_slot_5_id.src.includes("j-symbol.svg")) { // 5 REEL JACKS ROW 3,2 [diagonal zigzag 5 of a kind] [slots 11,7,8,9,5]
            console.log("[5 REEL] JACKS [ROW 3,2] [diagonal zigzag 5 of a kind] [slots 11,7,8,9,5]");
            player_cash_balance += bet_2 * jack_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * jack_win_2 * 2;
            multi_reel_slot_11.style.border = "5px solid orange";
            multi_reel_slot_7.style.border = "5px solid orange";
            multi_reel_slot_8.style.border = "5px solid orange";
            multi_reel_slot_9.style.border = "5px solid orange";
            multi_reel_slot_5.style.border = "5px solid orange";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > JACKS > $" + (bet_2 * jack_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }

        if (final_multi_slot_1_id.src.includes("j-symbol.svg") && final_multi_slot_7_id.src.includes("j-symbol.svg") && final_multi_slot_8_id.src.includes("j-symbol.svg") && final_multi_slot_9_id.src.includes("j-symbol.svg") && final_multi_slot_15_id.src.includes("j-symbol.svg")) { // 5 REEL JACKS ROW 2,1 [diagonal reverse zigzag 5 of a kind] [slots 1,7,8,9,15]
            console.log("[5 REEL] JACKS [ROW 2,1] [diagonal reverse zigzag 5 of a kind] [slots 1,7,8,9,15]");
            player_cash_balance += bet_2 * jack_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * jack_win_2 * 2;
            multi_reel_slot_1.style.border = "5px solid orange";
            multi_reel_slot_7.style.border = "5px solid orange";
            multi_reel_slot_8.style.border = "5px solid orange";
            multi_reel_slot_9.style.border = "5px solid orange";
            multi_reel_slot_15.style.border = "5px solid orange";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > JACKS > $" + (bet_2 * jack_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }

        // QUEENS PAYOUT COMBOS

        if (final_multi_slot_1_id.src.includes("q-symbol.svg") && final_multi_slot_2_id.src.includes("q-symbol.svg") && final_multi_slot_3_id.src.includes("q-symbol.svg") && final_multi_slot_4_id.src.includes("q-symbol.svg") && final_multi_slot_5_id.src.includes("q-symbol.svg")) { // 5 REEL QUEENS ROW 1
            console.log("[5 REEL] QUEENS [ROW 1]");
            player_cash_balance += bet_2 * queen_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * queen_win_2 * 2;
            multi_reel_slot_1.style.border = "5px solid #ca6ed2";
            multi_reel_slot_2.style.border = "5px solid #ca6ed2";
            multi_reel_slot_3.style.border = "5px solid #ca6ed2";
            multi_reel_slot_4.style.border = "5px solid #ca6ed2";
            multi_reel_slot_5.style.border = "5px solid #ca6ed2";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > QUEENS > $" + (bet_2 * queen_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_1_id.src.includes("q-symbol.svg") && final_multi_slot_2_id.src.includes("q-symbol.svg") && final_multi_slot_3_id.src.includes("q-symbol.svg") && final_multi_slot_4_id.src.includes("q-symbol.svg")) { // 4 REEL QUEENS ROW 1
            console.log("[4 REEL] QUEENS [ROW 1]");
            player_cash_balance += bet_2 * queen_win_2 * 1.5;
            free_spins_bonus_cash_win_total += bet_2 * queen_win_2 * 1.5;
            multi_reel_slot_1.style.border = "5px solid #ca6ed2";
            multi_reel_slot_2.style.border = "5px solid #ca6ed2";
            multi_reel_slot_3.style.border = "5px solid #ca6ed2";
            multi_reel_slot_4.style.border = "5px solid #ca6ed2";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > QUEENS > $" + (bet_2 * queen_win_2 * 1.5).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_1_id.src.includes("q-symbol.svg") && final_multi_slot_2_id.src.includes("q-symbol.svg") && final_multi_slot_3_id.src.includes("q-symbol.svg")) { // 3 REEL QUEENS ROW 1
            console.log("[3 REEL] QUEENS [ROW 1]");
            player_cash_balance += bet_2 * queen_win_2;
            free_spins_bonus_cash_win_total += bet_2 * queen_win_2;
            multi_reel_slot_1.style.border = "5px solid #ca6ed2";
            multi_reel_slot_2.style.border = "5px solid #ca6ed2";
            multi_reel_slot_3.style.border = "5px solid #ca6ed2";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > QUEENS > $" + (bet_2 * queen_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }
        if (final_multi_slot_6_id.src.includes("q-symbol.svg") && final_multi_slot_7_id.src.includes("q-symbol.svg") && final_multi_slot_8_id.src.includes("q-symbol.svg") && final_multi_slot_9_id.src.includes("q-symbol.svg") && final_multi_slot_10_id.src.includes("q-symbol.svg")) { // 5 REEL QUEENS ROW 2
            console.log("[5 REEL] QUEENS [ROW 2]");
            player_cash_balance += bet_2 * queen_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * queen_win_2 * 2;
            multi_reel_slot_6.style.border = "5px solid #ca6ed2";
            multi_reel_slot_7.style.border = "5px solid #ca6ed2";
            multi_reel_slot_8.style.border = "5px solid #ca6ed2";
            multi_reel_slot_9.style.border = "5px solid #ca6ed2";
            multi_reel_slot_10.style.border = "5px solid #ca6ed2";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > QUEENS > $" + (bet_2 * queen_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_6_id.src.includes("q-symbol.svg") && final_multi_slot_7_id.src.includes("q-symbol.svg") && final_multi_slot_8_id.src.includes("q-symbol.svg") && final_multi_slot_9_id.src.includes("q-symbol.svg")) { // 4 REEL QUEENS ROW 2
            console.log("[4 REEL] QUEENS [ROW 2]");
            player_cash_balance += bet_2 * queen_win_2 * 1.5;
            free_spins_bonus_cash_win_total += bet_2 * queen_win_2 * 1.5;
            multi_reel_slot_6.style.border = "5px solid #ca6ed2";
            multi_reel_slot_7.style.border = "5px solid #ca6ed2";
            multi_reel_slot_8.style.border = "5px solid #ca6ed2";
            multi_reel_slot_9.style.border = "5px solid #ca6ed2";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > QUEENS > $" + (bet_2 * queen_win_2 * 1.5).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_6_id.src.includes("q-symbol.svg") && final_multi_slot_7_id.src.includes("q-symbol.svg") && final_multi_slot_8_id.src.includes("q-symbol.svg")) { // 3 REEL QUEENS ROW 2
            console.log("[3 REEL] QUEENS [ROW 2]");
            player_cash_balance += bet_2 * queen_win_2;
            free_spins_bonus_cash_win_total += bet_2 * queen_win_2;
            multi_reel_slot_6.style.border = "5px solid #ca6ed2";
            multi_reel_slot_7.style.border = "5px solid #ca6ed2";
            multi_reel_slot_8.style.border = "5px solid #ca6ed2";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > QUEENS > $" + (bet_2 * queen_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }
        if (final_multi_slot_11_id.src.includes("q-symbol.svg") && final_multi_slot_12_id.src.includes("q-symbol.svg") && final_multi_slot_13_id.src.includes("q-symbol.svg") && final_multi_slot_14_id.src.includes("q-symbol.svg") && final_multi_slot_15_id.src.includes("q-symbol.svg")) { // 5 REEL QUEENS ROW 3
            console.log("[5 REEL] QUEENS [ROW 3]");
            player_cash_balance += bet_2 * queen_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * queen_win_2 * 2;
            multi_reel_slot_11.style.border = "5px solid #ca6ed2";
            multi_reel_slot_12.style.border = "5px solid #ca6ed2";
            multi_reel_slot_13.style.border = "5px solid #ca6ed2";
            multi_reel_slot_14.style.border = "5px solid #ca6ed2";
            multi_reel_slot_15.style.border = "5px solid #ca6ed2";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > QUEENS > $" + (bet_2 * queen_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_11_id.src.includes("q-symbol.svg") && final_multi_slot_12_id.src.includes("q-symbol.svg") && final_multi_slot_13_id.src.includes("q-symbol.svg") && final_multi_slot_14_id.src.includes("q-symbol.svg")) { // 4 REEL QUEENS ROW 3
            console.log("[4 REEL] QUEENS [ROW 3]");
            player_cash_balance += bet_2 * queen_win_2 * 1.5;
            free_spins_bonus_cash_win_total += bet_2 * queen_win_2 * 1.5;
            multi_reel_slot_11.style.border = "5px solid #ca6ed2";
            multi_reel_slot_12.style.border = "5px solid #ca6ed2";
            multi_reel_slot_13.style.border = "5px solid #ca6ed2";
            multi_reel_slot_14.style.border = "5px solid #ca6ed2";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > QUEENS > $" + (bet_2 * queen_win_2 * 1.5).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_11_id.src.includes("q-symbol.svg") && final_multi_slot_12_id.src.includes("q-symbol.svg") && final_multi_slot_13_id.src.includes("q-symbol.svg")) { // 3 REEL QUEENS ROW 3
            console.log("[3 REEL] QUEENS [ROW 3]");
            player_cash_balance += bet_2 * queen_win_2;
            free_spins_bonus_cash_win_total += bet_2 * queen_win_2;
            multi_reel_slot_11.style.border = "5px solid #ca6ed2";
            multi_reel_slot_12.style.border = "5px solid #ca6ed2";
            multi_reel_slot_13.style.border = "5px solid #ca6ed2";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > QUEENS > $" + (bet_2 * queen_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }
        if (final_multi_slot_1_id.src.includes("q-symbol.svg") && final_multi_slot_7_id.src.includes("q-symbol.svg") && final_multi_slot_13_id.src.includes("q-symbol.svg") && final_multi_slot_9_id.src.includes("q-symbol.svg") && final_multi_slot_5_id.src.includes("q-symbol.svg")) { // 5 REEL QUEENS ROW 1,2,3 [diagonal 5 of a kind] [slots 1.7.13.9.5]
            console.log("[5 REEL] QUEENS [ROW 1,2,3] [diagonal 5 of a kind] [slots 1,7,13,9,5]");
            player_cash_balance += bet_2 * queen_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * queen_win_2 * 2;
            multi_reel_slot_1.style.border = "5px solid #ca6ed2";
            multi_reel_slot_7.style.border = "5px solid #ca6ed2";
            multi_reel_slot_13.style.border = "5px solid #ca6ed2";
            multi_reel_slot_9.style.border = "5px solid #ca6ed2";
            multi_reel_slot_5.style.border = "5px solid #ca6ed2";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > QUEENS > $" + (bet_2 * queen_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_1_id.src.includes("q-symbol.svg") && final_multi_slot_7_id.src.includes("q-symbol.svg") && final_multi_slot_13_id.src.includes("q-symbol.svg")) { // 3 REEL QUEENS ROW 1,2,3 [diagonal] [slots 1.7.13]
            console.log("[3 REEL] QUEENS [ROW 1,2,3] [diagonal] [slots 1,7,13]");
            player_cash_balance += bet_2 * queen_win_2;
            free_spins_bonus_cash_win_total += bet_2 * queen_win_2;
            multi_reel_slot_1.style.border = "5px solid #ca6ed2";
            multi_reel_slot_7.style.border = "5px solid #ca6ed2";
            multi_reel_slot_13.style.border = "5px solid #ca6ed2";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > QUEENS > $" + (bet_2 * queen_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }
        if (final_multi_slot_11_id.src.includes("q-symbol.svg") && final_multi_slot_7_id.src.includes("q-symbol.svg") && final_multi_slot_3_id.src.includes("q-symbol.svg") && final_multi_slot_9_id.src.includes("q-symbol.svg") && final_multi_slot_15_id.src.includes("q-symbol.svg")) { // 5 REEL QUEENS ROW 1,2,3 [diagonal reverse 5 of a kind] [slots 11.7.3.9.15]
            console.log("[5 REEL] QUEENS [ROW 1,2,3] [diagonal reverse 5 of a kind] [slots 11,7,3,9,15]");
            player_cash_balance += bet_2 * queen_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * queen_win_2 * 2;
            multi_reel_slot_11.style.border = "5px solid #ca6ed2";
            multi_reel_slot_7.style.border = "5px solid #ca6ed2";
            multi_reel_slot_3.style.border = "5px solid #ca6ed2";
            multi_reel_slot_9.style.border = "5px solid #ca6ed2";
            multi_reel_slot_15.style.border = "5px solid #ca6ed2";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > QUEENS > $" + (bet_2 * queen_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_11_id.src.includes("q-symbol.svg") && final_multi_slot_7_id.src.includes("q-symbol.svg") && final_multi_slot_3_id.src.includes("q-symbol.svg")) { // 3 REEL QUEENS ROW 1,2,3 [diagonal reverse] [slots 11.7.3]
            console.log("[3 REEL] QUEENS [ROW 1,2,3] [diagonal reverse] [slots 11,7,3]");
            player_cash_balance += bet_2 * queen_win_2;
            free_spins_bonus_cash_win_total += bet_2 * queen_win_2;
            multi_reel_slot_11.style.border = "5px solid #ca6ed2";
            multi_reel_slot_7.style.border = "5px solid #ca6ed2";
            multi_reel_slot_3.style.border = "5px solid #ca6ed2";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > QUEENS > $" + (bet_2 * queen_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }

        if (final_multi_slot_11_id.src.includes("q-symbol.svg") && final_multi_slot_7_id.src.includes("q-symbol.svg") && final_multi_slot_8_id.src.includes("q-symbol.svg") && final_multi_slot_9_id.src.includes("q-symbol.svg") && final_multi_slot_5_id.src.includes("q-symbol.svg")) { // 5 REEL QUEENS ROW 3,2 [diagonal zigzag 5 of a kind] [slots 11,7,8,9,5]
            console.log("[5 REEL] QUEENS [ROW 3,2] [diagonal zigzag 5 of a kind] [slots 11,7,8,9,5]");
            player_cash_balance += bet_2 * queen_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * queen_win_2 * 2;
            multi_reel_slot_11.style.border = "5px solid #ca6ed2";
            multi_reel_slot_7.style.border = "5px solid #ca6ed2";
            multi_reel_slot_8.style.border = "5px solid #ca6ed2";
            multi_reel_slot_9.style.border = "5px solid #ca6ed2";
            multi_reel_slot_5.style.border = "5px solid #ca6ed2";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > QUEENS > $" + (bet_2 * queen_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }

        if (final_multi_slot_1_id.src.includes("q-symbol.svg") && final_multi_slot_7_id.src.includes("q-symbol.svg") && final_multi_slot_8_id.src.includes("q-symbol.svg") && final_multi_slot_9_id.src.includes("q-symbol.svg") && final_multi_slot_15_id.src.includes("q-symbol.svg")) { // 5 REEL QUEENS ROW 2,1 [diagonal reverse zigzag 5 of a kind] [slots 1,7,8,9,15]
            console.log("[5 REEL] QUEENS [ROW 2,1] [diagonal reverse zigzag 5 of a kind] [slots 1,7,8,9,15]");
            player_cash_balance += bet_2 * queen_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * queen_win_2 * 2;
            multi_reel_slot_1.style.border = "5px solid #ca6ed2";
            multi_reel_slot_7.style.border = "5px solid #ca6ed2";
            multi_reel_slot_8.style.border = "5px solid #ca6ed2";
            multi_reel_slot_9.style.border = "5px solid #ca6ed2";
            multi_reel_slot_15.style.border = "5px solid #ca6ed2";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > QUEENS > $" + (bet_2 * queen_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }
        
        // KINGS PAYOUT COMBOS

        if (final_multi_slot_1_id.src.includes("k-symbol.svg") && final_multi_slot_2_id.src.includes("k-symbol.svg") && final_multi_slot_3_id.src.includes("k-symbol.svg") && final_multi_slot_4_id.src.includes("k-symbol.svg") && final_multi_slot_5_id.src.includes("k-symbol.svg")) { // 5 REEL KINGS ROW 1
            console.log("[5 REEL] KINGS [ROW 1]");
            player_cash_balance += bet_2 * king_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * king_win_2 * 2;
            multi_reel_slot_1.style.border = "5px solid #ff3e28";
            multi_reel_slot_2.style.border = "5px solid #ff3e28";
            multi_reel_slot_3.style.border = "5px solid #ff3e28";
            multi_reel_slot_4.style.border = "5px solid #ff3e28";
            multi_reel_slot_5.style.border = "5px solid #ff3e28";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > KINGS > $" + (bet_2 * king_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_1_id.src.includes("k-symbol.svg") && final_multi_slot_2_id.src.includes("k-symbol.svg") && final_multi_slot_3_id.src.includes("k-symbol.svg") && final_multi_slot_4_id.src.includes("k-symbol.svg")) { // 4 REEL KINGS ROW 1
            console.log("[4 REEL] KINGS [ROW 1]");
            player_cash_balance += bet_2 * king_win_2 * 1.5;
            free_spins_bonus_cash_win_total += bet_2 * king_win_2 * 1.5;
            multi_reel_slot_1.style.border = "5px solid #ff3e28";
            multi_reel_slot_2.style.border = "5px solid #ff3e28";
            multi_reel_slot_3.style.border = "5px solid #ff3e28";
            multi_reel_slot_4.style.border = "5px solid #ff3e28";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > KINGS > $" + (bet_2 * king_win_2 * 1.5).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_1_id.src.includes("k-symbol.svg") && final_multi_slot_2_id.src.includes("k-symbol.svg") && final_multi_slot_3_id.src.includes("k-symbol.svg")) { // 3 REEL KINGS ROW 1
            console.log("[3 REEL] KINGS [ROW 1]");
            player_cash_balance += bet_2 * king_win_2;
            free_spins_bonus_cash_win_total += bet_2 * king_win_2;
            multi_reel_slot_1.style.border = "5px solid #ff3e28";
            multi_reel_slot_2.style.border = "5px solid #ff3e28";
            multi_reel_slot_3.style.border = "5px solid #ff3e28";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > KINGS > $" + (bet_2 * king_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }
        if (final_multi_slot_6_id.src.includes("k-symbol.svg") && final_multi_slot_7_id.src.includes("k-symbol.svg") && final_multi_slot_8_id.src.includes("k-symbol.svg") && final_multi_slot_9_id.src.includes("k-symbol.svg") && final_multi_slot_10_id.src.includes("k-symbol.svg")) { // 5 REEL KINGS ROW 2
            console.log("[5 REEL] KINGS [ROW 2]");
            player_cash_balance += bet_2 * king_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * king_win_2 * 2;
            multi_reel_slot_6.style.border = "5px solid #ff3e28";
            multi_reel_slot_7.style.border = "5px solid #ff3e28";
            multi_reel_slot_8.style.border = "5px solid #ff3e28";
            multi_reel_slot_9.style.border = "5px solid #ff3e28";
            multi_reel_slot_10.style.border = "5px solid #ff3e28";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > KINGS > $" + (bet_2 * king_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_6_id.src.includes("k-symbol.svg") && final_multi_slot_7_id.src.includes("k-symbol.svg") && final_multi_slot_8_id.src.includes("k-symbol.svg") && final_multi_slot_9_id.src.includes("k-symbol.svg")) { // 4 REEL KINGS ROW 2
            console.log("[4 REEL] KINGS [ROW 2]");
            player_cash_balance += bet_2 * king_win_2 * 1.5;
            free_spins_bonus_cash_win_total += bet_2 * king_win_2 * 1.5;
            multi_reel_slot_6.style.border = "5px solid #ff3e28";
            multi_reel_slot_7.style.border = "5px solid #ff3e28";
            multi_reel_slot_8.style.border = "5px solid #ff3e28";
            multi_reel_slot_9.style.border = "5px solid #ff3e28";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > KINGS > $" + (bet_2 * king_win_2 * 1.5).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_6_id.src.includes("k-symbol.svg") && final_multi_slot_7_id.src.includes("k-symbol.svg") && final_multi_slot_8_id.src.includes("k-symbol.svg")) { // 3 REEL KINGS ROW 2
            console.log("[3 REEL] KINGS [ROW 2]");
            player_cash_balance += bet_2 * king_win_2;
            free_spins_bonus_cash_win_total += bet_2 * king_win_2;
            multi_reel_slot_6.style.border = "5px solid #ff3e28";
            multi_reel_slot_7.style.border = "5px solid #ff3e28";
            multi_reel_slot_8.style.border = "5px solid #ff3e28";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > KINGS > $" + (bet_2 * king_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }
        if (final_multi_slot_11_id.src.includes("k-symbol.svg") && final_multi_slot_12_id.src.includes("k-symbol.svg") && final_multi_slot_13_id.src.includes("k-symbol.svg") && final_multi_slot_14_id.src.includes("k-symbol.svg") && final_multi_slot_15_id.src.includes("k-symbol.svg")) { // 5 REEL KINGS ROW 3
            console.log("[5 REEL] KINGS [ROW 3]");
            player_cash_balance += bet_2 * king_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * king_win_2 * 2;
            multi_reel_slot_11.style.border = "5px solid #ff3e28";
            multi_reel_slot_12.style.border = "5px solid #ff3e28";
            multi_reel_slot_13.style.border = "5px solid #ff3e28";
            multi_reel_slot_14.style.border = "5px solid #ff3e28";
            multi_reel_slot_15.style.border = "5px solid #ff3e28";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > KINGS > $" + (bet_2 * king_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_11_id.src.includes("k-symbol.svg") && final_multi_slot_12_id.src.includes("k-symbol.svg") && final_multi_slot_13_id.src.includes("k-symbol.svg") && final_multi_slot_14_id.src.includes("k-symbol.svg")) { // 4 REEL KINGS ROW 3
            console.log("[4 REEL] KINGS [ROW 3]");
            player_cash_balance += bet_2 * king_win_2 * 1.5;
            free_spins_bonus_cash_win_total += bet_2 * king_win_2 * 1.5;
            multi_reel_slot_11.style.border = "5px solid #ff3e28";
            multi_reel_slot_12.style.border = "5px solid #ff3e28";
            multi_reel_slot_13.style.border = "5px solid #ff3e28";
            multi_reel_slot_14.style.border = "5px solid #ff3e28";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > KINGS > $" + (bet_2 * king_win_2 * 1.5).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_11_id.src.includes("k-symbol.svg") && final_multi_slot_12_id.src.includes("k-symbol.svg") && final_multi_slot_13_id.src.includes("k-symbol.svg")) { // 3 REEL KINGS ROW 3
            console.log("[3 REEL] KINGS [ROW 3]");
            player_cash_balance += bet_2 * king_win_2;
            free_spins_bonus_cash_win_total += bet_2 * king_win_2;
            multi_reel_slot_11.style.border = "5px solid #ff3e28";
            multi_reel_slot_12.style.border = "5px solid #ff3e28";
            multi_reel_slot_13.style.border = "5px solid #ff3e28";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > KINGS > $" + (bet_2 * king_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }
        if (final_multi_slot_11_id.src.includes("k-symbol.svg") && final_multi_slot_7_id.src.includes("k-symbol.svg") && final_multi_slot_3_id.src.includes("k-symbol.svg") && final_multi_slot_9_id.src.includes("k-symbol.svg") && final_multi_slot_15_id.src.includes("k-symbol.svg")) { // 5 REEL KINGS ROW 1,2,3 [diagonal 5 of a kind] [slots 11.7.3.9.15]
            console.log("[5 REEL] KINGS [ROW 1,2,3] [diagonal 5 of a kind] [slots 11.7.3.9.15]");
             player_cash_balance += bet_2 * king_win_2 * 2;
             free_spins_bonus_cash_win_total += bet_2 * king_win_2 * 2;
            multi_reel_slot_11.style.border = "5px solid #ff3e28";
            multi_reel_slot_7.style.border = "5px solid #ff3e28";
            multi_reel_slot_3.style.border = "5px solid #ff3e28";
            multi_reel_slot_9.style.border = "5px solid #ff3e28";
            multi_reel_slot_15.style.border = "5px solid #ff3e28";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > KINGS > $" + (bet_2 * king_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_11_id.src.includes("k-symbol.svg") && final_multi_slot_7_id.src.includes("k-symbol.svg") && final_multi_slot_3_id.src.includes("k-symbol.svg")) { // 3 REEL KINGS ROW 1,2,3 [diagonal reverse] [slots 11.7.3]
            console.log("[3 REEL] KINGS [ROW 1,2,3] [diagonal reverse] [slots 11.7.3]");
            player_cash_balance += bet_2 * king_win_2;
            free_spins_bonus_cash_win_total += bet_2 * king_win_2;
            multi_reel_slot_11.style.border = "5px solid #ff3e28";
            multi_reel_slot_7.style.border = "5px solid #ff3e28";
            multi_reel_slot_3.style.border = "5px solid #ff3e28";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > KINGS > $" + (bet_2 * king_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }
        if (final_multi_slot_1_id.src.includes("k-symbol.svg") && final_multi_slot_7_id.src.includes("k-symbol.svg") && final_multi_slot_13_id.src.includes("k-symbol.svg") && final_multi_slot_9_id.src.includes("k-symbol.svg") && final_multi_slot_5_id.src.includes("k-symbol.svg")) { // 5 REEL KINGS ROW 1,2,3 [diagonal reverse 5 of a kind] [slots 1.7.13.9.5]
            console.log("[5 REEL] KINGS [ROW 1,2,3] [diagonal reverse 5 of a kind] [slots 1.7.13.9.5]");
             player_cash_balance += bet_2 * king_win_2 * 2;
             free_spins_bonus_cash_win_total += bet_2 * king_win_2 * 2;
            multi_reel_slot_1.style.border = "5px solid #ff3e28";
            multi_reel_slot_7.style.border = "5px solid #ff3e28";
            multi_reel_slot_13.style.border = "5px solid #ff3e28";
            multi_reel_slot_9.style.border = "5px solid #ff3e28";
            multi_reel_slot_5.style.border = "5px solid #ff3e28";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > KINGS > $" + (bet_2 * king_win_2 * 2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_1_id.src.includes("k-symbol.svg") && final_multi_slot_7_id.src.includes("k-symbol.svg") && final_multi_slot_13_id.src.includes("k-symbol.svg")) { // 3 REEL KINGS [diagonal] [slots 1,7,13]
            console.log("[3 REEL] KINGS [diagonal] [slots 1,7,13]");
            player_cash_balance += bet_2 * king_win_2;
            free_spins_bonus_cash_win_total += bet_2 * king_win_2;
            multi_reel_slot_1.style.border = "5px solid #ff3e28";
            multi_reel_slot_7.style.border = "5px solid #ff3e28";
            multi_reel_slot_13.style.border = "5px solid #ff3e28";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > KINGS > $" + (bet_2 * king_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }

        // ACES WINLINES

        if (final_multi_slot_1_id.src.includes("a-symbol.svg") && final_multi_slot_2_id.src.includes("a-symbol.svg") && final_multi_slot_3_id.src.includes("a-symbol.svg") && final_multi_slot_4_id.src.includes("a-symbol.svg") && final_multi_slot_5_id.src.includes("a-symbol.svg")) { // 5 REEL ACES ROW 1
            console.log("[5 REEL] ACES [ROW 1]");
            player_cash_balance += bet_2 * ace_win_2 * 3;
            free_spins_bonus_cash_win_total += bet_2 * ace_win_2 * 3;
            multi_reel_slot_1.style.border = "5px solid #ff6a00";
            multi_reel_slot_2.style.border = "5px solid #ff6a00";
            multi_reel_slot_3.style.border = "5px solid #ff6a00";
            multi_reel_slot_4.style.border = "5px solid #ff6a00";
            multi_reel_slot_5.style.border = "5px solid #ff6a00";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > ACES > $" + (bet_2 * ace_win_2 * 3).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_1_id.src.includes("a-symbol.svg") && final_multi_slot_2_id.src.includes("a-symbol.svg") && final_multi_slot_3_id.src.includes("a-symbol.svg") && final_multi_slot_4_id.src.includes("a-symbol.svg")) { // 4 REEL ACES ROW 1
            console.log("[4 REEL] ACES [ROW 1]");
            player_cash_balance += bet_2 * ace_win_2 * 1.5;
            free_spins_bonus_cash_win_total += bet_2 * ace_win_2 * 1.5;
            multi_reel_slot_1.style.border = "5px solid #ff6a00";
            multi_reel_slot_2.style.border = "5px solid #ff6a00";
            multi_reel_slot_3.style.border = "5px solid #ff6a00";
            multi_reel_slot_4.style.border = "5px solid #ff6a00";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > ACES > $" + (bet_2 * ace_win_2 * 1.5).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_1_id.src.includes("a-symbol.svg") && final_multi_slot_2_id.src.includes("a-symbol.svg") && final_multi_slot_3_id.src.includes("a-symbol.svg")) { // 3 REEL ACES ROW 1
            console.log("[3 REEL] ACES [ROW 1]");
            player_cash_balance += bet_2 * ace_win_2;
            free_spins_bonus_cash_win_total += bet_2 * ace_win_2;
            multi_reel_slot_1.style.border = "5px solid #ff6a00";
            multi_reel_slot_2.style.border = "5px solid #ff6a00";
            multi_reel_slot_3.style.border = "5px solid #ff6a00";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > ACES > $" + (bet_2 * ace_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }
        if (final_multi_slot_6_id.src.includes("a-symbol.svg") && final_multi_slot_7_id.src.includes("a-symbol.svg") && final_multi_slot_8_id.src.includes("a-symbol.svg") && final_multi_slot_9_id.src.includes("a-symbol.svg") && final_multi_slot_10_id.src.includes("a-symbol.svg")) { // 5 REEL ACES ROW 2
            console.log("[5 REEL] ACES [ROW 2]");
            player_cash_balance += bet_2 * ace_win_2 * 3;
            free_spins_bonus_cash_win_total += bet_2 * ace_win_2 * 3;
            multi_reel_slot_6.style.border = "5px solid #ff6a00";
            multi_reel_slot_7.style.border = "5px solid #ff6a00";
            multi_reel_slot_8.style.border = "5px solid #ff6a00";
            multi_reel_slot_9.style.border = "5px solid #ff6a00";
            multi_reel_slot_10.style.border = "5px solid #ff6a00";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > ACES > $" + (bet_2 * ace_win_2 * 3).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_6_id.src.includes("a-symbol.svg") && final_multi_slot_7_id.src.includes("a-symbol.svg") && final_multi_slot_8_id.src.includes("a-symbol.svg") && final_multi_slot_9_id.src.includes("a-symbol.svg")) { // 4 REEL ACES ROW 2
            console.log("[4 REEL] ACES [ROW 2]");
            player_cash_balance += bet_2 * ace_win_2 * 1.5;
            free_spins_bonus_cash_win_total += bet_2 * ace_win_2 * 1.5;
            multi_reel_slot_6.style.border = "5px solid #ff6a00";
            multi_reel_slot_7.style.border = "5px solid #ff6a00";
            multi_reel_slot_8.style.border = "5px solid #ff6a00";
            multi_reel_slot_9.style.border = "5px solid #ff6a00";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > ACES > $" + (bet_2 * ace_win_2 * 1.5).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_6_id.src.includes("a-symbol.svg") && final_multi_slot_7_id.src.includes("a-symbol.svg") && final_multi_slot_8_id.src.includes("a-symbol.svg")) { // 3 REEL ACES ROW 2
            console.log("[3 REEL] ACES [ROW 2]");
            player_cash_balance += bet_2 * ace_win_2;
            free_spins_bonus_cash_win_total += bet_2 * ace_win_2;
            multi_reel_slot_6.style.border = "5px solid #ff6a00";
            multi_reel_slot_7.style.border = "5px solid #ff6a00";
            multi_reel_slot_8.style.border = "5px solid #ff6a00";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > ACES > $" + (bet_2 * ace_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }
        if (final_multi_slot_11_id.src.includes("a-symbol.svg") && final_multi_slot_12_id.src.includes("a-symbol.svg") && final_multi_slot_13_id.src.includes("a-symbol.svg") && final_multi_slot_14_id.src.includes("a-symbol.svg") && final_multi_slot_15_id.src.includes("a-symbol.svg")) { // 5 REEL ACES ROW 3
            console.log("[5 REEL] ACES [ROW 3]");
            player_cash_balance += bet_2 * ace_win_2 * 3;
            free_spins_bonus_cash_win_total += bet_2 * ace_win_2 * 3;
            multi_reel_slot_11.style.border = "5px solid #ff6a00";
            multi_reel_slot_12.style.border = "5px solid #ff6a00";
            multi_reel_slot_13.style.border = "5px solid #ff6a00";
            multi_reel_slot_14.style.border = "5px solid #ff6a00";
            multi_reel_slot_15.style.border = "5px solid #ff6a00";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > ACES > $" + (bet_2 * ace_win_2 * 3).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_11_id.src.includes("a-symbol.svg") && final_multi_slot_12_id.src.includes("a-symbol.svg") && final_multi_slot_13_id.src.includes("a-symbol.svg") && final_multi_slot_14_id.src.includes("a-symbol.svg")) { // 4 REEL ACES ROW 3
            console.log("[4 REEL] ACES [ROW 3]");
            player_cash_balance += bet_2 * ace_win_2 * 1.5;
            free_spins_bonus_cash_win_total += bet_2 * ace_win_2 * 1.5;
            multi_reel_slot_11.style.border = "5px solid #ff6a00";
            multi_reel_slot_12.style.border = "5px solid #ff6a00";
            multi_reel_slot_13.style.border = "5px solid #ff6a00";
            multi_reel_slot_14.style.border = "5px solid #ff6a00";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > ACES > $" + (bet_2 * ace_win_2 * 1.5).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_11_id.src.includes("a-symbol.svg") && final_multi_slot_12_id.src.includes("a-symbol.svg") && final_multi_slot_13_id.src.includes("a-symbol.svg")) { // 3 REEL ACES ROW 3
            console.log("[3 REEL] ACES [ROW 3]");
            player_cash_balance += bet_2 * ace_win_2;
            free_spins_bonus_cash_win_total += bet_2 * ace_win_2;
            multi_reel_slot_11.style.border = "5px solid #ff6a00";
            multi_reel_slot_12.style.border = "5px solid #ff6a00";
            multi_reel_slot_13.style.border = "5px solid #ff6a00";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > ACES > $" + (bet_2 * ace_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }
        if (final_multi_slot_1_id.src.includes("a-symbol.svg") && final_multi_slot_7_id.src.includes("a-symbol.svg") && final_multi_slot_13_id.src.includes("a-symbol.svg") && final_multi_slot_9_id.src.includes("a-symbol.svg") && final_multi_slot_5_id.src.includes("a-symbol.svg")) { // 5 REEL ACES ROW 1,2,3 [diagonal 5 of a kind] [slots 1.7.13.9.5]
            console.log("[5 REEL] ACES [ROW 1,2,3] [diagonal 5 of a kind] [slots 1,7,13,9,5]");
            player_cash_balance += bet_2 * ace_win_2 * 3;
            free_spins_bonus_cash_win_total += bet_2 * ace_win_2 * 3;
            multi_reel_slot_1.style.border = "5px solid #ff6a00";
            multi_reel_slot_7.style.border = "5px solid #ff6a00";
            multi_reel_slot_13.style.border = "5px solid #ff6a00";
            multi_reel_slot_9.style.border = "5px solid #ff6a00";
            multi_reel_slot_5.style.border = "5px solid #ff6a00";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > ACES > $" + (bet_2 * ace_win_2 * 3).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_1_id.src.includes("a-symbol.svg") && final_multi_slot_7_id.src.includes("a-symbol.svg") && final_multi_slot_13_id.src.includes("a-symbol.svg")) { // 3 REEL ACES ROW 1,2,3 [diagonal] [slots 1.7.13]
            console.log("[3 REEL] ACES [ROW 1,2,3] [diagonal] [slots 1,7,13]");
            player_cash_balance += bet_2 * ace_win_2;
            free_spins_bonus_cash_win_total += bet_2 * ace_win_2;
            multi_reel_slot_1.style.border = "5px solid #ff6a00";
            multi_reel_slot_7.style.border = "5px solid #ff6a00";
            multi_reel_slot_13.style.border = "5px solid #ff6a00";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > ACES > $" + (bet_2 * ace_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }
        if (final_multi_slot_11_id.src.includes("a-symbol.svg") && final_multi_slot_7_id.src.includes("a-symbol.svg") && final_multi_slot_3_id.src.includes("a-symbol.svg") && final_multi_slot_9_id.src.includes("a-symbol.svg") && final_multi_slot_15_id.src.includes("a-symbol.svg")) { // 5 REEL ACES ROW 1,2,3 [diagonal reverse 5 of a kind] [slots 11.7.3.9.15]
            console.log("[5 REEL] ACES [ROW 1,2,3] [diagonal reverse 5 of a kind] [slots 11,7,3,9,15]");
            player_cash_balance += bet_2 * ace_win_2 * 3;
            free_spins_bonus_cash_win_total += bet_2 * ace_win_2 * 3;
            multi_reel_slot_11.style.border = "5px solid #ff6a00";
            multi_reel_slot_7.style.border = "5px solid #ff6a00";
            multi_reel_slot_3.style.border = "5px solid #ff6a00";
            multi_reel_slot_9.style.border = "5px solid #ff6a00";
            multi_reel_slot_15.style.border = "5px solid #ff6a00";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > ACES > $" + (bet_2 * ace_win_2 * 3).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_multi_slot_11_id.src.includes("a-symbol.svg") && final_multi_slot_7_id.src.includes("a-symbol.svg") && final_multi_slot_3_id.src.includes("a-symbol.svg")) { // 3 REEL ACES ROW 1,2,3 [diagonal reverse] [slots 11.7.3]
            console.log("[3 REEL] ACES [ROW 1,2,3] [diagonal reverse] [slots 11,7,3]");
            player_cash_balance += bet_2 * ace_win_2;
            free_spins_bonus_cash_win_total += bet_2 * ace_win_2;
            multi_reel_slot_11.style.border = "5px solid #ff6a00";
            multi_reel_slot_7.style.border = "5px solid #ff6a00";
            multi_reel_slot_3.style.border = "5px solid #ff6a00";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > ACES > $" + (bet_2 * ace_win_2).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }

        if (final_multi_slot_11_id.src.includes("a-symbol.svg") && final_multi_slot_7_id.src.includes("a-symbol.svg") && final_multi_slot_8_id.src.includes("a-symbol.svg") && final_multi_slot_9_id.src.includes("a-symbol.svg") && final_multi_slot_5_id.src.includes("a-symbol.svg")) { // 5 REEL ACES ROW 3,2 [diagonal zigzag 5 of a kind] [slots 11,7,8,9,5]
            console.log("[5 REEL] ACES [ROW 3,2] [diagonal zigzag 5 of a kind] [slots 11,7,8,9,5]");
            player_cash_balance += bet_2 * ace_win_2 * 3;
            free_spins_bonus_cash_win_total += bet_2 * ace_win_2 * 3;
            multi_reel_slot_11.style.border = "5px solid #ff6a00";
            multi_reel_slot_7.style.border = "5px solid #ff6a00";
            multi_reel_slot_8.style.border = "5px solid #ff6a00";
            multi_reel_slot_9.style.border = "5px solid #ff6a00";
            multi_reel_slot_5.style.border = "5px solid #ff6a00";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > ACES > $" + (bet_2 * ace_win_2 * 3).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }

        if (final_multi_slot_1_id.src.includes("a-symbol.svg") && final_multi_slot_7_id.src.includes("a-symbol.svg") && final_multi_slot_8_id.src.includes("a-symbol.svg") && final_multi_slot_9_id.src.includes("a-symbol.svg") && final_multi_slot_15_id.src.includes("a-symbol.svg")) { // 5 REEL ACES ROW 2,1 [diagonal reverse zigzag 5 of a kind] [slots 1,7,8,9,15]
            console.log("[5 REEL] ACES [ROW 2,1] [diagonal reverse zigzag 5 of a kind] [slots 1,7,8,9,15]");
            player_cash_balance += bet_2 * ace_win_2 * 3;
            free_spins_bonus_cash_win_total += bet_2 * ace_win_2 * 3;
            multi_reel_slot_1.style.border = "5px solid #ff6a00";
            multi_reel_slot_7.style.border = "5px solid #ff6a00";
            multi_reel_slot_8.style.border = "5px solid #ff6a00";
            multi_reel_slot_9.style.border = "5px solid #ff6a00";
            multi_reel_slot_15.style.border = "5px solid #ff6a00";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > ACES > $" + (bet_2 * ace_win_2 * 3).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }

        if (final_multi_slot_11_id.src.includes("a-symbol.svg") && final_multi_slot_12_id.src.includes("a-symbol.svg") && final_multi_slot_8_id.src.includes("a-symbol.svg") && final_multi_slot_4_id.src.includes("a-symbol.svg") && final_multi_slot_5_id.src.includes("a-symbol.svg")) { // 5 REEL ACES [zigzag] [slots 11,12,8,4,5]
            console.log("[5 REEL] ACES [zigzag] [slots 11,12,8,4,5]");
            player_cash_balance += bet_2 * ace_win_2 * 3;
            free_spins_bonus_cash_win_total += bet_2 * ace_win_2 * 3;
            multi_reel_slot_11.style.border = "5px solid #ff6a00";
            multi_reel_slot_12.style.border = "5px solid #ff6a00";
            multi_reel_slot_8.style.border = "5px solid #ff6a00";
            multi_reel_slot_4.style.border = "5px solid #ff6a00";
            multi_reel_slot_5.style.border = "5px solid #ff6a00";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > ACES > $" + (bet_2 * ace_win_2 * 3).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }

        if (final_multi_slot_1_id.src.includes("a-symbol.svg") && final_multi_slot_2_id.src.includes("a-symbol.svg") && final_multi_slot_8_id.src.includes("a-symbol.svg") && final_multi_slot_14_id.src.includes("a-symbol.svg") && final_multi_slot_15_id.src.includes("a-symbol.svg")) { // 5 REEL ACES [zigzag] [slots 1,2,8,14,15]
            console.log("[5 REEL] ACES [zigzag] [slots 1,2,8,14,15]");
            player_cash_balance += bet_2 * ace_win_2 * 3;
            free_spins_bonus_cash_win_total += bet_2 * ace_win_2 * 3;
            multi_reel_slot_1.style.border = "5px solid #ff6a00";
            multi_reel_slot_2.style.border = "5px solid #ff6a00";
            multi_reel_slot_8.style.border = "5px solid #ff6a00";
            multi_reel_slot_14.style.border = "5px solid #ff6a00";
            multi_reel_slot_15.style.border = "5px solid #ff6a00";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > ACES > $" + (bet_2 * ace_win_2 * 3).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }

        // COIN CLUSTER PAYOUT COMBOS

        if (final_multi_slot_1_id.src.includes("Points-cluster.png") && final_multi_slot_2_id.src.includes("Points-cluster.png") && final_multi_slot_3_id.src.includes("Points-cluster.png") && final_multi_slot_4_id.src.includes("Points-cluster.png") && final_multi_slot_5_id.src.includes("Points-cluster.png")) { // 5 REEL COIN CLUSTER ROW 1
            console.log("[5 REEL] COIN CLUSTER [ROW 1]");
            player_coins_balance += bet_2 * coin_cluster_win * 2;
            free_spins_bonus_coin_win_total += bet_2 * coin_cluster_win * 2;
            multi_reel_slot_1.style.border = "5px solid #ffe228";
            multi_reel_slot_2.style.border = "5px solid #ffe228";
            multi_reel_slot_3.style.border = "5px solid #ffe228";
            multi_reel_slot_4.style.border = "5px solid #ffe228";
            multi_reel_slot_5.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > COIN CLUSTER > " + formatDisplayNumber(bet_2 * coin_cluster_win * 2) + " COINS", 3500);
        } else if (final_multi_slot_1_id.src.includes("Points-cluster.png") && final_multi_slot_2_id.src.includes("Points-cluster.png") && final_multi_slot_3_id.src.includes("Points-cluster.png") && final_multi_slot_4_id.src.includes("Points-cluster.png")) { // 4 REEL COIN CLUSTER ROW 1
            console.log("[4 REEL] COIN CLUSTER [ROW 1]");
            player_coins_balance += bet_2 * coin_cluster_win * 1.5;
            free_spins_bonus_coin_win_total += bet_2 * coin_cluster_win * 1.5;
            multi_reel_slot_1.style.border = "5px solid #ffe228";
            multi_reel_slot_2.style.border = "5px solid #ffe228";
            multi_reel_slot_3.style.border = "5px solid #ffe228";
            multi_reel_slot_4.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > COIN CLUSTER > " + formatDisplayNumber(bet_2 * coin_cluster_win * 1.5) + " COINS", 3500);
        } else if (final_multi_slot_1_id.src.includes("Points-cluster.png") && final_multi_slot_2_id.src.includes("Points-cluster.png") && final_multi_slot_3_id.src.includes("Points-cluster.png")) { // 3 REEL COIN CLUSTER ROW 1
            console.log("[3 REEL] COIN CLUSTER [ROW 1]");
            player_coins_balance += bet_2 * coin_cluster_win;
            free_spins_bonus_coin_win_total += bet_2 * coin_cluster_win;
            multi_reel_slot_1.style.border = "5px solid #ffe228";
            multi_reel_slot_2.style.border = "5px solid #ffe228";
            multi_reel_slot_3.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > COIN CLUSTER > " + formatDisplayNumber(bet_2 * coin_cluster_win) + " COINS", 3500);
        }
        if (final_multi_slot_6_id.src.includes("Points-cluster.png") && final_multi_slot_7_id.src.includes("Points-cluster.png") && final_multi_slot_8_id.src.includes("Points-cluster.png") && final_multi_slot_9_id.src.includes("Points-cluster.png") && final_multi_slot_10_id.src.includes("Points-cluster.png")) { // 5 REEL COIN CLUSTER ROW 2
            console.log("[5 REEL] COIN CLUSTER [ROW 2]");
            player_coins_balance += bet_2 * coin_cluster_win * 2;
            free_spins_bonus_coin_win_total += bet_2 * coin_cluster_win * 2;
            multi_reel_slot_6.style.border = "5px solid #ffe228";
            multi_reel_slot_7.style.border = "5px solid #ffe228";
            multi_reel_slot_8.style.border = "5px solid #ffe228";
            multi_reel_slot_9.style.border = "5px solid #ffe228";
            multi_reel_slot_10.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > COIN CLUSTER > " + formatDisplayNumber(bet_2 * coin_cluster_win * 2) + " COINS", 3500);
        } else if (final_multi_slot_6_id.src.includes("Points-cluster.png") && final_multi_slot_7_id.src.includes("Points-cluster.png") && final_multi_slot_8_id.src.includes("Points-cluster.png") && final_multi_slot_9_id.src.includes("Points-cluster.png")) { // 4 REEL COIN CLUSTER ROW 2
            console.log("[4 REEL] COIN CLUSTER [ROW 2]");
            player_coins_balance += bet_2 * coin_cluster_win * 1.5;
            free_spins_bonus_coin_win_total += bet_2 * coin_cluster_win * 1.5;
            multi_reel_slot_6.style.border = "5px solid #ffe228";
            multi_reel_slot_7.style.border = "5px solid #ffe228";
            multi_reel_slot_8.style.border = "5px solid #ffe228";
            multi_reel_slot_9.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > COIN CLUSTER > " + formatDisplayNumber(bet_2 * coin_cluster_win * 1.5) + " COINS", 3500);
        } else if (final_multi_slot_6_id.src.includes("Points-cluster.png") && final_multi_slot_7_id.src.includes("Points-cluster.png") && final_multi_slot_8_id.src.includes("Points-cluster.png")) { // 3 REEL COIN CLUSTER ROW 2
            console.log("[3 REEL] COIN CLUSTER [ROW 2]");
            player_coins_balance += bet_2 * coin_cluster_win;
            free_spins_bonus_coin_win_total += bet_2 * coin_cluster_win;
            multi_reel_slot_6.style.border = "5px solid #ffe228";
            multi_reel_slot_7.style.border = "5px solid #ffe228";
            multi_reel_slot_8.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > COIN CLUSTER > " + formatDisplayNumber(bet_2 * coin_cluster_win) + " COINS", 3500);
        }
        if (final_multi_slot_11_id.src.includes("Points-cluster.png") && final_multi_slot_12_id.src.includes("Points-cluster.png") && final_multi_slot_13_id.src.includes("Points-cluster.png") && final_multi_slot_14_id.src.includes("Points-cluster.png") && final_multi_slot_15_id.src.includes("Points-cluster.png")) { // 5 REEL COIN CLUSTER ROW 3
            console.log("[5 REEL] COIN CLUSTER [ROW 3]");
            player_coins_balance += bet_2 * coin_cluster_win * 2;
            free_spins_bonus_coin_win_total += bet_2 * coin_cluster_win * 2;
            multi_reel_slot_11.style.border = "5px solid #ffe228";
            multi_reel_slot_12.style.border = "5px solid #ffe228";
            multi_reel_slot_13.style.border = "5px solid #ffe228";
            multi_reel_slot_14.style.border = "5px solid #ffe228";
            multi_reel_slot_15.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > COIN CLUSTER > " + formatDisplayNumber(bet_2 * coin_cluster_win * 2) + " COINS", 3500);
        } else if (final_multi_slot_11_id.src.includes("Points-cluster.png") && final_multi_slot_12_id.src.includes("Points-cluster.png") && final_multi_slot_13_id.src.includes("Points-cluster.png") && final_multi_slot_14_id.src.includes("Points-cluster.png")) { // 4 REEL COIN CLUSTER ROW 3
            console.log("[4 REEL] COIN CLUSTER [ROW 3]");
            player_coins_balance += bet_2 * coin_cluster_win * 1.5;
            free_spins_bonus_coin_win_total += bet_2 * coin_cluster_win * 1.5;
            multi_reel_slot_11.style.border = "5px solid #ffe228";
            multi_reel_slot_12.style.border = "5px solid #ffe228";
            multi_reel_slot_13.style.border = "5px solid #ffe228";
            multi_reel_slot_14.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > COIN CLUSTER > " + formatDisplayNumber(bet_2 * coin_cluster_win * 1.5) + " COINS", 3500);
        } else if (final_multi_slot_11_id.src.includes("Points-cluster.png") && final_multi_slot_12_id.src.includes("Points-cluster.png") && final_multi_slot_13_id.src.includes("Points-cluster.png")) { // 3 REEL COIN CLUSTER ROW 3
            console.log("[3 REEL] COIN CLUSTER [ROW 3]");
            player_coins_balance += bet_2 * coin_cluster_win;
            free_spins_bonus_coin_win_total += bet_2 * coin_cluster_win;
            multi_reel_slot_11.style.border = "5px solid #ffe228";
            multi_reel_slot_12.style.border = "5px solid #ffe228";
            multi_reel_slot_13.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > COIN CLUSTER > " + formatDisplayNumber(bet_2 * coin_cluster_win) + " COINS", 3500);
        }
        if (final_multi_slot_1_id.src.includes("Points-cluster.png") && final_multi_slot_7_id.src.includes("Points-cluster.png") && final_multi_slot_13_id.src.includes("Points-cluster.png") && final_multi_slot_9_id.src.includes("Points-cluster.png") && final_multi_slot_5_id.src.includes("Points-cluster.png")) { // 5 REEL COIN CLUSTER ROW 1,2,3 [diagonal 5 of a kind] [slots 1,7,13,9,5]
            console.log("[5 REEL] COIN CLUSTER [ROW 1,2,3] [diagonal 5 of a kind] [slots 1,7,13,9,5]");
            player_coins_balance += bet_2 * coin_cluster_win * 1.5;
            free_spins_bonus_coin_win_total += bet_2 * coin_cluster_win * 1.5;
            multi_reel_slot_1.style.border = "5px solid #ffe228";
            multi_reel_slot_7.style.border = "5px solid #ffe228";
            multi_reel_slot_13.style.border = "5px solid #ffe228";
            multi_reel_slot_9.style.border = "5px solid #ffe228";
            multi_reel_slot_5.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > COIN CLUSTER > " + formatDisplayNumber(bet_2 * coin_cluster_win * 1.5) + " COINS", 3500);
        } else if (final_multi_slot_1_id.src.includes("Points-cluster.png") && final_multi_slot_7_id.src.includes("Points-cluster.png") && final_multi_slot_13_id.src.includes("Points-cluster.png")) { // 3 REEL COIN CLUSTER ROW 1,2,3 [diagonal] [slots 1,7,13]
            console.log("[3 REEL] COIN CLUSTER [ROW 1,2,3] [diagonal] [slots 1,7,13]");
            player_coins_balance += bet_2 * coin_cluster_win;
            free_spins_bonus_coin_win_total += bet_2 * coin_cluster_win;
            multi_reel_slot_1.style.border = "5px solid #ffe228";
            multi_reel_slot_7.style.border = "5px solid #ffe228";
            multi_reel_slot_13.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > COIN CLUSTER > " + formatDisplayNumber(bet_2 * coin_cluster_win) + " COINS", 3500);
        }
        if (final_multi_slot_11_id.src.includes("Points-cluster.png") && final_multi_slot_7_id.src.includes("Points-cluster.png") && final_multi_slot_3_id.src.includes("Points-cluster.png") && final_multi_slot_9_id.src.includes("Points-cluster.png") && final_multi_slot_15_id.src.includes("Points-cluster.png")) { // 5 REEL COIN CLUSTER ROW 1,2,3 [diagonal reverse 5 of a kind] [slots 11,7,3,9,15]
            console.log("[5 REEL] COIN CLUSTER [ROW 1,2,3] [diagonal reverse 5 of a kind] [slots 11,7,3,9,15]");
            player_coins_balance += bet_2 * coin_cluster_win * 2;
            free_spins_bonus_coin_win_total += bet_2 * coin_cluster_win * 2;
            multi_reel_slot_11.style.border = "5px solid #ffe228";
            multi_reel_slot_7.style.border = "5px solid #ffe228";
            multi_reel_slot_3.style.border = "5px solid #ffe228";
            multi_reel_slot_9.style.border = "5px solid #ffe228";
            multi_reel_slot_15.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > COIN CLUSTER > " + formatDisplayNumber(bet_2 * coin_cluster_win * 2) + " COINS", 3500);
        } else if (final_multi_slot_11_id.src.includes("Points-cluster.png") && final_multi_slot_7_id.src.includes("Points-cluster.png") && final_multi_slot_3_id.src.includes("Points-cluster.png")) { // 3 REEL COIN CLUSTER ROW 1,2,3 [diagonal reverse] [slots 11,7,3]
            console.log("[3 REEL] COIN CLUSTER [ROW 1,2,3] [diagonal reverse] [slots 11,7,3]");
            player_coins_balance += bet_2 * coin_cluster_win;
            free_spins_bonus_coin_win_total += bet_2 * coin_cluster_win;
            multi_reel_slot_11.style.border = "5px solid #ffe228";
            multi_reel_slot_7.style.border = "5px solid #ffe228";
            multi_reel_slot_3.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > COIN CLUSTER > " + formatDisplayNumber(bet_2 * coin_cluster_win) + " COINS", 3500);
        }
        if (final_multi_slot_11_id.src.includes("Points-cluster.png") && final_multi_slot_7_id.src.includes("Points-cluster.png") && final_multi_slot_8_id.src.includes("Points-cluster.png") && final_multi_slot_9_id.src.includes("Points-cluster.png") && final_multi_slot_5_id.src.includes("Points-cluster.png")) { // 5 REEL COIN CLUSTER ROW 3,2 [diagonal zigzag 5 of a kind] [slots 11,7,8,9,5]
            console.log("[5 REEL] COIN CLUSTER [ROW 3,2] [diagonal zigzag 5 of a kind] [slots 11,7,8,9,5]");
            player_coins_balance += bet_2 * coin_cluster_win * 2;
            free_spins_bonus_coin_win_total += bet_2 * coin_cluster_win * 2;
            multi_reel_slot_11.style.border = "5px solid #ffe228";
            multi_reel_slot_7.style.border = "5px solid #ffe228";
            multi_reel_slot_8.style.border = "5px solid #ffe228";
            multi_reel_slot_9.style.border = "5px solid #ffe228";
            multi_reel_slot_5.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > COIN CLUSTER > " + formatDisplayNumber(bet_2 * coin_cluster_win * 2) + " COINS", 3500);
        }
        if (final_multi_slot_1_id.src.includes("Points-cluster.png") && final_multi_slot_7_id.src.includes("Points-cluster.png") && final_multi_slot_8_id.src.includes("Points-cluster.png") && final_multi_slot_9_id.src.includes("Points-cluster.png") && final_multi_slot_15_id.src.includes("Points-cluster.png")) { // 5 REEL COIN CLUSTER ROW 2,1 [diagonal reverse zigzag 5 of a kind] [slots 1,7,8,9,15]
            console.log("[5 REEL] COIN CLUSTER [ROW 2,1] [diagonal reverse zigzag 5 of a kind] [slots 1,7,8,9,15]");
            player_coins_balance += bet_2 * coin_cluster_win * 2;
            free_spins_bonus_coin_win_total += bet_2 * coin_cluster_win * 2;
            multi_reel_slot_1.style.border = "5px solid #ffe228";
            multi_reel_slot_7.style.border = "5px solid #ffe228";
            multi_reel_slot_8.style.border = "5px solid #ffe228";
            multi_reel_slot_9.style.border = "5px solid #ffe228";
            multi_reel_slot_15.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > COIN CLUSTER > " + formatDisplayNumber(bet_2 * coin_cluster_win * 2) + " COINS", 3500);
        }

        // SEVENS PAYOUT COMBOS

        if (final_multi_slot_1_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_2_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_3_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_4_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_5_id.src.includes("triple-777-jackpot-green.svg")) { // 5 REEL SEVENS ROW 1
            console.log("[5 REEL] SEVENS [ROW 1]");
            player_coins_balance += bet_2 * seven_win_2 * 2;
            free_spins_bonus_coin_win_total += bet_2 * seven_win_2 * 2;
            multi_reel_slot_1.style.border = "5px solid #ffe228";
            multi_reel_slot_2.style.border = "5px solid #ffe228";
            multi_reel_slot_3.style.border = "5px solid #ffe228";
            multi_reel_slot_4.style.border = "5px solid #ffe228";
            multi_reel_slot_5.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > SEVENS > $" + formatMoneyValue(bet_2 * seven_win_2 * 2), 3500);
        } else if (final_multi_slot_1_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_2_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_3_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_4_id.src.includes("triple-777-jackpot-green.svg")) { // 4 REEL SEVENS ROW 1
            console.log("[4 REEL] SEVENS [ROW 1]");
            player_coins_balance += bet_2 * seven_win_2 * 1.5;
            free_spins_bonus_coin_win_total += bet_2 * seven_win_2 * 1.5;
            multi_reel_slot_1.style.border = "5px solid #ffe228";
            multi_reel_slot_2.style.border = "5px solid #ffe228";
            multi_reel_slot_3.style.border = "5px solid #ffe228";
            multi_reel_slot_4.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > SEVENS > $" + formatMoneyValue(bet_2 * seven_win_2 * 1.5), 3500);
        } else if (final_multi_slot_1_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_2_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_3_id.src.includes("triple-777-jackpot-green.svg")) { // 3 REEL SEVENS ROW 1
            console.log("[3 REEL] SEVENS [ROW 1]");
            player_coins_balance += bet_2 * seven_win_2;
            free_spins_bonus_coin_win_total += bet_2 * seven_win_2;
            multi_reel_slot_1.style.border = "5px solid #ffe228";
            multi_reel_slot_2.style.border = "5px solid #ffe228";
            multi_reel_slot_3.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > SEVENS > $" + formatMoneyValue(bet_2 * seven_win_2), 3500);
        }
        if (final_multi_slot_6_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_7_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_8_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_9_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_10_id.src.includes("triple-777-jackpot-green.svg")) { // 5 REEL SEVENS ROW 2
            console.log("[5 REEL] SEVENS [ROW 2]");
            player_coins_balance += bet_2 * seven_win_2 * 2;
            free_spins_bonus_coin_win_total += bet_2 * seven_win_2 * 2;
            multi_reel_slot_6.style.border = "5px solid #ffe228";
            multi_reel_slot_7.style.border = "5px solid #ffe228";
            multi_reel_slot_8.style.border = "5px solid #ffe228";
            multi_reel_slot_9.style.border = "5px solid #ffe228";
            multi_reel_slot_10.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > SEVENS > $" + formatMoneyValue(bet_2 * seven_win_2 * 2), 3500);
        } else if (final_multi_slot_6_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_7_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_8_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_9_id.src.includes("triple-777-jackpot-green.svg")) { // 4 REEL SEVENS ROW 2
            console.log("[4 REEL] SEVENS [ROW 2]");
            player_coins_balance += bet_2 * seven_win_2 * 1.5;
            free_spins_bonus_coin_win_total += bet_2 * seven_win_2 * 1.5;
            multi_reel_slot_6.style.border = "5px solid #ffe228";
            multi_reel_slot_7.style.border = "5px solid #ffe228";
            multi_reel_slot_8.style.border = "5px solid #ffe228";
            multi_reel_slot_9.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > SEVENS > $" + formatMoneyValue(bet_2 * seven_win_2 * 1.5), 3500);
        } else if (final_multi_slot_6_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_7_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_8_id.src.includes("triple-777-jackpot-green.svg")) { // 3 REEL SEVENS ROW 2
            console.log("[3 REEL] SEVENS [ROW 2]");
            player_coins_balance += bet_2 * seven_win_2;
            free_spins_bonus_coin_win_total += bet_2 * seven_win_2;
            multi_reel_slot_6.style.border = "5px solid #ffe228";
            multi_reel_slot_7.style.border = "5px solid #ffe228";
            multi_reel_slot_8.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > SEVENS > $" + formatMoneyValue(bet_2 * seven_win_2), 3500);
        }
        if (final_multi_slot_11_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_12_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_13_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_14_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_15_id.src.includes("triple-777-jackpot-green.svg")) { // 5 REEL SEVENS ROW 3
            console.log("[5 REEL] SEVENS [ROW 3]");
            player_coins_balance += bet_2 * seven_win_2 * 2;
            free_spins_bonus_coin_win_total += bet_2 * seven_win_2 * 2;
            multi_reel_slot_11.style.border = "5px solid #ffe228";
            multi_reel_slot_12.style.border = "5px solid #ffe228";
            multi_reel_slot_13.style.border = "5px solid #ffe228";
            multi_reel_slot_14.style.border = "5px solid #ffe228";
            multi_reel_slot_15.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > SEVENS > $" + formatMoneyValue(bet_2 * seven_win_2 * 2), 3500);
        } else if (final_multi_slot_11_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_12_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_13_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_14_id.src.includes("triple-777-jackpot-green.svg")) { // 4 REEL SEVENS ROW 3
            console.log("[4 REEL] SEVENS [ROW 3]");
            player_coins_balance += bet_2 * seven_win_2 * 1.5;
            free_spins_bonus_coin_win_total += bet_2 * seven_win_2 * 1.5;
            multi_reel_slot_11.style.border = "5px solid #ffe228";
            multi_reel_slot_12.style.border = "5px solid #ffe228";
            multi_reel_slot_13.style.border = "5px solid #ffe228";
            multi_reel_slot_14.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > SEVENS > $" + formatMoneyValue(bet_2 * seven_win_2 * 1.5), 3500);
        } else if (final_multi_slot_11_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_12_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_13_id.src.includes("triple-777-jackpot-green.svg")) { // 3 REEL SEVENS ROW 3
            console.log("[3 REEL] SEVENS [ROW 3]");
            player_coins_balance += bet_2 * seven_win_2;
            free_spins_bonus_coin_win_total += bet_2 * seven_win_2;
            multi_reel_slot_11.style.border = "5px solid #ffe228";
            multi_reel_slot_12.style.border = "5px solid #ffe228";
            multi_reel_slot_13.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > SEVENS > $" + formatMoneyValue(bet_2 * seven_win_2), 3500);
        }
        if (final_multi_slot_1_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_7_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_13_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_9_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_5_id.src.includes("triple-777-jackpot-green.svg")) { // 5 REEL SEVENS ROW 1,2,3 [diagonal 5 of a kind] [slots 1,7,13,9,5]
            console.log("[5 REEL] SEVENS [ROW 1,2,3] [diagonal 5 of a kind] [slots 1,7,13,9,5]");
            player_coins_balance += bet_2 * seven_win_2 * 2;
            free_spins_bonus_coin_win_total += bet_2 * seven_win_2 * 2;
            multi_reel_slot_1.style.border = "5px solid #ffe228";
            multi_reel_slot_7.style.border = "5px solid #ffe228";
            multi_reel_slot_13.style.border = "5px solid #ffe228";
            multi_reel_slot_9.style.border = "5px solid #ffe228";
            multi_reel_slot_5.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > SEVENS > $" + formatMoneyValue(bet_2 * seven_win_2 * 2), 3500);
        } else if (final_multi_slot_1_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_7_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_13_id.src.includes("triple-777-jackpot-green.svg")) { // 3 REEL SEVENS ROW 1,2,3 [diagonal] [slots 1,7,13]
            console.log("[3 REEL] SEVENS [ROW 1,2,3] [diagonal] [slots 1,7,13]");
            player_coins_balance += bet_2 * seven_win_2;
            free_spins_bonus_coin_win_total += bet_2 * seven_win_2;
            multi_reel_slot_1.style.border = "5px solid #ffe228";
            multi_reel_slot_7.style.border = "5px solid #ffe228";
            multi_reel_slot_13.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > SEVENS > $" + formatMoneyValue(bet_2 * seven_win_2), 3500);
        }
        if (final_multi_slot_11_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_7_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_3_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_9_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_15_id.src.includes("triple-777-jackpot-green.svg")) { // 5 REEL SEVENS ROW 1,2,3 [diagonal reverse 5 of a kind] [slots 11,7,3,9,15]
            console.log("[5 REEL] SEVENS [ROW 1,2,3] [diagonal reverse 5 of a kind] [slots 11,7,3,9,15]");
            player_coins_balance += bet_2 * seven_win_2 * 2;
            free_spins_bonus_coin_win_total += bet_2 * seven_win_2 * 2;
            multi_reel_slot_11.style.border = "5px solid #ffe228";
            multi_reel_slot_7.style.border = "5px solid #ffe228";
            multi_reel_slot_3.style.border = "5px solid #ffe228";
            multi_reel_slot_9.style.border = "5px solid #ffe228";
            multi_reel_slot_15.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > SEVENS > $" + formatMoneyValue(bet_2 * seven_win_2 * 2), 3500);
        } else if (final_multi_slot_11_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_7_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_3_id.src.includes("triple-777-jackpot-green.svg")) { // 3 REEL SEVENS ROW 1,2,3 [diagonal reverse] [slots 11,7,3]
            console.log("[3 REEL] SEVENS [ROW 1,2,3] [diagonal reverse] [slots 11,7,3]");
            player_coins_balance += bet_2 * seven_win_2;
            free_spins_bonus_coin_win_total += bet_2 * seven_win_2;
            multi_reel_slot_11.style.border = "5px solid #ffe228";
            multi_reel_slot_7.style.border = "5px solid #ffe228";
            multi_reel_slot_3.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > SEVENS > $" + formatMoneyValue(bet_2 * seven_win_2), 3500);
        }
        if (final_multi_slot_11_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_7_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_8_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_9_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_5_id.src.includes("triple-777-jackpot-green.svg")) { // 5 REEL SEVENS ROW 3,2 [diagonal zigzag 5 of a kind] [slots 11,7,8,9,5]
            console.log("[5 REEL] SEVENS [ROW 3,2] [diagonal zigzag 5 of a kind] [slots 11,7,8,9,5]");
            player_coins_balance += bet_2 * seven_win_2 * 2;
            free_spins_bonus_coin_win_total += bet_2 * seven_win_2 * 2;
            multi_reel_slot_11.style.border = "5px solid #ffe228";
            multi_reel_slot_7.style.border = "5px solid #ffe228";
            multi_reel_slot_8.style.border = "5px solid #ffe228";
            multi_reel_slot_9.style.border = "5px solid #ffe228";
            multi_reel_slot_5.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > SEVENS > $" + formatMoneyValue(bet_2 * seven_win_2 * 2), 3500);
        }
        if (final_multi_slot_1_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_7_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_8_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_9_id.src.includes("triple-777-jackpot-green.svg") && final_multi_slot_15_id.src.includes("triple-777-jackpot-green.svg")) { // 5 REEL SEVENS ROW 2,1 [diagonal reverse zigzag 5 of a kind] [slots 1,7,8,9,15]
            console.log("[5 REEL] SEVENS [ROW 2,1] [diagonal reverse zigzag 5 of a kind] [slots 1,7,8,9,15]");
            player_coins_balance += bet_2 * seven_win_2 * 2;
            free_spins_bonus_coin_win_total += bet_2 * seven_win_2 * 2;
            multi_reel_slot_1.style.border = "5px solid #ffe228";
            multi_reel_slot_7.style.border = "5px solid #ffe228";
            multi_reel_slot_8.style.border = "5px solid #ffe228";
            multi_reel_slot_9.style.border = "5px solid #ffe228";
            multi_reel_slot_15.style.border = "5px solid #ffe228";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > SEVENS > $" + formatMoneyValue(bet_2 * seven_win_2 * 2), 3500);
        }

        // CHERRIES PAYOUT COMBOS

        if (final_multi_slot_1_id.src.includes("cherry-symbol.svg") && final_multi_slot_2_id.src.includes("cherry-symbol.svg") && final_multi_slot_3_id.src.includes("cherry-symbol.svg") && final_multi_slot_4_id.src.includes("cherry-symbol.svg") && final_multi_slot_5_id.src.includes("cherry-symbol.svg")) { // 5 REEL CHERRIES ROW 1
            console.log("[5 REEL] CHERRIES [ROW 1]");
            player_cash_balance += bet_2 * cherry_win_2 * 2;
            total_spins_cash_earned += bet_2 * cherry_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * cherry_win_2 * 2;
            multi_reel_slot_1.style.border = "5px solid #E86D72";
            multi_reel_slot_2.style.border = "5px solid #E86D72";
            multi_reel_slot_3.style.border = "5px solid #E86D72";
            multi_reel_slot_4.style.border = "5px solid #E86D72";
            multi_reel_slot_5.style.border = "5px solid #E86D72";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > CHERRIES > $" + formatMoneyValue(bet_2 * cherry_win_2 * 2), 3500);
        } else if (final_multi_slot_1_id.src.includes("cherry-symbol.svg") && final_multi_slot_2_id.src.includes("cherry-symbol.svg") && final_multi_slot_3_id.src.includes("cherry-symbol.svg") && final_multi_slot_4_id.src.includes("cherry-symbol.svg")) { // 4 REEL CHERRIES ROW 1
            console.log("[4 REEL] CHERRIES [ROW 1]");
            player_cash_balance += bet_2 * cherry_win_2 * 1.5;
            total_spins_cash_earned += bet_2 * cherry_win_2 * 1.5;
            free_spins_bonus_cash_win_total += bet_2 * cherry_win_2 * 1.5;
            multi_reel_slot_1.style.border = "5px solid #E86D72";
            multi_reel_slot_2.style.border = "5px solid #E86D72";
            multi_reel_slot_3.style.border = "5px solid #E86D72";
            multi_reel_slot_4.style.border = "5px solid #E86D72";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > CHERRIES > $" + formatMoneyValue(bet_2 * cherry_win_2 * 1.5), 3500);
        } else if (final_multi_slot_1_id.src.includes("cherry-symbol.svg") && final_multi_slot_2_id.src.includes("cherry-symbol.svg") && final_multi_slot_3_id.src.includes("cherry-symbol.svg")) { // 3 REEL CHERRIES ROW 1
            console.log("[3 REEL] CHERRIES [ROW 1]");
            player_cash_balance += bet_2 * cherry_win_2;
            total_spins_cash_earned += bet_2 * cherry_win_2;
            free_spins_bonus_cash_win_total += bet_2 * cherry_win_2;
            multi_reel_slot_1.style.border = "5px solid #E86D72";
            multi_reel_slot_2.style.border = "5px solid #E86D72";
            multi_reel_slot_3.style.border = "5px solid #E86D72";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > CHERRIES > $" + formatMoneyValue(bet_2 * cherry_win_2), 3500);
        }

        if (final_multi_slot_6_id.src.includes("cherry-symbol.svg") && final_multi_slot_7_id.src.includes("cherry-symbol.svg") && final_multi_slot_8_id.src.includes("cherry-symbol.svg") && final_multi_slot_9_id.src.includes("cherry-symbol.svg") && final_multi_slot_10_id.src.includes("cherry-symbol.svg")) { // 5 REEL CHERRIES ROW 2
            console.log("[5 REEL] CHERRIES [ROW 2]");
            player_cash_balance += bet_2 * cherry_win_2 * 2;
            total_spins_cash_earned += bet_2 * cherry_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * cherry_win_2 * 2;
            multi_reel_slot_6.style.border = "5px solid #E86D72";
            multi_reel_slot_7.style.border = "5px solid #E86D72";
            multi_reel_slot_8.style.border = "5px solid #E86D72";
            multi_reel_slot_9.style.border = "5px solid #E86D72";
            multi_reel_slot_10.style.border = "5px solid #E86D72";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > CHERRIES > $" + formatMoneyValue(bet_2 * cherry_win_2 * 2), 3500);
        } else if (final_multi_slot_6_id.src.includes("cherry-symbol.svg") && final_multi_slot_7_id.src.includes("cherry-symbol.svg") && final_multi_slot_8_id.src.includes("cherry-symbol.svg") && final_multi_slot_9_id.src.includes("cherry-symbol.svg")) { // 4 REEL CHERRIES ROW 2
            console.log("[4 REEL] CHERRIES [ROW 2]");
            player_cash_balance += bet_2 * cherry_win_2 * 1.5;
            total_spins_cash_earned += bet_2 * cherry_win_2 * 1.5;
            free_spins_bonus_cash_win_total += bet_2 * cherry_win_2 * 1.5;
            multi_reel_slot_6.style.border = "5px solid #E86D72";
            multi_reel_slot_7.style.border = "5px solid #E86D72";
            multi_reel_slot_8.style.border = "5px solid #E86D72";
            multi_reel_slot_9.style.border = "5px solid #E86D72";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > CHERRIES > $" + formatMoneyValue(bet_2 * cherry_win_2 * 1.5), 3500);
        } else if (final_multi_slot_6_id.src.includes("cherry-symbol.svg") && final_multi_slot_7_id.src.includes("cherry-symbol.svg") && final_multi_slot_8_id.src.includes("cherry-symbol.svg")) { // 3 REEL CHERRIES ROW 2
            console.log("[3 REEL] CHERRIES [ROW 2]");
            player_cash_balance += bet_2 * cherry_win_2;
            total_spins_cash_earned += bet_2 * cherry_win_2;
            free_spins_bonus_cash_win_total += bet_2 * cherry_win_2;
            multi_reel_slot_6.style.border = "5px solid #E86D72";
            multi_reel_slot_7.style.border = "5px solid #E86D72";
            multi_reel_slot_8.style.border = "5px solid #E86D72";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > CHERRIES > $" + formatMoneyValue(bet_2 * cherry_win_2), 3500);
        }

        if (final_multi_slot_11_id.src.includes("cherry-symbol.svg") && final_multi_slot_12_id.src.includes("cherry-symbol.svg") && final_multi_slot_13_id.src.includes("cherry-symbol.svg") && final_multi_slot_14_id.src.includes("cherry-symbol.svg") && final_multi_slot_15_id.src.includes("cherry-symbol.svg")) { // 5 REEL CHERRIES ROW 3
            console.log("[5 REEL] CHERRIES [ROW 3]");
            player_cash_balance += bet_2 * cherry_win_2 * 2;
            total_spins_cash_earned += bet_2 * cherry_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * cherry_win_2 * 2;
            multi_reel_slot_11.style.border = "5px solid #E86D72";
            multi_reel_slot_12.style.border = "5px solid #E86D72";
            multi_reel_slot_13.style.border = "5px solid #E86D72";
            multi_reel_slot_14.style.border = "5px solid #E86D72";
            multi_reel_slot_15.style.border = "5px solid #E86D72";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > CHERRIES > $" + formatMoneyValue(bet_2 * cherry_win_2 * 2), 3500);
        } else if (final_multi_slot_11_id.src.includes("cherry-symbol.svg") && final_multi_slot_12_id.src.includes("cherry-symbol.svg") && final_multi_slot_13_id.src.includes("cherry-symbol.svg") && final_multi_slot_14_id.src.includes("cherry-symbol.svg")) { // 4 REEL CHERRIES ROW 3
            console.log("[4 REEL] CHERRIES [ROW 3]");
            player_cash_balance += bet_2 * cherry_win_2 * 1.5;
            total_spins_cash_earned += bet_2 * cherry_win_2 * 1.5;
            free_spins_bonus_cash_win_total += bet_2 * cherry_win_2 * 1.5;
            multi_reel_slot_11.style.border = "5px solid #E86D72";
            multi_reel_slot_12.style.border = "5px solid #E86D72";
            multi_reel_slot_13.style.border = "5px solid #E86D72";
            multi_reel_slot_14.style.border = "5px solid #E86D72";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > CHERRIES > $" + formatMoneyValue(bet_2 * cherry_win_2 * 1.5), 3500);
        } else if (final_multi_slot_11_id.src.includes("cherry-symbol.svg") && final_multi_slot_12_id.src.includes("cherry-symbol.svg") && final_multi_slot_13_id.src.includes("cherry-symbol.svg")) { // 3 REEL CHERRIES ROW 3
            console.log("[3 REEL] CHERRIES [ROW 3]");
            player_cash_balance += bet_2 * cherry_win_2;
            total_spins_cash_earned += bet_2 * cherry_win_2;
            free_spins_bonus_cash_win_total += bet_2 * cherry_win_2;
            multi_reel_slot_11.style.border = "5px solid #E86D72";
            multi_reel_slot_12.style.border = "5px solid #E86D72";
            multi_reel_slot_13.style.border = "5px solid #E86D72";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > CHERRIES > $" + formatMoneyValue(bet_2 * cherry_win_2), 3500);
        }

        if (final_multi_slot_1_id.src.includes("cherry-symbol.svg") && final_multi_slot_7_id.src.includes("cherry-symbol.svg") && final_multi_slot_13_id.src.includes("cherry-symbol.svg") && final_multi_slot_9_id.src.includes("cherry-symbol.svg") && final_multi_slot_5_id.src.includes("cherry-symbol.svg")) { // 5 REEL CHERRIES DIAGONAL [1,7,13,9,5]
            console.log("[5 REEL] CHERRIES [ROW 1,2,3] [diagonal 5 of a kind] [slots 1,7,13,9,5]");
            player_cash_balance += bet_2 * cherry_win_2 * 2;
            total_spins_cash_earned += bet_2 * cherry_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * cherry_win_2 * 2;
            multi_reel_slot_1.style.border = "5px solid #E86D72";
            multi_reel_slot_7.style.border = "5px solid #E86D72";
            multi_reel_slot_13.style.border = "5px solid #E86D72";
            multi_reel_slot_9.style.border = "5px solid #E86D72";
            multi_reel_slot_5.style.border = "5px solid #E86D72";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > CHERRIES > $" + formatMoneyValue(bet_2 * cherry_win_2 * 2), 3500);
        } else if (final_multi_slot_1_id.src.includes("cherry-symbol.svg") && final_multi_slot_7_id.src.includes("cherry-symbol.svg") && final_multi_slot_13_id.src.includes("cherry-symbol.svg")) { // 3 REEL CHERRIES DIAGONAL [1,7,13]
            console.log("[3 REEL] CHERRIES [ROW 1,2,3] [diagonal] [slots 1,7,13]");
            player_cash_balance += bet_2 * cherry_win_2;
            total_spins_cash_earned += bet_2 * cherry_win_2;
            free_spins_bonus_cash_win_total += bet_2 * cherry_win_2;
            multi_reel_slot_1.style.border = "5px solid #E86D72";
            multi_reel_slot_7.style.border = "5px solid #E86D72";
            multi_reel_slot_13.style.border = "5px solid #E86D72";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > CHERRIES > $" + formatMoneyValue(bet_2 * cherry_win_2), 3500);
        }

        if (final_multi_slot_11_id.src.includes("cherry-symbol.svg") && final_multi_slot_7_id.src.includes("cherry-symbol.svg") && final_multi_slot_3_id.src.includes("cherry-symbol.svg") && final_multi_slot_9_id.src.includes("cherry-symbol.svg") && final_multi_slot_15_id.src.includes("cherry-symbol.svg")) { // 5 REEL CHERRIES REVERSE DIAGONAL [11,7,3,9,15]
            console.log("[5 REEL] CHERRIES [ROW 1,2,3] [diagonal reverse 5 of a kind] [slots 11,7,3,9,15]");
            player_cash_balance += bet_2 * cherry_win_2 * 2;
            total_spins_cash_earned += bet_2 * cherry_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * cherry_win_2 * 2;
            multi_reel_slot_11.style.border = "5px solid #E86D72";
            multi_reel_slot_7.style.border = "5px solid #E86D72";
            multi_reel_slot_3.style.border = "5px solid #E86D72";
            multi_reel_slot_9.style.border = "5px solid #E86D72";
            multi_reel_slot_15.style.border = "5px solid #E86D72";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > CHERRIES > $" + formatMoneyValue(bet_2 * cherry_win_2 * 2), 3500);
        } else if (final_multi_slot_11_id.src.includes("cherry-symbol.svg") && final_multi_slot_7_id.src.includes("cherry-symbol.svg") && final_multi_slot_3_id.src.includes("cherry-symbol.svg")) { // 3 REEL CHERRIES REVERSE DIAGONAL [11,7,3]
            console.log("[3 REEL] CHERRIES [ROW 1,2,3] [diagonal reverse] [slots 11,7,3]");
            player_cash_balance += bet_2 * cherry_win_2;
            total_spins_cash_earned += bet_2 * cherry_win_2;
            free_spins_bonus_cash_win_total += bet_2 * cherry_win_2;
            multi_reel_slot_11.style.border = "5px solid #E86D72";
            multi_reel_slot_7.style.border = "5px solid #E86D72";
            multi_reel_slot_3.style.border = "5px solid #E86D72";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > CHERRIES > $" + formatMoneyValue(bet_2 * cherry_win_2), 3500);
        }

        if (final_multi_slot_11_id.src.includes("cherry-symbol.svg") && final_multi_slot_7_id.src.includes("cherry-symbol.svg") && final_multi_slot_8_id.src.includes("cherry-symbol.svg") && final_multi_slot_9_id.src.includes("cherry-symbol.svg") && final_multi_slot_5_id.src.includes("cherry-symbol.svg")) { // 5 REEL CHERRIES ZIGZAG [11,7,8,9,5]
            console.log("[5 REEL] CHERRIES [ROW 3,2] [diagonal zigzag 5 of a kind] [slots 11,7,8,9,5]");
            player_cash_balance += bet_2 * cherry_win_2 * 2;
            total_spins_cash_earned += bet_2 * cherry_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * cherry_win_2 * 2;
            multi_reel_slot_11.style.border = "5px solid #E86D72";
            multi_reel_slot_7.style.border = "5px solid #E86D72";
            multi_reel_slot_8.style.border = "5px solid #E86D72";
            multi_reel_slot_9.style.border = "5px solid #E86D72";
            multi_reel_slot_5.style.border = "5px solid #E86D72";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > CHERRIES > $" + formatMoneyValue(bet_2 * cherry_win_2 * 2), 3500);
        }

        if (final_multi_slot_1_id.src.includes("cherry-symbol.svg") && final_multi_slot_7_id.src.includes("cherry-symbol.svg") && final_multi_slot_8_id.src.includes("cherry-symbol.svg") && final_multi_slot_9_id.src.includes("cherry-symbol.svg") && final_multi_slot_15_id.src.includes("cherry-symbol.svg")) { // 5 REEL CHERRIES REVERSE ZIGZAG [1,7,8,9,15]
            console.log("[5 REEL] CHERRIES [ROW 2,1] [diagonal reverse zigzag 5 of a kind] [slots 1,7,8,9,15]");
            player_cash_balance += bet_2 * cherry_win_2 * 2;
            total_spins_cash_earned += bet_2 * cherry_win_2 * 2;
            free_spins_bonus_cash_win_total += bet_2 * cherry_win_2 * 2;
            multi_reel_slot_1.style.border = "5px solid #E86D72";
            multi_reel_slot_7.style.border = "5px solid #E86D72";
            multi_reel_slot_8.style.border = "5px solid #E86D72";
            multi_reel_slot_9.style.border = "5px solid #E86D72";
            multi_reel_slot_15.style.border = "5px solid #E86D72";
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WIN > CHERRIES > $" + formatMoneyValue(bet_2 * cherry_win_2 * 2), 3500);
        }
        
        for (let i = 0; i < final_multi_slot_id_storage.length; i++) {
            const reel = final_multi_slot_id_storage[i];

            if (reel.src.includes("slot-placeholder.svg")) {
                rareWinsRNG2(reel);

            if (reel.src.includes("slot-placeholder.svg")) {
                reel.src = base_symbol_refs[
                    Math.floor(Math.random() * base_symbol_refs.length)
                ];
            }
        }
}

        for (let i = 0; i < final_multi_slot_id_storage.length; i++) {
            if (final_multi_slot_id_storage[i].src.includes("star-symbol.svg")) {
                const increased_bet_return = bet_2 * 2;
                player_cash_balance += increased_bet_return;

                smallDingAudio();
                notificationDialog("WIN > STAR > $" + formatMoneyValue(increased_bet_return), 3500);
                final_multi_slot_id_storage[i].style.border = "5px solid springgreen";
            }
        }
    }, multi_reel_spin_time)
}