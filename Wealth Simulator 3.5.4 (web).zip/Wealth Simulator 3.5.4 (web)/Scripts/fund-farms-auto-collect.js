let farm_1_auto_opt = document.getElementById("farm-1-auto-btn");
let farm_2_auto_opt = document.getElementById("farm-2-auto-btn");
let farm_3_auto_opt = document.getElementById("farm-3-auto-btn");
let farm_4_auto_opt = document.getElementById("farm-4-auto-btn");
let farm_5_auto_opt = document.getElementById("farm-5-auto-btn");
let farm_6_auto_opt = document.getElementById("farm-6-auto-btn");

let tier_2_farm_1_auto_opt = document.getElementById("tier-2-farm-1-auto-btn");
let tier_2_farm_2_auto_opt = document.getElementById("tier-2-farm-2-auto-btn");
let tier_2_farm_3_auto_opt = document.getElementById("tier-2-farm-3-auto-btn");
let tier_2_farm_4_auto_opt = document.getElementById("tier-2-farm-4-auto-btn");
let tier_2_farm_5_auto_opt = document.getElementById("tier-2-farm-5-auto-btn");
let tier_2_farm_6_auto_opt = document.getElementById("tier-2-farm-6-auto-btn");

let tier_3_farm_1_auto_opt = document.getElementById("tier-3-farm-1-auto-btn");
let tier_3_farm_2_auto_opt = document.getElementById("tier-3-farm-2-auto-btn");
let tier_3_farm_3_auto_opt = document.getElementById("tier-3-farm-3-auto-btn");
let tier_3_farm_4_auto_opt = document.getElementById("tier-3-farm-4-auto-btn");
let tier_3_farm_5_auto_opt = document.getElementById("tier-3-farm-5-auto-btn");
let tier_3_farm_6_auto_opt = document.getElementById("tier-3-farm-6-auto-btn");

let farm_1_auto_state = false;
let farm_2_auto_state = false;
let farm_3_auto_state = false;
let farm_4_auto_state = false;
let farm_5_auto_state = false;
let farm_6_auto_state = false;

let tier_2_farm_1_auto_state = false;
let tier_2_farm_2_auto_state = false;
let tier_2_farm_3_auto_state = false;
let tier_2_farm_4_auto_state = false;
let tier_2_farm_5_auto_state = false;
let tier_2_farm_6_auto_state = false;

let tier_3_farm_1_auto_state = false;
let tier_3_farm_2_auto_state = false;
let tier_3_farm_3_auto_state = false;
let tier_3_farm_4_auto_state = false;
let tier_3_farm_5_auto_state = false;
let tier_3_farm_6_auto_state = false;

// Auto-click interval refs (set when auto-collect is active)

let farm_1_auto_int = null;
let farm_2_auto_int = null;
let farm_3_auto_int = null;
let farm_4_auto_int = null;
let farm_5_auto_int = null;
let farm_6_auto_int = null;

let tier_2_farm_1_auto_int = null;
let tier_2_farm_2_auto_int = null;
let tier_2_farm_3_auto_int = null;
let tier_2_farm_4_auto_int = null;
let tier_2_farm_5_auto_int = null;
let tier_2_farm_6_auto_int = null;

let tier_3_farm_1_auto_int = null;
let tier_3_farm_2_auto_int = null;
let tier_3_farm_3_auto_int = null;
let tier_3_farm_4_auto_int = null;
let tier_3_farm_5_auto_int = null;
let tier_3_farm_6_auto_int = null;

let farm_1_auto_price = 10;
let farm_2_auto_price = 20;
let farm_3_auto_price = 40;
let farm_4_auto_price = 80;
let farm_5_auto_price = 120;
let farm_6_auto_price = 200;

let tier_2_farm_1_auto_price = 30;
let tier_2_farm_2_auto_price = 60;
let tier_2_farm_3_auto_price = 120;
let tier_2_farm_4_auto_price = 240;
let tier_2_farm_5_auto_price = 360;
let tier_2_farm_6_auto_price = 480;

let tier_3_farm_1_auto_price = 200;
let tier_3_farm_2_auto_price = 500;
let tier_3_farm_3_auto_price = 700;
let tier_3_farm_4_auto_price = 900;
let tier_3_farm_5_auto_price = 1200;
let tier_3_farm_6_auto_price = 1500;

let farm_auto_price_output = document.getElementById("farm-auto-perk-price-output");
let farm_auto_row_output = document.getElementById("farm-auto-row-output");
let farm_auto_purchase_opt = document.getElementById("farm-purchase-auto-btn");

let farm_auto_collect_dialog_overlay = document.getElementById("farm-auto-collect-dialog-overlay");
let close_farm_auto_collect_dialog_btn = document.getElementById("close-farm-auto-collect-dialog-btn");
let farm_purchase_auto_btn = document.getElementById("farm-purchase-auto-btn");

let close_farm_auto_collect_btn = document.getElementById("close-farm-auto-collect-dialog-btn");

close_farm_auto_collect_dialog_btn.onclick = function() {
    farm_auto_collect_dialog_overlay.style.display = "none";
}

farm_1_auto_opt.onclick = function() {
    purchaseFarmAutoCollect(farm_1_auto_opt, farm_auto_collect_dialog_overlay, "Tier 1 Farm 1 > Auto-Collect", farm_purchase_auto_btn, farm_1_auto_price, "farm_1_auto_state", farm_1_collect_opt);
}

farm_2_auto_opt.onclick = function() {
    purchaseFarmAutoCollect(farm_2_auto_opt, farm_auto_collect_dialog_overlay, "Tier 1 Farm 2 > Auto-Collect", farm_purchase_auto_btn, farm_2_auto_price, "farm_2_auto_state", farm_2_collect_opt);
}

farm_3_auto_opt.onclick = function() {
    purchaseFarmAutoCollect(farm_3_auto_opt, farm_auto_collect_dialog_overlay, "Tier 1 Farm 3 > Auto-Collect", farm_purchase_auto_btn, farm_3_auto_price, "farm_3_auto_state", farm_3_collect_opt);
}

farm_4_auto_opt.onclick = function() {
    purchaseFarmAutoCollect(farm_4_auto_opt, farm_auto_collect_dialog_overlay, "Tier 1 Farm 4 > Auto-Collect", farm_purchase_auto_btn, farm_4_auto_price, "farm_4_auto_state", farm_4_collect_opt);
}

farm_5_auto_opt.onclick = function() {
    purchaseFarmAutoCollect(farm_5_auto_opt, farm_auto_collect_dialog_overlay, "Tier 1 Farm 5 > Auto-Collect", farm_purchase_auto_btn, farm_5_auto_price, "farm_5_auto_state", farm_5_collect_opt);
}

farm_6_auto_opt.onclick = function() {
    purchaseFarmAutoCollect(farm_6_auto_opt, farm_auto_collect_dialog_overlay, "Tier 1 Farm 6 > Auto-Collect", farm_purchase_auto_btn, farm_6_auto_price, "farm_6_auto_state", farm_6_collect_opt);
}

tier_2_farm_1_auto_opt.onclick = function() {
    purchaseFarmAutoCollect(tier_2_farm_1_auto_opt, farm_auto_collect_dialog_overlay, "Tier 2 Farm 1 > Auto-Collect", farm_purchase_auto_btn, tier_2_farm_1_auto_price, "tier_2_farm_1_auto_state", tier_2_farm_1_collect_opt);
}

tier_2_farm_2_auto_opt.onclick = function() {
    purchaseFarmAutoCollect(tier_2_farm_2_auto_opt, farm_auto_collect_dialog_overlay, "Tier 2 Farm 2 > Auto-Collect", farm_purchase_auto_btn, tier_2_farm_2_auto_price, "tier_2_farm_2_auto_state", tier_2_farm_2_collect_opt);
}

tier_2_farm_3_auto_opt.onclick = function() {
    purchaseFarmAutoCollect(tier_2_farm_3_auto_opt, farm_auto_collect_dialog_overlay, "Tier 2 Farm 3 > Auto-Collect", farm_purchase_auto_btn, tier_2_farm_3_auto_price, "tier_2_farm_3_auto_state", tier_2_farm_3_collect_opt);
}

tier_2_farm_4_auto_opt.onclick = function() {
    purchaseFarmAutoCollect(tier_2_farm_4_auto_opt, farm_auto_collect_dialog_overlay, "Tier 2 Farm 4 > Auto-Collect", farm_purchase_auto_btn, tier_2_farm_4_auto_price, "tier_2_farm_4_auto_state", tier_2_farm_4_collect_opt);
}

tier_2_farm_5_auto_opt.onclick = function() {
    purchaseFarmAutoCollect(tier_2_farm_5_auto_opt, farm_auto_collect_dialog_overlay, "Tier 2 Farm 5 > Auto-Collect", farm_purchase_auto_btn, tier_2_farm_5_auto_price, "tier_2_farm_5_auto_state", tier_2_farm_5_collect_opt);
}

tier_2_farm_6_auto_opt.onclick = function() {
    purchaseFarmAutoCollect(tier_2_farm_6_auto_opt, farm_auto_collect_dialog_overlay, "Tier 2 Farm 6 > Auto-Collect", farm_purchase_auto_btn, tier_2_farm_6_auto_price, "tier_2_farm_6_auto_state", tier_2_farm_6_collect_opt);
}

tier_3_farm_1_auto_opt.onclick = function() {
    purchaseFarmAutoCollect(tier_3_farm_1_auto_opt, farm_auto_collect_dialog_overlay, "Tier 3 Farm 1 > Auto-Collect", farm_purchase_auto_btn, tier_3_farm_1_auto_price, "tier_3_farm_1_auto_state", tier_3_farm_1_collect_opt);
}

tier_3_farm_2_auto_opt.onclick = function() {
    purchaseFarmAutoCollect(tier_3_farm_2_auto_opt, farm_auto_collect_dialog_overlay, "Tier 3 Farm 2 > Auto-Collect", farm_purchase_auto_btn, tier_3_farm_3_auto_price, "tier_3_farm_2_auto_state", tier_3_farm_2_collect_opt);
}

tier_3_farm_3_auto_opt.onclick = function() {
    purchaseFarmAutoCollect(tier_3_farm_3_auto_opt, farm_auto_collect_dialog_overlay, "Tier 3 Farm 3 > Auto-Collect", farm_purchase_auto_btn, tier_3_farm_3_auto_price, "tier_3_farm_3_auto_state", tier_3_farm_3_collect_opt);
}

tier_3_farm_4_auto_opt.onclick = function() {
    purchaseFarmAutoCollect(tier_3_farm_4_auto_opt, farm_auto_collect_dialog_overlay, "Tier 3 Farm 4 > Auto-Collect", farm_purchase_auto_btn, tier_3_farm_4_auto_price, "tier_3_farm_4_auto_state", tier_3_farm_4_collect_opt);
}

tier_3_farm_5_auto_opt.onclick = function() {
    purchaseFarmAutoCollect(tier_3_farm_5_auto_opt, farm_auto_collect_dialog_overlay, "Tier 3 Farm 5 > Auto-Collect", farm_purchase_auto_btn, tier_3_farm_5_auto_price, "tier_3_farm_5_auto_state", tier_3_farm_5_collect_opt);
}

tier_3_farm_6_auto_opt.onclick = function() {
    purchaseFarmAutoCollect(tier_3_farm_6_auto_opt, farm_auto_collect_dialog_overlay, "Tier 3 Farm 6 > Auto-Collect", farm_purchase_auto_btn, tier_3_farm_6_auto_price, "tier_3_farm_6_auto_state", tier_3_farm_6_collect_opt);
}