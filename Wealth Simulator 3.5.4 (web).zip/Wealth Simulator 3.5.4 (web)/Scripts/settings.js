// PREFERENCES & SETTINGS

let shortcut_keyboard_binds_preference = document.getElementById("shortcut-keybinds-preference");
let slots_malfunction_repair_preference = document.getElementById("slots-malfunction-repair-preference");
let winline_highlighting_preference = document.getElementById("winline-highlighting-preference");
let farm_percent_progress_preference = document.getElementById("farm-percent-progress-preference");

let mute_farm_collect_click_sfx_preference = document.getElementById("mute-farm-collect-click-sfx-preference");
let mute_trivia_clock_sfx_preference = document.getElementById("mute-trivia-clock-sfx-preference");

let auto_next_question_trigger_preference = document.getElementById("auto-next-question-trigger-preference");
let level_xp_grant_output_preference = document.getElementById("level-xp-grant-output-preference");
let reel_alternation_animation_preference = document.getElementById("reel-alternation-animation-preference");
let hide_main_balances_tab_preference = document.getElementById("hide-main-balances-tab-preference");
let reel_border_shadow_preference = document.getElementById("reel-border-shadow-preference");

let winlineRestrictions;

// ACTIVITY STATES

let shortcut_keyboard_binds_preference_active = false;
let reel_spin_sync_preference_active = false;
let farm_percent_progress_preference_active = false;
let mute_farm_collect_click_sfx_preference_active = false;
let mute_trivia_clock_sfx_preference_active = false;
let auto_next_question_trigger_preference_active = false;
let level_xp_grant_output_preference_active = false;
let reel_alternation_animation_preference_active = false;
let reel_border_shadow_preference_active = false;

function handleSpinKeybinds(event) {
    if (event.key === " ") {
        spin_btn.click();
    } else if (event.key === "a") {
        auto_spin_btn.click();
    } else if (event.key === "s") {
        stop_auto_spin_btn.click();
        if (auto_spin_active === false) {
            stop_auto_spin_btn.disabled = true;
            stop_auto_spin_btn.style.cursor = "not-allowed";
            stop_auto_spin_btn.style.opacity = "0.5";
        }
    }
}

function menuOptsShortcuts(e) {
    switch (e.key) {
        case "c": console_ui_menu_opt.click(); break // "C" opens console
        case "g": gambling_hub_menu_opt_btn.click(); // "g" opens gambling menu
    }
}

function handleFarmKeybinds(event) {
    if (event.key === "1") {
        farm_1_collect_opt.click();
    } else if (event.key === "2") {
        farm_2_collect_opt.click();
    } else if (event.key === "3") {
        farm_3_collect_opt.click();
    } else if (event.key === "4") {
        farm_4_collect_opt.click();
    } else if (event.key === "5") {
        farm_5_collect_opt.click();
    } else if (event.key === "6") {
        farm_6_collect_opt.click();
    }
}

function enableShortcutKeybinds() {
    document.addEventListener("keydown", handleSpinKeybinds);
    document.addEventListener("keydown", handleFarmKeybinds);
    document.addEventListener("keydown", menuOptsShortcuts);
}

function disableShortcutKeybinds() {
    document.removeEventListener("keydown", handleSpinKeybinds);
    document.removeEventListener("keydown", handleFarmKeybinds);
    document.removeEventListener("keydown", menuOptsShortcuts);
}

mute_trivia_clock_sfx_preference.addEventListener("click", () => { 
    if (mute_trivia_clock_sfx_preference.checked) {
        oscClickAudio();
        mute_trivia_clock_sfx_preference_active = true;
        document.getElementById("sfx-mute-4").innerHTML = "<span style='color: red;'>MUTED</span>";
        document.getElementById("clock-tick-sfx").muted = true; notificationDialog("Audio Muted!", 3000);
    } else {
        oscClickAudio();
        mute_trivia_clock_sfx_preference_active = false;
        document.getElementById("sfx-mute-4").innerHTML = "<span style='color: lime;'>UNMUTED</span>";
        document.getElementById("clock-tick-sfx").muted = false; notificationDialog("Audio Unmuted!", 3000);
    }
});

mute_farm_collection_sfx_opt.addEventListener("click", () => { 
    if (mute_farm_collection_sfx_opt.checked) {
        oscClickAudio();
        mute_farm_collection_sfx_opt_active = true;
        document.getElementById("sfx-mute-1").innerHTML = "<span style='color: red;'>MUTED</span>";
        document.getElementById("collect-farm-sfx").muted = true; notificationDialog("Audio Muted!", 3000);
    } else {
        oscClickAudio();
        mute_farm_collection_sfx_opt_active = false;
        document.getElementById("sfx-mute-1").innerHTML = "<span style='color: lime;'>UNMUTED</span>";
        document.getElementById("collect-farm-sfx").muted = false; notificationDialog("Audio Unmuted!", 3000);
    }
});

mute_farm_collect_click_sfx_preference.onclick = function() {
    if (mute_farm_collect_click_sfx_preference.checked) {
        mute_farm_collect_click_sfx_preference_active = true;
        osc_sfx_active = false;
        oscillator.disconnect(audio_ctx.destination);
        document.getElementById("sfx-mute-2").innerHTML = "<span style='color: red;'>MUTED</span>";
        notificationDialog("[ENABLED] > FARM COLLECT OSCILLATOR CLICK SFX MUTED", 3000);
    } else {
        mute_farm_collect_click_sfx_preference_active = false;
        osc_sfx_active = true;
        document.getElementById("sfx-mute-2").innerHTML = "<span style='color: lime;'>UNMUTED</span>";
        oscillator.connect(audio_ctx.destination);
        notificationDialog("[DISABLED] > FARM COLLECT OSCILLATOR CLICK SFX RESTORED", 3000);
    }
}

mute_reel_spin_sfx_opt.addEventListener("click", () => { 
    if (mute_reel_spin_sfx_opt.checked) {
        oscClickAudio();
        document.getElementById("sfx-mute-3").textContent = "MUTED";
        document.getElementById("sfx-mute-3").style.color = "red";
        document.getElementById("spinning-sfx").muted = true; notificationDialog("Audio Muted!", 3000);
    } else {
        oscClickAudio();
        document.getElementById("sfx-mute-3").textContent = "UNMUTED";
        document.getElementById("sfx-mute-3").style.color = "lime";
        document.getElementById("spinning-sfx").muted = false; notificationDialog("Audio Unmuted!", 3000);
    }
});

winline_highlighting_preference.addEventListener("change", function toggleWinlineHighlighting() {
    if (winline_highlighting_preference.checked) {
        clearInterval(winlineRestrictions);
        oscClickAudio();
        keyboardClickAudio();
        notificationDialog("[Success]: Winline highlighting enabled!", 1500);
    } else {
        winlineRestrictions = setInterval(() => {
            for (let i = 0; i < multi_reels_storage.length; i++) {
                multi_reels_storage[i].style.border = "3px solid black";
            }
            for (let i = 0; i < multi_slot_symbols.length; i++) {
                multi_slot_symbols[i].style.border = "3px solid black";
            }
        }, 10)
        oscClickAudio();
        keyboardClickAudio();
        notificationDialog("[Success]: Winline highlighting disabled!", 1500);
    }
})

shortcut_keyboard_binds_preference.addEventListener("change", function shortcutKeybinds() {
    if (shortcut_keyboard_binds_preference.checked) {
        notificationDialog("[Success]: Shortcut control keybinds enabled!", 3500);
        shortcut_keyboard_binds_preference_active = true;
        oscClickAudio();
        enableShortcutKeybinds();
    } else {
        notificationDialog("[Success]: Shortcut control keybinds disabled!", 3500);
        shortcut_keyboard_binds_preference_active = false;
        disableShortcutKeybinds();
        oscClickAudio();
    }
})

farm_percent_progress_preference.addEventListener("change", function displayFarmPercentProgress() {
    if (farm_percent_progress_preference.checked) {
        notificationDialog("[Success]: Farm percentage progress outputs displayed!", 3000);
        farm_percent_progress_display_enabled = true;
        for (let i = 0; i < gen_farm_percent_progress_displays_storage.length; i++) {
            gen_farm_percent_progress_displays_storage[i].style.display = "flex";
        }
        oscClickAudio();
        notificationDialog("REDIRECTING..", 1500);
        setTimeout(() => { fund_farms_opt_btn.click(); }, 2000)
    } else {
        notificationDialog("[Success]: Farm percentage progress hidden!", 3500);
        keyboardClickAudio();
        farm_percent_progress_display_enabled = false;
        for (let i = 0; i < gen_farm_percent_progress_displays_storage.length; i++) {
            gen_farm_percent_progress_displays_storage[i].style.display = "none";
        }
    }
})

// 3 & 15 REEL SLOT REPAIR / RESET SEQUENCE

slots_malfunction_repair_preference.addEventListener("change", function repairSlotMalfunctions() {
    if (slots_malfunction_repair_preference.checked) {
        oscClickAudio();
        stop_auto_spin_btn.click();
        stop_auto_spin_2_btn.click();
        setTimeout(() => {
            notificationDialog("STARTING FULL REPAIRS..", 2000);
            disableGamblingControls();
            disableGamblingControls2();
            stop_auto_spin_btn.click();
            stop_auto_spin_2_btn.click();
            close_settings_ui_btn.click();
            setTimeout(() => {
                document.getElementById("slot-selection-dialog-overlay").style.display = "flex";
                document.getElementById("3-reel-slot-opt").click();
                disableGamblingControls();
                disableGamblingControls2();
                setTimeout(() => {
                    document.getElementById("slot-symbol-1").src = "Images/slot-placeholder.svg";
                    document.getElementById("slot-symbol-2").src = "Images/slot-placeholder.svg";
                    document.getElementById("slot-symbol-3").src = "Images/slot-placeholder.svg";
                    disableGamblingControls();
                    disableGamblingControls2();
                }, 1000)
                setTimeout(() => { document.getElementById("15-reel-slot-opt").click(); }, 2500)
                setTimeout(() => { notificationDialog("TERMINATING ONGOING PROCESSES..", 1500); }, 1000)
                setTimeout(() => { 
                    notificationDialog("RESETING ONGOING SPIN INTERVALS..");
                    clearInterval(slot_1_int);
                    clearInterval(slot_2_int);
                    clearInterval(slot_3_int);
                    clearInterval(multi_slot_1_int);
                    clearInterval(multi_slot_2_int);
                    clearInterval(multi_slot_3_int);
                    clearInterval(multi_slot_4_int);
                    clearInterval(multi_slot_5_int);
                    clearInterval(multi_slot_6_int);
                    clearInterval(multi_slot_7_int);
                    clearInterval(multi_slot_8_int);
                    clearInterval(multi_slot_9_int);
                    clearInterval(multi_slot_10_int);
                    clearInterval(multi_slot_11_int);
                    clearInterval(multi_slot_12_int);
                    clearInterval(multi_slot_13_int);
                    clearInterval(multi_slot_14_int);
                    clearInterval(multi_slot_15_int);
                    stop_auto_spin_btn.click();
                    stop_auto_spin_2_btn.click();
                    disableGamblingControls();
                    disableGamblingControls2();
                    document.getElementById("slot-symbol-1").src = "Images/slot-placeholder.svg";
                    document.getElementById("slot-symbol-2").src = "Images/slot-placeholder.svg";
                    document.getElementById("slot-symbol-3").src = "Images/slot-placeholder.svg";
                    document.getElementById("multi-slot-symbol-1").src = "Images/slot-placeholder.svg";
                    document.getElementById("multi-slot-symbol-2").src = "Images/slot-placeholder.svg";
                    document.getElementById("multi-slot-symbol-3").src = "Images/slot-placeholder.svg";
                    document.getElementById("multi-slot-symbol-4").src = "Images/slot-placeholder.svg";
                    document.getElementById("multi-slot-symbol-5").src = "Images/slot-placeholder.svg";
                    document.getElementById("multi-slot-symbol-6").src = "Images/slot-placeholder.svg";
                    document.getElementById("multi-slot-symbol-7").src = "Images/slot-placeholder.svg";
                    document.getElementById("multi-slot-symbol-8").src = "Images/slot-placeholder.svg";
                    document.getElementById("multi-slot-symbol-9").src = "Images/slot-placeholder.svg";
                    document.getElementById("multi-slot-symbol-10").src = "Images/slot-placeholder.svg";
                    document.getElementById("multi-slot-symbol-11").src = "Images/slot-placeholder.svg";
                    document.getElementById("multi-slot-symbol-12").src = "Images/slot-placeholder.svg";
                    document.getElementById("multi-slot-symbol-13").src = "Images/slot-placeholder.svg";
                    document.getElementById("multi-slot-symbol-14").src = "Images/slot-placeholder.svg";
                    document.getElementById("multi-slot-symbol-15").src = "Images/slot-placeholder.svg";

                    for (let i = 0; i < multi_reels_storage.length; i++) { multi_reels_storage[i].style.border = "3px solid snow"; }
                    for (let i = 0; i < final_multi_slot_id_storage.length; i++) { final_multi_slot_id_storage[i].style.border = "none"; }

                    slots_malfunction_repair_preference.click();
                    setTimeout(() => { notificationDialog("REPAIR ATTEMPT COMPLETED..", 3000); }, 1000)
                    setTimeout(() => { enableGamblingControls(); enableGamblingControls2(); }, 10000)
                }, 2500)
            }, 1500)
        }, 1000)
    }
})

auto_next_question_trigger_preference.addEventListener("click", () => {
    if (auto_next_question_trigger_preference.checked) {
        auto_next_question_trigger_preference_active = true;
        notificationDialog("[ENABLED] > NEXT QUESTION WILL BE AUTOMATICALLY TRIGGERED", 3000);
        oscClickAudio();
    } else {
        oscClickAudio();
        auto_next_question_trigger_preference_active = false;
        notificationDialog("[DISABLED] > NEXT QUESTION MANUAL METHOD RESTORED", 3500);
    }
})

level_xp_grant_output_preference.onclick = function() {
    if (level_xp_grant_output_preference.checked) {
        level_xp_grant_output_preference_active = true;
        notificationDialog("[ENABLED] > XP GRANTS WILL NOW BE DISPLAYED BESIDE THE LEVEL BAR", 3000);
        oscClickAudio();
    } else {
        level_xp_grant_output_preference_active = false;
        notificationDialog("[DISABLED] > XP GRANTS OUTPUT HIDDEN", 3000);
        oscClickAudio();
    }
}

function enableReelAlternationAnimation(reel) {
    reel.style.animationName = "reel-rotation";
    reel.style.animationDuration = "4s";
    reel.style.animationTimingFunction = "linear";
    reel.style.animationDirection = "alternate";
    reel.style.animationIterationCount = "infinite";
}

reel_alternation_animation_preference.addEventListener("change", function() {
    if (reel_alternation_animation_preference.checked) {
        reel_alternation_animation_preference_active = true;

        notificationDialog("[ENABLED] > REEL ALTERNATION ANIMATION ENABLED", 3000);
    } else {
        reel_alternation_animation_preference_active = false;

        endReelRotation();
        notificationDialog("[DISABLED] > REEL ALTERNATION ANIMATION DISABLED", 3000);
    }

    oscClickAudio();
});

reel_border_shadow_preference.addEventListener("change", function() {
    if (reel_border_shadow_preference.checked) {
        reel_border_shadow_preference_active = false;

        for (let i = 0; i < multi_reels_storage.length; i++) { multi_reels_storage[i].style.border = "1.8px solid whitesmoke"; multi_reels_storage[i].style.boxShadow = "rgba(168, 255, 221) 0 0 1px 1px"; }
        for (let i = 0; i < reels_storage.length; i++) { reels_storage[i].style.border = "1.8px solid whitesmoke"; reels_storage[i].style.boxShadow = "rgba(168, 255, 221) 0 0 1px 1px"; }

        oscClickAudio();
        notificationDialog("[ENABLED] > REEL BORDERS & SHADOWS RESTORED!", 3000);
    } else {
        reel_border_shadow_preference_active = true;

        for (let i = 0; i < multi_reels_storage.length; i++) { multi_reels_storage[i].style.border = "none"; multi_reels_storage[i].style.boxShadow = "none"; }
        for (let i = 0; i < reels_storage.length; i++) { reels_storage[i].style.border = "none"; reels_storage[i].style.boxShadow = "none"; }

        oscClickAudio();
        notificationDialog("[DISABLED] > REEL BORDERS & SHADOWS REMOVED!", 3000);
    }
});

hide_main_balances_tab_preference.onclick = function() {
    if (hide_main_balances_tab_preference.checked) {
        hide_main_balances_tab_preference_active = true;
        document.getElementById("currencies-hotbar").style.display = "none";
        document.getElementById("main-cont-output-ui").style.marginTop = "15px;";
        notificationDialog("[ENABLED] > MAIN BALANCES HOTBAR HIDDEN", 3000);
        oscClickAudio();
    } else {
        hide_main_balances_tab_preference_active = false;
        document.getElementById("currencies-hotbar").style.display = "flex";
        document.getElementById("main-cont-output-ui").style.marginTop = "0px;";
        notificationDialog("[DISABLED] > MAIN BALANCES HOTBAR RESTORED", 3000);
        oscClickAudio();
    }
}