let level_hub_dialog_overlay = document.getElementById("level-hub-dialog-overlay");
let close_level_hub_dialog_overlay_btn = document.getElementById("close-level-hub-dialog-overlay-btn");

let level_hub_lvl_bar = document.getElementById("level-hub-lvl-bar");
let lvl_bar_current_progress_output = document.getElementById("lvl-bar-current-progress-output");
let lvl_bar_next_lvl_req_output = document.getElementById("lvl-bar-next-lvl-req-output");

let player_lvl = 1;
let player_lvl_progress_bar_value = document.getElementById("player-lvl-progress-bar");
let player_lvl_progress_max = 100;
let player_lvl_progress_value = 0;
let player_lvl_increase_mult = 1.2;
let next_lvl_req = player_lvl_progress_max * player_lvl_increase_mult;

let def_lvl_up_cash_award = 2.50;
let def_lvl_up_coin_award = 2;

let def_lvl_up_cash_award_mult = 1.2;
let def_lvl_up_coin_award_mult = 2;

let double_xp_active = false;
let modifiersUnlockedNotified = true;

let milestone_claim_opt_1 = document.getElementById("milestone-claim-opt-1");
let milestone_claim_opt_2 = document.getElementById("milestone-claim-opt-2");
let milestone_claim_opt_3 = document.getElementById("milestone-claim-opt-3");
let milestone_claim_opt_4 = document.getElementById("milestone-claim-opt-4");
let milestone_claim_opt_5 = document.getElementById("milestone-claim-opt-5");
let milestone_claim_opt_6 = document.getElementById("milestone-claim-opt-6");

let milestone_lvl_5_reached = false;
let milestone_lvl_10_reached = false;
let milestone_lvl_20_reached = false;
let milestone_lvl_30_reached = false;
let milestone_lvl_40_reached = false;
let milestone_lvl_50_reached = false;

let milestone_claim_opts_storage = [milestone_claim_opt_1, milestone_claim_opt_2, milestone_claim_opt_3, milestone_claim_opt_4, milestone_claim_opt_5, milestone_claim_opt_6];
let milestone_lvl_reached_status_storage = [milestone_lvl_5_reached, milestone_lvl_10_reached, milestone_lvl_20_reached, milestone_lvl_30_reached, milestone_lvl_40_reached, milestone_lvl_50_reached];

document.getElementById("lvl-block").onclick = function() { level_hub_dialog_overlay.style.display = "flex"; }
close_level_hub_dialog_overlay_btn.onclick = function() { level_hub_dialog_overlay.style.display = "none"; }

milestone_claim_opt_1.onclick = function() { levelMilestoneClaim(milestone_claim_opt_1, 25, 20); }
milestone_claim_opt_2.onclick = function() { levelMilestoneClaim(milestone_claim_opt_2, 100, 40); }
milestone_claim_opt_3.onclick = function() { levelMilestoneClaim(milestone_claim_opt_3, 250, 100); }
milestone_claim_opt_4.onclick = function() { levelMilestoneClaim(milestone_claim_opt_4, 500, 200); }
milestone_claim_opt_5.onclick = function() { levelMilestoneClaim(milestone_claim_opt_5, 1000, 400); }
milestone_claim_opt_6.onclick = function() { levelMilestoneClaim(milestone_claim_opt_6, 2500, 1000); }

function levelMilestoneChecker(milestone_opt, milestone_lvl_reached, milestone_level, previous_level) {
    if (milestone_lvl_reached) {
        milestone_opt.disabled = false; milestone_opt.style.opacity = "1"; milestone_opt.style.cursor = "pointer";
        milestone_opt.innerHTML = "CLAIM";
        if (previous_level < milestone_level) {
            notificationDialog("[#] > LEVEL [" + milestone_level + "] MILESTONE REACHED!", 3500);
            //levelMilestoneAudio();
        }
    }
}

function levelMilestoneClaim(milestone_opt, milestone_award_1, milestone_award_2, milestone_award_3) {
    milestone_opt.addEventListener("click", () => {
        const award_panel = document.createElement("section");
        award_panel.className = "dialog-overlay";
        award_panel.style.backgroundImage = "linear-gradient(rgba(0, 0, 0, 0.9), rgba(0, 0, 0, 0.9))";
        award_panel.style.width = "700px";
        award_panel.style.height = "400px";
        award_panel.style.display = "flex";
        award_panel.style.flexDirection = "column";
        award_panel.style.justifyContent = "center";
        award_panel.style.alignItems = "center";
        award_panel.innerHTML = "<span style='color: springgreen'>Cash</span> >> <span style='color: springgreen;'>$" + formatMoneyValue(milestone_award_1) + "</span>" + "<br>" + "<span style='color: yellow;'>Coins</span> >> <span style='color: yellow;'>" + formatDisplayNumber(milestone_award_2) + "</span>" +
        "<br>" + "Booster >> " + milestone_award_3;
        document.getElementById("level-hub-opt").appendChild(award_panel);
    });
}

function updatePlayerLvlProgressUI() {
    player_lvl_progress_bar_value.max = player_lvl_progress_max;
    player_lvl_progress_bar_value.value = Math.min(player_lvl_progress_value, player_lvl_progress_max);

    level_hub_lvl_bar.value = player_lvl_progress_value;
    lvl_bar_current_progress_output.innerHTML = "Current Level > <span style='color: springgreen;'> " + player_lvl;
}

function processPlayerLvlOverflow() {
    let levels_gained = 0;
    let previous_level = player_lvl;

    while (player_lvl_progress_value >= player_lvl_progress_max) {
        player_lvl_progress_value -= player_lvl_progress_max;
        player_lvl++;

        def_lvl_up_cash_award *= def_lvl_up_cash_award_mult;
        def_lvl_up_coin_award += def_lvl_up_coin_award_mult;

        player_cash_balance += def_lvl_up_cash_award;
        player_coins_balance += def_lvl_up_coin_award;

        inventory_slot_9_player_owned_amount++; // MYSTERY TOKENS
        current_loan_debt_limit += 50;

        // FARM LVL PROGRESS INCREMENTS (incremented by 1 per level)

        farm_1_lvl_progress_inc++;
        farm_2_lvl_progress_inc++;
        farm_3_lvl_progress_inc++;
        farm_4_lvl_progress_inc++;
        farm_5_lvl_progress_inc++;
        farm_6_lvl_progress_inc++;

        if (tier_2_farm_unlocked) {
            tier_2_farm_1_lvl_progress_inc++;
            tier_2_farm_2_lvl_progress_inc++;
            tier_2_farm_3_lvl_progress_inc++;
            tier_2_farm_4_lvl_progress_inc++;
            tier_2_farm_5_lvl_progress_inc++;
            tier_2_farm_6_lvl_progress_inc++;
        }

        // BOARD PASSIVE INCOME UPGRADE LVL PROGRESS INCREMENTS (incremented by 10)

        board_slot_1_upgrade_lvl_progress_inc += 10;
        board_slot_2_upgrade_lvl_progress_inc += 10;
        board_slot_3_upgrade_lvl_progress_inc += 10;
        board_slot_4_upgrade_lvl_progress_inc += 10;
        board_slot_5_upgrade_lvl_progress_inc += 10;
        board_slot_6_upgrade_lvl_progress_inc += 10;

        player_lvl_progress_max = Math.round(player_lvl_progress_max * player_lvl_increase_mult);
        next_lvl_req = player_lvl_progress_max;
        levels_gained++;
    }

    updatePlayerLvlProgressUI();

    milestone_lvl_5_reached = player_lvl >= 5;
    milestone_lvl_10_reached = player_lvl >= 10;
    milestone_lvl_20_reached = player_lvl >= 20;
    milestone_lvl_30_reached = player_lvl >= 30;
    milestone_lvl_40_reached = player_lvl >= 40;
    milestone_lvl_50_reached = player_lvl >= 50;

    levelMilestoneChecker(milestone_claim_opt_1, milestone_lvl_5_reached, 5, previous_level);
    levelMilestoneChecker(milestone_claim_opt_2, milestone_lvl_10_reached, 10, previous_level);
    levelMilestoneChecker(milestone_claim_opt_3, milestone_lvl_20_reached, 20, previous_level);
    levelMilestoneChecker(milestone_claim_opt_4, milestone_lvl_30_reached, 30, previous_level);
    levelMilestoneChecker(milestone_claim_opt_5, milestone_lvl_40_reached, 40, previous_level);
    levelMilestoneChecker(milestone_claim_opt_6, milestone_lvl_50_reached, 50, previous_level);

    if (player_lvl >= 5 && !modifiersUnlockedNotified) {
        modifiers_active = true;
        notificationDialog("You have unlocked the timer modifiers in Trivia!", 4000);
        modifiersUnlockedNotified = true;
    }

    if (levels_gained > 0) {
        setTimeout(() => {
            lvlUpAudio();
            document.getElementById("lvl-up-dialog-overlay").style.display = "flex";
            document.getElementById("lvl-up-award-1").innerHTML = "CASH > " + "<span style='color: springgreen'>$" + formatMoneyValue(def_lvl_up_cash_award) + "</span>";
            document.getElementById("lvl-up-award-2").innerHTML = "COINS > " + "<span style='color: yellow'>" + formatDisplayNumber(Math.round(def_lvl_up_coin_award)) + "</span>";


            let random_booster_win_rng = Math.floor(Math.random() * 30);
            let bonus_feature_win_rng = Math.floor(Math.random() * 50);

            document.getElementById("lvl-up-award-3").innerHTML = "BOOSTER > " + "<span style='color: yellow;'>X1 MYSTERY TOKEN</span>";

            if (bonus_feature_win_rng === 1) {
                let random_bonus_win = Math.floor(Math.random() * 3);
                if (random_bonus_win === 1) {
                    inventory_slot_5_player_owned_amount++;
                    notificationDialog("X1 WILD FREE SPINS BONUS ADDED TO INVENTORY!", 3000);
                    document.getElementById("lvl-up-award-4").innerHTML = "BONUS > " + "<span style='color: purple'>" + "X1 WILD FREE SPINS BONUS" + "</span>";
                } else if (random_bonus_win === 2) {
                    inventory_slot_10_player_owned_amount++;
                    notificationDialog("X1 FREE SPINS BONUS ADDED TO INVENTORY!", 3000);
                    document.getElementById("lvl-up-award-4").innerHTML = "BONUS > " + "<span style='color: gold'>" + "X1 FREE SPINS BONUS" + "</span>";
                }
            }

            if (random_booster_win_rng === 1) {
                inventory_slot_9_player_owned_amount++;
                notificationDialog("X1 MYSTERY TOKEN ADDED TO INVENTORY!", 3000);
                document.getElementById("lvl-up-award-4").innerHTML = "BONUS > " + "<span style='color: orange'>" + "X1 MYSTERY TOKEN" + "</span>";
            } else if (random_booster_win_rng === 3) {
                inventory_slot_6_player_owned_amount++;
                notificationDialog("X1 INSTANT XP BOOSTER ADDED TO INVENTORY!", 3000);
                document.getElementById("lvl-up-award-4").innerHTML = "BONUS > " + "<span style='color: lightblue'>" + "X1 INSTANT XP BOOSTER" + "</span>";
            } else if (random_booster_win_rng === 5) {
                inventory_slot_1_player_owned_amount++;
                notificationDialog("X1 DOUBLE FARM INCOME BOOSTER ADDED TO INVENTORY!", 3000);
                document.getElementById("lvl-up-award-4").innerHTML = "BONUS > " + "<span style='color: lightblue'>" + "X1 DOUBLE FARM INCOME BOOSTER" + "</span>";
            }
        }, 1000)

        setTimeout(() => { document.getElementById("lvl-up-dialog-overlay").style.display = "none"; document.getElementById("lvl-up-award-4").innerHTML = ""; }, 6000)
    }
}


function addPlayerLvlXp(amount) {

    if (double_xp_active) { amount = amount * 2; }
    if (amount <= 0) return;

    if (level_xp_grant_output_preference_active) {
        document.getElementById("lvl-xp-inc-output").style.display = "block";
        document.getElementById("lvl-xp-inc-output").innerHTML = "+<span style='color: springgreen'>" + formatDisplayNumber(amount) + "</span><span style='color: yellow'>XP</span>";
        setTimeout(() => { document.getElementById("lvl-xp-inc-output").innerHTML = ""; document.getElementById("lvl-xp-inc-output").style.display = "none"; }, 1500)
    } else {
        document.getElementById("lvl-xp-inc-output").innerHTML = "";
        document.getElementById("lvl-xp-inc-output").style.display = "none";
    }

    const xpBuff = permanent_buffs_storage.find(buff => buff.buff_id === 2 && buff.buff_active);
    let xpGain = amount;
    if (xpBuff) {
        xpGain = amount * 1.10;
    }

    if (level_xp_grant_output_preference_active) {
        document.getElementById("lvl-xp-inc-output").innerHTML = "+<span style='color: springgreen'>" + formatDisplayNumber(xpGain) + "</span><span style='color: yellow'>XP</span>";
    }

    player_lvl_progress_value += xpGain;

    processPlayerLvlOverflow();
}

document.getElementById("close-lvl-up-dialog-overlay-btn").onclick = function() {
    document.getElementById("lvl-up-dialog-overlay").style.display = "none";
}

let lvl_status_checker = setInterval(() => {
    if (player_lvl_progress_value >= player_lvl_progress_max) {
        processPlayerLvlOverflow();
    }
}, 500)

updatePlayerLvlProgressUI();
