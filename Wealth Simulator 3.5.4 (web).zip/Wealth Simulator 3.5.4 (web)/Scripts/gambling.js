let bet = 1;
let cash_win = 5;
let diamond_win = 1;
let coin_win = 6;
let cherry_win = 1.5;

// Doubled multipliers for 3-reel slot (wins are rarer)

let jack_win = 2;
let queen_win = 2;
let king_win = 3.50;
let triple_coins_win = 10;

let cash_probability = 12;
let coin_probability = 12;
let diamond_probability = 30;
let jack_probability = 10;
let queen_probability = 10;
let king_probability = 15;
let cherry_probability_1 = 15;
let triple_coins_probability_1 = 15;

let star_probability_main = 200;

let jackpot_win_probability = 60;
let wild_win_probability = 4;
let wild_bonus_probability = Math.floor(Math.random() * 10) + 1;
let wild_bonus_free_spins = 0;
let wild_bonus_active = false;
let wild_bet_lock_int;

let wild_bonus_cash_win_total = 0;
let wild_bonus_coin_win_total = 0;
let wild_bonus_diamond_win_total = 0;

let triple_7_win = 2500;
let triple_wild_win = 1500;

let total_777_jackpots_won_counter = 0;
let total_triple_wilds_won_counter = 0;
let total_triple_stars_won_counter = 0;
let total_wild_bonus_won_counter = 0;

let spin_btn = document.getElementById("spin-btn");
let auto_spin_btn = document.getElementById("auto-spin");
let auto_spin_active = false;
let auto_spin_int;
let spin_initiation_status;
let security_control_disable_int;
let stop_auto_spin_btn = document.getElementById("stop-auto-spin");
let bet_btn = document.getElementById("bet-btn");
let max_bet_btn = document.getElementById("max-bet");
let bet_selector_slider = document.getElementById("bet-selector-slider");
let bet_based_cash_win = bet * cash_win;
let bet_based_cash_win_output = document.getElementById("bet-based-cash-win-output");
let bet_step_interval_opts = [document.getElementById("2-step"), document.getElementById("5-step"), document.getElementById("10-step"), document.getElementById("20-step")];
let current_bet_output = document.getElementById("current-bet-output");
let manual_bet_increment_btn = document.getElementById("manual-bet-increment-opt");
let manual_bet_decrement_btn = document.getElementById("manual-bet-decrement-opt");
let reels_spin_int_max = 200;
let reels_spin_int_min = 150;

let final_slot_1_id = document.getElementById("slot-symbol-1");
let final_slot_2_id = document.getElementById("slot-symbol-2");
let final_slot_3_id = document.getElementById("slot-symbol-3");

let bet_slider_step_refs_storage = [document.getElementById('1-step'), document.getElementById('2-step'), document.getElementById('5-step'), document.getElementById('10-step'), document.getElementById('20-step')];
let final_slot_id_storage = [final_slot_1_id, final_slot_2_id, final_slot_3_id];

let total_spins = 0;
let total_spins_cash_earned = 0;
let total_spins_cash_lost = 0;

let high_roller_250_bet_opt = document.getElementById("250-bet");
let high_roller_500_bet_opt = document.getElementById("500-bet");
let high_roller_1000_bet_opt = document.getElementById("1000-bet");
let high_roller_2500_bet_opt = document.getElementById("2500-bet");
let high_roller_5000_bet_opt = document.getElementById("5000-bet");
let high_roller_10000_bet_opt = document.getElementById("10000-bet");
let high_roller_25000_bet_opt = document.getElementById("25000-bet");
let high_roller_50000_bet_opt = document.getElementById("50000-bet");
let high_roller_100000_bet_opt = document.getElementById("100000-bet");
let high_roller_500000_bet_opt = document.getElementById("500000-bet");
let high_roller_1000000_bet_opt = document.getElementById("1000000-bet");
let high_roller_2500000_bet_opt = document.getElementById("2500000-bet");
let high_roller_1000000000_bet_opt = document.getElementById("1000000000-bet");

let high_roller_bets_storage = [high_roller_250_bet_opt, high_roller_500_bet_opt, high_roller_1000_bet_opt, high_roller_2500_bet_opt, high_roller_5000_bet_opt, high_roller_10000_bet_opt];
let high_roller_active = false;
let high_roller_opt = document.getElementById("vip");
let high_roller_disable_opt = document.getElementById("disable-high-roller");

let reel_slot_1 = document.getElementById("gambling-slot-1");
let reel_slot_2 = document.getElementById("gambling-slot-2");
let reel_slot_3 = document.getElementById("gambling-slot-3");

let slot_1_int;
let slot_2_int;
let slot_3_int;

let reels_storage = [reel_slot_1, reel_slot_2, reel_slot_3];

for (let i = 0; i < bet_slider_step_refs_storage.length; i++) {
    bet_slider_step_refs_storage[i].addEventListener("click", () => {
        buttonPressAudio();
    });
}

document.getElementById("3-reel-slot-shortcut-btn").onclick = function() {
    document.getElementById("3-reel-slot-opt").click();
}

// BET SLIDER STEP INTERVAL OPTS

document.getElementById("1-step").onclick = function() { betProgressStepInt(1); manualBetOptDisable(); betSliderResetMeasure(); }
document.getElementById("2-step").onclick = function() { betProgressStepInt(2); manualBetOptDisable(); betSliderResetMeasure(); }
document.getElementById("5-step").onclick = function() { betProgressStepInt(5); manualBetOptDisable(); betSliderResetMeasure(); }
document.getElementById("10-step").onclick = function() { betProgressStepInt(10); manualBetOptDisable(); betSliderResetMeasure(); }
document.getElementById("20-step").onclick = function() { betProgressStepInt(20); manualBetOptDisable(); betSliderResetMeasure(); }

function betSliderResetMeasure() {
    manual_bet_increment_btn.disabled = false; manual_bet_increment_btn.style.cursor = "pointer"; manual_bet_increment_btn.style.opacity = "1";
    manual_bet_decrement_btn.disabled = true; manual_bet_decrement_btn.style.cursor = "not-allowed"; manual_bet_decrement_btn.style.opacity = "0.5";
} betSliderResetMeasure();

function manualBetOptDisable() {
    manual_bet_increment_btn.disabled = false; manual_bet_increment_btn.style.cursor = "pointer"; manual_bet_increment_btn.style.opacity = "1";
    manual_bet_decrement_btn.disabled = false; manual_bet_decrement_btn.style.cursor = "pointer"; manual_bet_decrement_btn.style.opacity = "1";
}

// UNIVERSAL BET SLIDER STEP INTERVAL APLICATOR

function betProgressStepInt(bet_step_amount) {
    bet = bet_step_amount;
    bet_selector_slider.step = bet_step_amount;
    bet_selector_slider.min = bet_step_amount;
    bet_selector_slider.value = bet_step_amount;
    updateBetDisplay();
}

function cashWinVisual() {
    for (let i = 0; i < reels_storage.length; i++) {
        reels_storage[i].style.border = "5px solid lime";
        setTimeout(() => { reels_storage[i].style.border = "1px solid black"; }, 1500)
    }
}

function calculateBetBasedCashWin(currentBet) {
    return currentBet * cash_win;
}

function updateBetDisplay() {
    bet_based_cash_win = calculateBetBasedCashWin(bet);
    bet_based_cash_win_output.innerHTML = "Cash Win : $" + bet_based_cash_win.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

function diamondWinVisual() {
    for (let i = 0; i < reels_storage.length; i++) {
        reels_storage[i].style.border = "5px solid aqua";
        setTimeout(() => { reels_storage[i].style.border = "1px solid black"; }, 1500)
    }
}

function coinWinVisual() {
    for (let i = 0; i < reels_storage.length; i++) {
        reels_storage[i].style.border = "5px solid yellow";
        setTimeout(() => { reels_storage[i].style.border = "1px solid black"; }, 1500)
    }
}

function queenWinVisual() {
    for (let i = 0; i < reels_storage.length; i++) {
        reels_storage[i].style.border = "5px solid #springgreen";
        setTimeout(() => { reels_storage[i].style.border = "1px solid black"; }, 1500)
    }
}

function kingWinVisual() {
    for (let i = 0; i < reels_storage.length; i++) {
        reels_storage[i].style.border = "5px solid aquamarine";
        setTimeout(() => { reels_storage[i].style.border = "1px solid black"; }, 1500)
    }
}

function jackpotWinVisual() {
    for (let i = 0; i < reels_storage.length; i++) {
        reels_storage[i].style.border = "5px solid #yellow";
        setTimeout(() => { reels_storage[i].style.border = "1px solid black"; }, 3000)
    }
}

function cherryWinVisual() {
    for (let i = 0; i < reels_storage.length; i++) {
        reels_storage[i].style.border = "5px solid #E86D72";
        setTimeout(() => { reels_storage[i].style.border = "1px solid black"; }, 2000)
    }
}

// BASE SYMBOLS

//let slot_symbols = ["Images/Cash-balance-icon.png", "Images/Diamond-icon.png", "Images/Tycoon-score-balance-icon.png", "Images/Tycoon-score-balance-icon.png", "Images/j-symbol.svg", "Images/j-symbol.svg", "Images/q-symbol.svg", "Images/q-symbol.svg", "Images/q-symbol.svg", "Images/k-symbol.svg", "Images/cherry-symbol.svg", "Images/cherry-symbol.svg", "Images/cherry-symbol.svg", "Images/cherry-symbol.svg", "Images/cherry-symbol.svg"];

document.getElementById("close-gambling-vip-dialog-overlay-btn").onclick = function() {
    document.getElementById("gambling-vip-dialog-overlay").style.display = "none";
}

document.getElementById("close-wild-bonus-end-overlay-btn").onclick = function() {
    document.getElementById("wild-bonus-end-dialog-overlay").style.display = "none";
    wild_bonus_cash_win_total = 0;
    wild_bonus_coin_win_total = 0;
    wild_bonus_diamond_win_total = 0;
}

high_roller_opt.onclick = function() {
    document.getElementById("gambling-vip-dialog-overlay").style.display = "flex";
}

document.getElementById("increase-wilds-probability-diamond").innerHTML = "Invest X1<span style='color: aqua;'> Diamond</span>";
document.getElementById("increase-wilds-probability-diamond").onclick = function() {
    if (player_diamond_balance >= 1) {
        player_diamond_balance--;
        wild_win_probability -= 2;
        upgradePurchasedAudio();
        notificationDialog("Applied Successfully!", 3000);
    } else {
         upgradePurchaseFailedAudio();
        notificationDialog("Insufficient Diamonds!", 3000);
    }
}

document.getElementById("increase-wilds-probability-coins").innerHTML = "Invest X100<span style='color: yellow;'> Coins</span>";
document.getElementById("increase-wilds-probability-coins").onclick = function() {
    if (player_coins_balance >= 1) {
        player_coins_balance--;
        wild_win_probability -= 2;
        upgradePurchasedAudio();
        notificationDialog("Applied Successfully!", 3000);
    } else {
         upgradePurchaseFailedAudio();
        notificationDialog("Insufficient Diamonds!", 3000);
    }
}

document.getElementById("disable-high-roller").onclick = function() {
    high_roller_active = false;
    high_roller_disable_opt.style.display = "none";
    bet = 2;
    bet_selector_slider.value = 2;
    enableBetOpt();
    notificationDialog("HIGH ROLLER DISABLED!", 3500);
}

function highRollerBetSet(high_roller_bet_opt, high_roller_bet_value) {
    high_roller_disable_opt.style.display = "block";
    high_roller_active = true;
    bet = high_roller_bet_value;
    oscClickAudio();
    notificationDialog("[- HIGH ROLLER ACTIVE -]", 3000);
}

high_roller_250_bet_opt.onclick = function() { highRollerBetSet(this, 250); }
high_roller_500_bet_opt.onclick = function() { highRollerBetSet(this, 500); }
high_roller_1000_bet_opt.onclick = function() { highRollerBetSet(this, 1000); }
high_roller_5000_bet_opt.onclick = function() { highRollerBetSet(this, 5000); }
high_roller_10000_bet_opt.onclick = function() { highRollerBetSet(this, 10000); }
high_roller_25000_bet_opt.onclick = function() { highRollerBetSet(this, 25000); }
high_roller_50000_bet_opt.onclick = function() { highRollerBetSet(this, 50000); }
high_roller_100000_bet_opt.onclick = function() { highRollerBetSet(this, 100000); }
high_roller_500000_bet_opt.onclick = function() { highRollerBetSet(this, 500000); }
high_roller_1000000_bet_opt.onclick = function() { highRollerBetSet(this, 1000000); }

function manualBetIncrement() {
    oscClickAudio();

    if (bet + Number(bet_selector_slider.step) > Number(bet_selector_slider.max)) {
        notificationDialog("Bet cannot exceed $" + formatMoneyValue(Number(bet_selector_slider.max)) + "!", 3000);
    } else if (bet_selector_slider.value >= Number(bet_selector_slider.max)) {
        manual_bet_increment_btn.disabled = true; manual_bet_increment_btn.style.cursor = "not-allowed"; manual_bet_increment_btn.style.opacity = "0.5";
    } else {
        bet += Number(bet_selector_slider.step);
        bet_selector_slider.value = bet;
        current_bet_output.innerHTML = "Current Bet : $" + formatMoneyValue(bet);
        updateBetDisplay();
    }

    if (bet >= Number(bet_selector_slider.max)) {
        manual_bet_increment_btn.disabled = true; manual_bet_increment_btn.style.cursor = "not-allowed"; manual_bet_increment_btn.style.opacity = "0.5";
    } else {
        manualBetOptDisable();
    }
}

function manualBetDecrement() {
    const minimumBet = Number(bet_selector_slider.min);
    const betStep = Number(bet_selector_slider.step);
    oscClickAudio();

    if (bet - betStep < minimumBet) {
        notificationDialog("Bet cannot be less than $" + formatMoneyValue(minimumBet) + "!", 3000);
        bet = minimumBet;
    } else {
        bet -= betStep;
        bet_selector_slider.value = bet;
        current_bet_output.innerHTML = "Current Bet : $" + formatMoneyValue(bet);
        updateBetDisplay();
    }

    if (bet <= minimumBet) {
        manual_bet_decrement_btn.disabled = true; manual_bet_decrement_btn.style.cursor = "not-allowed"; manual_bet_decrement_btn.style.opacity = "0.5";
    } else {
        manualBetOptDisable();
    }
}

function disableBetOpt() {
    bet_btn.disabled = true;
    bet_btn.style.cursor = "not-allowed";
    bet_btn.style.opacity = "0.5";
    max_bet_btn.disabled = true;
    max_bet_btn.style.cursor = "not-allowed";
    max_bet_btn.style.opacity = "0.5";
    high_roller_opt.disabled = true;
    high_roller_opt.style.opacity = "0.5";
    high_roller_opt.style.cursor = "not-allowed";
    high_roller_disable_opt.disabled = true;
    high_roller_disable_opt.style.opacity = "0.5";
    high_roller_disable_opt.cursor = "not-allowed";
}

function enableBetOpt() {
    bet_btn.disabled = false;
    bet_btn.style.cursor = "pointer";
    bet_btn.style.opacity = "1";
    max_bet_btn.disabled = false;
    max_bet_btn.style.cursor = "pointer";
    max_bet_btn.style.opacity = "1";
    high_roller_opt.disabled = false;
    high_roller_opt.style.opacity = "1";
    high_roller_opt.style.cursor = "pointer";
    high_roller_disable_opt.disabled = false;
    high_roller_disable_opt.style.opacity = "1";
    high_roller_disable_opt.cursor = "pointer";
}

function disableGamblingControls() {
    document.getElementById("gambling-bet-dialog-overlay").style.display = "none";
    auto_spin_btn.disabled = true;
    auto_spin_btn.style.cursor = "not-allowed";
    auto_spin_btn.style.opacity = "0.5";
    spin_btn.disabled = true;
    spin_btn.style.cursor = "not-allowed";
    spin_btn.style.opacity = "0.5";
    spin_btn.disabled = true;
    bet_btn.disabled = true;
    bet_btn.style.cursor = "not-allowed";
    bet_btn.style.opacity = "0.5";
    max_bet_btn.disabled = true;
    max_bet_btn.style.cursor = "not-allowed";
    max_bet_btn.style.opacity = "0.5";
    high_roller_opt.disabled = true;
    high_roller_opt.style.opacity = "0.5";
    high_roller_opt.style.cursor = "not-allowed";
}

function enableGamblingControls() {
    auto_spin_btn.disabled = false;
    auto_spin_btn.style.cursor = "pointer";
    auto_spin_btn.style.opacity = "1";
    spin_btn.disabled = false;
    spin_btn.style.cursor = "pointer";
    spin_btn.style.opacity = "1";
    bet_btn.disabled = false;
    bet_btn.style.cursor = "pointer";
    bet_btn.style.opacity = "1";
    max_bet_btn.disabled = false;
    max_bet_btn.style.cursor = "pointer";
    max_bet_btn.style.opacity = "1";
    high_roller_opt.disabled = false;
    high_roller_opt.style.opacity = "1";
    high_roller_opt.style.cursor = "pointer";
    high_roller_disable_opt.disabled = false;
    high_roller_disable_opt.style.opacity = "1";
    high_roller_disable_opt.cursor = "pointer";
}

// STOP / TERMINATE AUTO-SPIN INTERVAL

function terminateAutoSpin() {
    clearInterval(auto_spin_int);
    auto_spin_active = false;
    setTimeout(() => { enableGamblingControls(); }, 5000)
    stop_auto_spin_btn.style.display = "none";
}

function rareWinsRNG(slot_reel) { // RARE WIN RNG
    //let slot_symbol_index = Math.floor(Math.random() * slot_symbols.length);
    let jackpot_win = Math.floor(Math.random() * jackpot_win_probability);
    let wild_win = Math.floor(Math.random() * wild_win_probability);
    let wild_bonus = Math.floor(Math.random() * wild_bonus_probability);
    let star_win_main = Math.floor(Math.random() * star_probability_main);
    let triple_coins_win = Math.floor(Math.random() * triple_coins_probability_1);

    let cash_win = Math.floor(Math.random() * cash_probability);
    let coin_win = Math.floor(Math.random() * coin_probability);
    let diamond_win = Math.floor(Math.random() * diamond_probability);
    let jack_win = Math.floor(Math.random() * jack_probability);
    let queen_win = Math.floor(Math.random() * queen_probability);
    let king_win = Math.floor(Math.random() * king_probability);
    let seven_win = Math.floor(Math.random() * seven_probability);
    let cherry_win = Math.floor(Math.random() * cherry_probability_1);

    if (jackpot_win === 1) {
        slot_reel.src = "Images/triple-777-jackpot.svg";
    } else if (cash_win === 1) {
        slot_reel.src = "Images/Cash-balance-icon.png";
    } else if (coin_win === 1) {
        slot_reel.src = "Images/Tycoon-score-balance-icon.png";
    } else if (diamond_win === 1) {
        slot_reel.src = "Images/Diamond-icon.png";
    } else if (jack_win === 1) {
        slot_reel.src = "Images/j-symbol.svg";
    } else if (queen_win === 1) {
        slot_reel.src = "Images/q-symbol.svg";
    } else if (king_win === 1) {
        slot_reel.src = "Images/k-symbol.svg";
    } else if (triple_coins_win === 1) {
        slot_reel.src = "Images/Points-cluster.png";
    } else if (cherry_win === 1) {
        slot_reel.src = "Images/cherry-symbol.svg";
    } else if (seven_win === 1) {
        slot_reel.src = "Images/triple-777-jackpot-green.svg";
    } else if (wild_win === 1) {
        slot_reel.src = "Images/wild-symbol.svg";
    } else if (wild_bonus === 1) {
        slot_reel.src = "Images/wild-bonus-symbol.svg";
    } else if (star_win_main === 1) {
        slot_reel.src = "Images/star-symbol.svg";
    }
}

function initiateWildBonus() { // WILD BONUS INITIATION SEQUENCE
    wild_bonus_active = true;
    terminateAutoSpin();
    disableGamblingControls();
    notificationDialog("WILD BONUS WON!", 3000);

    setTimeout(() => {
        wild_win_probability = 6;
        wild_bonus_probability = 99999999999999999999;
        wild_bonus_free_spins = 0;

        jack_probability = null;
        queen_probability = null;
        king_probability = null;
        cash_probability = null;

        jackpot_win_probability = 30;
        wild_win_probability = 7;

        lvlUpAudio();
        keyboardClickAudio();
        bet_btn.style.display = "none";
        max_bet_btn.style.display = "none";
        high_roller_opt.style.display = "none";
        inventory_slot_4_use_booster_opt.disabled = true;
        inventory_slot_4_use_booster_opt.style.opacity = "0.5";
        inventory_slot_4_use_booster_opt.style.cursor = "not-allowed";
        inventory_slot_5_use_booster_opt.disabled = true;
        inventory_slot_5_use_booster_opt.style.opacity = "0.5";
        inventory_slot_5_use_booster_opt.style.cursor = "not-allowed";
        setTimeout(() => { notificationDialog("You've received 10 wild free spins with a $" + bet + '', 4000); }, 2000)
        setTimeout(() => { 
            document.getElementById("wild-bonus-free-spins-output").style.display = "block";
            document.getElementById("slot-selection-dialog-overlay").style.display = "none";
            document.getElementById("gambling-vip-dialog-overlay").style.display = "none";
            document.getElementById("slot-symbol-1").src = "Images/wild-bonus-symbol.svg";
            document.getElementById("slot-symbol-2").src = "Images/wild-bonus-symbol.svg";
            document.getElementById("slot-symbol-3").src = "Images/wild-bonus-symbol.svg";
            setTimeout(() => { cashWinVisual(); cashWinVisual(); setTimeout(() => { coinWinVisual(); setTimeout(() => { diamondWinVisual(); }), 500 }), 600 }, 700)
        }, 1000)
        wild_bet_lock_int = setInterval(() => {
            disableBetOpt();
            document.getElementById("disable-high-roller").style.display = "none";
        }, 250)
    }, 500)
}

document.getElementById("start-wild-bonus-dialog-overlay-btn").onclick = function() {
    document.getElementById("wild-bonus-start-dialog-overlay").style.display = "none";
    document.getElementById("gambling-vip-dialog-overlay").style.display = "none";
    document.getElementById("slot-selection-dialog-overlay").style.display = "none";
    setTimeout(() => { clearInterval(security_control_disable_int); }, 1000)
    wild_bonus_active = true;
    initiateWildBonus();
    enableGamblingControls();
}

function initiateSpin() {  // SPIN INITIATION SEQUENCE
    initiateReelRotation();

    slot_1_int = setInterval(() => {
        rareWinsRNG(document.getElementById("slot-symbol-1"));
    }, Math.floor(Math.random() * reels_spin_int_max) + reels_spin_int_min)
    slot_2_int = setInterval(() => {
        rareWinsRNG(document.getElementById("slot-symbol-2"));
    }, Math.floor(Math.random() * reels_spin_int_max) + reels_spin_int_min)
    slot_3_int = setInterval(() => {
        rareWinsRNG(document.getElementById("slot-symbol-3"));
    }, Math.floor(Math.random() * reels_spin_int_max) + reels_spin_int_min)

    for (let i = 0; i < final_slot_id_storage.length; i++) {
        final_slot_id_storage[i].src = "Images/slot-placeholder.svg";
    }

    spinningReelsAudio();
    addPlayerLvlXp(bet * 2);
    total_spins_cash_lost += bet;
    buff_3_spin_counter++;
    total_spins++;
    if (wild_bonus_active) { wild_bonus_free_spins++; }
    if (task_5_active) {
        task_5_progress = increaseProgressValue(task_5_progress, task_5_progress_bar);
        task_5_progress_bar.value = Math.min(Number(task_5_progress_bar.value) + 1, Number(task_5_progress_bar.max) || 100);
    }

    document.getElementById("slot-symbol-1").style.border = "none";
    document.getElementById("slot-symbol-2").style.border = "none";
    document.getElementById("slot-symbol-3").style.border = "none";

    setTimeout(() => {
        clearInterval(slot_1_int);
        clearInterval(slot_2_int);
        clearInterval(slot_3_int);
        if (spin_initiation_status) { setTimeout(() => { enableGamblingControls(); }, 1000); }
        spin_initiation_status = false;

        // FINAL REEL OUTPUT ID's

        let final_slot_1_id = document.getElementById("slot-symbol-1");
        let final_slot_2_id = document.getElementById("slot-symbol-2");
        let final_slot_3_id = document.getElementById("slot-symbol-3");
        
        // CASH MATCH

        if (final_slot_1_id.src.includes("Cash-balance-icon.png") && final_slot_2_id.src.includes("Cash-balance-icon.png") && final_slot_3_id.src.includes("Cash-balance-icon.png")) {
            player_cash_balance += bet * cash_win;
            total_spins_cash_earned += bet * cash_win;
            wild_bonus_cash_win_total += bet * cash_win;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("CASH WIN: $" + (bet * cash_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }

        // DIAMOND MATCH

        if (final_slot_1_id.src.includes("Diamond-icon.png") && final_slot_2_id.src.includes("Diamond-icon.png") && final_slot_3_id.src.includes("Diamond-icon.png")) {
            player_diamond_balance += diamond_win;
            wild_bonus_diamond_win_total += diamond_win;
            smallDingAudio();
            diamondWinVisual();
            notificationDialog("X1 DIAMOND CREDITED!", 3500);
        }

        // COIN MATCH

        if (final_slot_1_id.src.includes("Tycoon-score-balance-icon.png") && final_slot_2_id.src.includes("Tycoon-score-balance-icon.png") && final_slot_3_id.src.includes("Tycoon-score-balance-icon.png")) {
            player_coins_balance += bet * coin_win;
            wild_bonus_coin_win_total += bet * coin_win;
            smallDingAudio();
            coinWinVisual();
            notificationDialog("WIN: " + formatDisplayNumber(bet * coin_win) + " COINS", 3500);
        }

        // JACKS MATCH

        if (final_slot_1_id.src.includes("j-symbol.svg") && final_slot_2_id.src.includes("j-symbol.svg") && final_slot_3_id.src.includes("j-symbol.svg")) {
            player_cash_balance += bet * jack_win;
            total_spins_cash_earned += bet * jack_win;
            wild_bonus_cash_win_total += bet * jack_win;
            smallDingAudio();
            notificationDialog("JACKS WIN: $" + (bet * jack_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3000);
        }

        // QUEENS MATCH

        if (final_slot_1_id.src.includes("q-symbol.svg") && final_slot_2_id.src.includes("q-symbol.svg") && final_slot_3_id.src.includes("q-symbol.svg")) {
            player_cash_balance += bet * queen_win;
            total_spins_cash_earned += bet * queen_win;
            wild_bonus_cash_win_total += bet * queen_win;
            smallDingAudio();
            queenWinVisual();
            notificationDialog("QUEENS WIN: $" + (bet * queen_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3000);
        }

        // KINGS MATCH

        if (final_slot_1_id.src.includes("k-symbol.svg") && final_slot_2_id.src.includes("k-symbol.svg") && final_slot_3_id.src.includes("k-symbol.svg")) {
            player_cash_balance += bet * king_win;
            total_spins_cash_earned += bet * king_win;
            wild_bonus_cash_win_total += bet * king_win;
            smallDingAudio();
            kingWinVisual();
            notificationDialog("KINGS WIN: $" + (bet * king_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3000);
        }

        // TRIPLE 7'S JACKPOT MATCH 

        if (final_slot_1_id.src.includes("triple-777-jackpot.svg") && final_slot_2_id.src.includes("triple-777-jackpot.svg") && final_slot_3_id.src.includes("triple-777-jackpot.svg")) {
            const jackpotAmount = (bet * triple_7_win) * 2; // compute from current bet so it updates when bet changes
            player_cash_balance += jackpotAmount;
            total_spins_cash_earned += jackpotAmount;
            wild_bonus_cash_win_total += jackpotAmount;
            total_777_jackpots_won_counter++;
            terminateAutoSpin();
            jackpotWinVisual();
            notificationDialog("JACKPOT WIN: $" + jackpotAmount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }) + " - CONGRATULATIONS!", 6000);
        }

        // WILD BONUS MATCH

        if (final_slot_1_id.src.includes("wild-bonus-symbol.svg") && final_slot_2_id.src.includes("wild-bonus-symbol.svg") && final_slot_3_id.src.includes("wild-bonus-symbol.svg")) {
            disableGamblingControls();
            disableBetOpt();
            jackpotWinVisual();
            setTimeout(() => {
                document.getElementById("wild-bonus-start-dialog-overlay").style.display = "flex";
            }, 1500)
            document.getElementById("gambling-vip-dialog-overlay").style.display = "none";
            total_wild_bonus_won_counter++;
            if (task_6_active) {
                task_6_progress = increaseProgressValue(task_6_progress, task_6_progress_bar, 100);
                task_6_progress_bar.value = Math.min(Number(task_6_progress_bar.value) + 1, Number(task_6_progress_bar.max) || 100);
            }
            bonusWinAudio();
            disableGamblingControls();
            stop_auto_spin_btn.click();
        }

        // compute wild-based cash payout from current bet (used for mixed WILD+CASH combos)
        const wildCashPayoutAmount = bet * cash_win;
        const wildCoinPayoutAmount = bet * coin_win;

        // WILDS + CASH COMBINATIONS

        if (final_slot_1_id.src.includes("wild-symbol.svg") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("wild-symbol.svg")) {  // WILD, WILD, WILD
            player_cash_balance += triple_wild_win;
            total_spins_cash_earned += triple_wild_win;
            wild_bonus_cash_win_total += triple_wild_win;
            total_triple_wilds_won_counter++;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD WIN: $" + triple_wild_win.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("wild-symbol.svg") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("Cash-balance-icon.png")) { // WILD, WILD, CASH
            player_cash_balance += wildCashPayoutAmount;
            total_spins_cash_earned += wildCashPayoutAmount;
            wild_bonus_cash_win_total += wildCashPayoutAmount;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD WIN: $" + wildCashPayoutAmount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("wild-symbol.svg") && final_slot_2_id.src.includes("Cash-balance-icon.png") && final_slot_3_id.src.includes("Cash-balance-icon.png")) { // WILD, CASH, CASH
            player_cash_balance += wildCashPayoutAmount;
            total_spins_cash_earned += wildCashPayoutAmount;
            wild_bonus_cash_win_total += wildCashPayoutAmount;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD WIN: $" + wildCashPayoutAmount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("Cash-balance-icon.png") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("Cash-balance-icon.png")) { // CASH, WILD, CASH
            player_cash_balance += wildCashPayoutAmount;
            total_spins_cash_earned += wildCashPayoutAmount;
            wild_bonus_cash_win_total += wildCashPayoutAmount;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD WIN: $" + wildCashPayoutAmount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("Cash-balance-icon.png") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("wild-symbol.svg")) { // CASH, WILD, WILD
            player_cash_balance += wildCashPayoutAmount;
            total_spins_cash_earned += wildCashPayoutAmount;
            wild_bonus_cash_win_total += wildCashPayoutAmount;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD WIN: $" + wildCashPayoutAmount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("wild-symbol.svg") && final_slot_2_id.src.includes("Cash-balance-icon.png") && final_slot_3_id.src.includes("wild-symbol.svg")) { // WILD, CASH, WILD
            player_cash_balance += wildCashPayoutAmount;
            total_spins_cash_earned += wildCashPayoutAmount;
            wild_bonus_cash_win_total += wildCashPayoutAmount;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD WIN: $" + wildCashPayoutAmount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("Cash-balance-icon.png") && final_slot_2_id.src.includes("Cash-balance-icon.png") && final_slot_3_id.src.includes("wild-symbol.svg")) { // CASH, CASH, WILD
            player_cash_balance += wildCashPayoutAmount;
            total_spins_cash_earned += wildCashPayoutAmount;
            wild_bonus_cash_win_total += wildCashPayoutAmount;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD WIN: $" + wildCashPayoutAmount.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }

        // WILD + COIN COMBINATIONS

        if (final_slot_1_id.src.includes("wild-symbol.svg") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("Tycoon-score-balance-icon.png")) { // WILD, WILD, COIN
            player_coins_balance += wildCoinPayoutAmount;
            total_spins_cash_earned += wildCoinPayoutAmount;
            wild_bonus_coin_win_total += wildCoinPayoutAmount;
            smallDingAudio();
            coinWinVisual();
            notificationDialog("WILD WIN: " + wildCoinPayoutAmount + " COINS", 3500);
        } else if (final_slot_1_id.src.includes("Tycoon-score-balance-icon.png") && final_slot_2_id.src.includes("Tycoon-score-balance-icon.png") && final_slot_3_id.src.includes("wild-symbol.svg")) { // COIN, COIN, WILD
            player_coins_balance += wildCoinPayoutAmount;
            total_spins_cash_earned += wildCoinPayoutAmount;
            wild_bonus_coin_win_total += wildCoinPayoutAmount;
            smallDingAudio();
            coinWinVisual();
            notificationDialog("WILD WIN: " + wildCoinPayoutAmount + " COINS", 3500);
        } else if (final_slot_1_id.src.includes("wild-symbol.svg") && final_slot_2_id.src.includes("Tycoon-score-balance-icon.png") && final_slot_3_id.src.includes("Tycoon-score-balance-icon.png")) { // WILD, COIN, COIN
            player_coins_balance += wildCoinPayoutAmount;
            total_spins_cash_earned += wildCoinPayoutAmount;
            wild_bonus_coin_win_total += wildCoinPayoutAmount;
            smallDingAudio();
            coinWinVisual();
            notificationDialog("WILD WIN: " + wildCoinPayoutAmount + " COINS", 3500);
        } else if (final_slot_1_id.src.includes("Tycoon-score-balance-icon.png") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("Tycoon-score-balance-icon.png")) { // COIN, WILD, COIN
            player_coins_balance += wildCoinPayoutAmount;
            total_spins_cash_earned += wildCoinPayoutAmount;
            wild_bonus_coin_win_total += wildCoinPayoutAmount;
            smallDingAudio();
            coinWinVisual();
            notificationDialog("WILD WIN: " + wildCoinPayoutAmount + " COINS", 3500);
        } else if (final_slot_1_id.src.includes("Tycoon-score-balance-icon.png") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("wild-symbol.svg")) { // COIN, WILD, WILD
            player_coins_balance += wildCoinPayoutAmount;
            total_spins_cash_earned += wildCoinPayoutAmount;
            wild_bonus_coin_win_total += wildCoinPayoutAmount;
            smallDingAudio();
            coinWinVisual();
            notificationDialog("WILD WIN: " + wildCoinPayoutAmount + " COINS", 3500);
        } else if (final_slot_1_id.src.includes("wild-symbol.svg") && final_slot_2_id.src.includes("Tycoon-score-balance-icon.png") && final_slot_3_id.src.includes("wild-symbol.svg")) { // WILD, COIN, WILD
            player_coins_balance += wildCoinPayoutAmount;
            total_spins_cash_earned += wildCoinPayoutAmount;
            wild_bonus_coin_win_total += wildCoinPayoutAmount;
            smallDingAudio();
            coinWinVisual();
            notificationDialog("WILD WIN: " + wildCoinPayoutAmount + " COINS", 3500);
        }

        // WILD + JACK COMBINATIONS

        if (final_slot_1_id.src.includes("wild-symbol.svg") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("j-symbol.svg")) { // WILD, WILD, JACK
            player_cash_balance += bet * jack_win;
            total_spins_cash_earned += bet * jack_win;
            wild_bonus_cash_win_total += bet * jack_win;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD [JACKS] WIN: $" + (bet * jack_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("j-symbol.svg") && final_slot_2_id.src.includes("j-symbol.svg") && final_slot_3_id.src.includes("wild-symbol.svg")) { // JACK, JACK, WILD
            total_spins_cash_earned += bet * jack_win;
            player_cash_balance += bet * jack_win;
            wild_bonus_cash_win_total += bet * jack_win;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD [JACKS] WIN: $" + (bet * jack_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("wild-symbol.svg") && final_slot_2_id.src.includes("j-symbol.svg") && final_slot_3_id.src.includes("j-symbol.svg")) { // WILD, JACK, JACK
            total_spins_cash_earned += bet * jack_win;
            player_cash_balance += bet * jack_win;
            wild_bonus_cash_win_total += bet * jack_win;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD [JACKS] WIN: $" + (bet * jack_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("j-symbol.svg") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("j-symbol.svg")) { // JACK, WILD, JACK
            total_spins_cash_earned += bet * jack_win;
            player_cash_balance += bet * jack_win;
            wild_bonus_cash_win_total += bet * jack_win;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD [JACKS] WIN: $" + (bet * jack_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("j-symbol.svg") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("wild-symbol.svg")) { // JACK, WILD, WILD
            total_spins_cash_earned += bet * jack_win;
            player_cash_balance += bet * jack_win;
            wild_bonus_cash_win_total += bet * jack_win;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD [JACKS] WIN: $" + (bet * jack_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("wild-symbol.svg") && final_slot_2_id.src.includes("j-symbol.svg") && final_slot_3_id.src.includes("wild-symbol.svg")) { // WILD, JACK, WILD
            total_spins_cash_earned += bet * jack_win;
            player_cash_balance += bet * jack_win;
            wild_bonus_cash_win_total += bet * jack_win;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD [JACKS] WIN: $" + (bet * jack_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }

        // WILD + QUEEN COMBINATIONS

        if (final_slot_1_id.src.includes("wild-symbol.svg") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("q-symbol.svg")) { // WILD, WILD, QUEEN
            player_cash_balance += bet * queen_win;
            total_spins_cash_earned += bet * queen_win;
            wild_bonus_cash_win_total += bet * queen_win;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD [QUEENS] WIN: $" + (bet * queen_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("q-symbol.svg") && final_slot_2_id.src.includes("q-symbol.svg") && final_slot_3_id.src.includes("wild-symbol.svg")) { // QUEEN, QUEEN, WILD
            total_spins_cash_earned += bet * queen_win;
            player_cash_balance += bet * queen_win;
            wild_bonus_cash_win_total += bet * queen_win;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD [QUEENS] WIN: $" + (bet * queen_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("wild-symbol.svg") && final_slot_2_id.src.includes("q-symbol.svg") && final_slot_3_id.src.includes("q-symbol.svg")) { // WILD, QUEEN, QUEEN
            total_spins_cash_earned += bet * queen_win;
            player_cash_balance += bet * queen_win;
            wild_bonus_cash_win_total += bet * queen_win;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD [QUEENS] WIN: $" + (bet * queen_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("q-symbol.svg") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("q-symbol.svg")) { // QUEEN, WILD, QUEEN
            total_spins_cash_earned += bet * queen_win;
            player_cash_balance += bet * queen_win;
            wild_bonus_cash_win_total += bet * queen_win;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD [QUEENS] WIN: $" + (bet * queen_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("q-symbol.svg") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("wild-symbol.svg")) { // QUEEN, WILD, WILD
            total_spins_cash_earned += bet * queen_win;
            player_cash_balance += bet * queen_win;
            wild_bonus_cash_win_total += bet * queen_win;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD [QUEENS] WIN: $" + (bet * queen_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("wild-symbol.svg") && final_slot_2_id.src.includes("q-symbol.svg") && final_slot_3_id.src.includes("wild-symbol.svg")) { // WILD, QUEEN, WILD
            total_spins_cash_earned += bet * queen_win;
            player_cash_balance += bet * queen_win;
            wild_bonus_cash_win_total += bet * queen_win;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD [QUEENS] WIN: $" + (bet * queen_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }

        // WILD + KING COMBINATIONS

        if (final_slot_1_id.src.includes("wild-symbol.svg") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("k-symbol.svg")) { // WILD, WILD, KING
            player_cash_balance += bet * king_win;
            total_spins_cash_earned += bet * king_win;
            wild_bonus_cash_win_total += bet * king_win;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD [KINGS] WIN: $" + (bet * king_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("k-symbol.svg") && final_slot_2_id.src.includes("k-symbol.svg") && final_slot_3_id.src.includes("wild-symbol.svg")) { // KING, KING, WILD
            total_spins_cash_earned += bet * king_win;
            player_cash_balance += bet * king_win;
            wild_bonus_cash_win_total += bet * king_win;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD [KINGS] WIN: $" + (bet * king_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("wild-symbol.svg") && final_slot_2_id.src.includes("k-symbol.svg") && final_slot_3_id.src.includes("k-symbol.svg")) { // WILD, KING, KING
            total_spins_cash_earned += bet * king_win;
            player_cash_balance += bet * king_win;
            wild_bonus_cash_win_total += bet * king_win;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD [KINGS] WIN: $" + (bet * king_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("k-symbol.svg") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("k-symbol.svg")) { // KING, WILD, KING
            total_spins_cash_earned += bet * king_win;
            player_cash_balance += bet * king_win;
            wild_bonus_cash_win_total += bet * king_win;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD [KINGS] WIN: $" + (bet * king_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("k-symbol.svg") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("wild-symbol.svg")) { // KING, WILD, WILD
            total_spins_cash_earned += bet * king_win;
            player_cash_balance += bet * king_win;
            wild_bonus_cash_win_total += bet * king_win;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD [KINGS] WIN: $" + (bet * king_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("wild-symbol.svg") && final_slot_2_id.src.includes("k-symbol.svg") && final_slot_3_id.src.includes("wild-symbol.svg")) { // WILD, KING, WILD
            total_spins_cash_earned += bet * king_win;
            player_cash_balance += bet * king_win;
            wild_bonus_cash_win_total += bet * king_win;
            smallDingAudio();
            cashWinVisual();
            notificationDialog("WILD [KINGS] WIN: $" + (bet * king_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }

        // CHERRIES WIN

        if (final_slot_1_id.src.includes("cherry-symbol.svg") && final_slot_2_id.src.includes("cherry-symbol.svg") && final_slot_3_id.src.includes("cherry-symbol.svg")) {
            player_cash_balance += bet * cherry_win;
            total_spins_cash_earned += bet * cherry_win;
            wild_bonus_cash_win_total += bet * cherry_win;
            cherryWinVisual();
            smallDingAudio();
            notificationDialog("CHERRIES WIN: $" + (bet * cherry_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3000);
        }

        // WILD + CHERRY COMBINATIONS

        if (final_slot_1_id.src.includes("wild-symbol.svg") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("cherry-symbol.svg")) { // WILD, WILD, CHERRY
            player_cash_balance += bet * cherry_win;
            total_spins_cash_earned += bet * cherry_win;
            wild_bonus_cash_win_total += bet * cherry_win;
            smallDingAudio();
            cherryWinVisual();
            notificationDialog("WILD [CHERRIES] WIN: $" + (bet * cherry_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("wild-symbol.svg") && final_slot_2_id.src.includes("cherry-symbol.svg") && final_slot_3_id.src.includes("cherry-symbol.svg")) { // WILD, CHERRY, CHERRY
            total_spins_cash_earned += bet * cherry_win;
            player_cash_balance += bet * cherry_win;
            wild_bonus_cash_win_total += bet * cherry_win;
            smallDingAudio();
            cherryWinVisual();
            notificationDialog("WILD [CHERRIES] WIN: $" + (bet * cherry_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("cherry-symbol.svg") && final_slot_2_id.src.includes("cherry-symbol.svg") && final_slot_3_id.src.includes("wild-symbol.svg")) { // CHERRY, CHERRY, WILD
            total_spins_cash_earned += bet * cherry_win;
            player_cash_balance += bet * cherry_win;
            wild_bonus_cash_win_total += bet * cherry_win;
            smallDingAudio();
            cherryWinVisual();
            notificationDialog("WILD [CHERRIES] WIN: $" + (bet * cherry_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("cherry-symbol.svg") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("cherry-symbol.svg")) { // CHERRY, WILD, CHERRY
            total_spins_cash_earned += bet * cherry_win;
            player_cash_balance += bet * cherry_win;
            wild_bonus_cash_win_total += bet * cherry_win;
            smallDingAudio();
            cherryWinVisual();
            notificationDialog("WILD [CHERRIES] WIN: $" + (bet * cherry_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("cherry-symbol.svg") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("wild-symbol.svg")) { // CHERRY, WILD, WILD
            total_spins_cash_earned += bet * cherry_win;
            player_cash_balance += bet * cherry_win;
            wild_bonus_cash_win_total += bet * cherry_win;
            smallDingAudio();
            cherryWinVisual();
            notificationDialog("WILD [CHERRIES] WIN: $" + (bet * cherry_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("wild-symbol.svg") && final_slot_2_id.src.includes("cherry-symbol.svg") && final_slot_3_id.src.includes("wild-symbol.svg")) { // WILD, CHERRY, WILD
            total_spins_cash_earned += bet * cherry_win;
            player_cash_balance += bet * cherry_win;
            wild_bonus_cash_win_total += bet * cherry_win;
            smallDingAudio();
            cherryWinVisual();
            notificationDialog("WILD [CHERRIES] WIN: $" + (bet * cherry_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }

        // COIN CLUSTER WIN

        if (final_slot_1_id.src.includes("Points-cluster.png") && final_slot_2_id.src.includes("Points-cluster.png") && final_slot_3_id.src.includes("Points-cluster.png")) {
            player_cash_balance += bet * triple_coin_win;
            total_spins_cash_earned += bet * triple_coin_win;
            wild_bonus_cash_win_total += bet * triple_coin_win;
            cherryWinVisual();
            smallDingAudio();
            notificationDialog("COIN CLUSTER WIN: $" + (bet * triple_coin_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3000);
        }

        // WILD + COIN CLUSTER COMBINATIONS

        if (final_slot_1_id.src.includes("Points-cluster.png") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("Points-cluster.png")) { // WILD, WILD, COIN CLUSTER
            player_cash_balance += bet * triple_coin_win;
            total_spins_cash_earned += bet * triple_coin_win;
            wild_bonus_cash_win_total += bet * triple_coin_win;
            smallDingAudio();
            coinWinVisual();
            notificationDialog("WILD [COIN CLUSTER] WIN: $" + (bet * triple_coin_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("wild-symbol.svg") && final_slot_2_id.src.includes("Points-cluster.png") && final_slot_3_id.src.includes("Points-cluster.png")) { // WILD, COIN CLUSTER, COIN CLUSTER
            total_spins_cash_earned += bet * triple_coin_win;
            player_cash_balance += bet * triple_coin_win;
            wild_bonus_cash_win_total += bet * triple_coin_win;
            smallDingAudio();
            coinWinVisual();
            notificationDialog("WILD [COIN CLUSTER] WIN: $" + (bet * triple_coin_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("Points-cluster.png") && final_slot_2_id.src.includes("Points-cluster.png") && final_slot_3_id.src.includes("wild-symbol.svg")) { // COIN CLUSTER, COIN CLUSTER, WILD 
            total_spins_cash_earned += bet * triple_coin_win;
            player_cash_balance += bet * triple_coin_win;
            wild_bonus_cash_win_total += bet * triple_coin_win;
            smallDingAudio();
            coinWinVisual();
            notificationDialog("WILD [COIN CLUSTER] WIN: $" + (bet * triple_coin_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("Points-cluster.png") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("Points-cluster.png")) { // COIN CLUSTER, WILD, COIN CLUSTER
            total_spins_cash_earned += bet * triple_coin_win;
            player_cash_balance += bet * triple_coin_win;
            wild_bonus_cash_win_total += bet * triple_coin_win;
            smallDingAudio();
            coinWinVisual();
            notificationDialog("WILD [COIN CLUSTER] WIN: $" + (bet * triple_coin_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("Points-cluster.png") && final_slot_2_id.src.includes("wild-symbol.svg") && final_slot_3_id.src.includes("wild-symbol.svg")) { // COIN CLUSTER, WILD, WILD
            total_spins_cash_earned += bet * triple_coin_win;
            player_cash_balance += bet * triple_coin_win;
            wild_bonus_cash_win_total += bet * triple_coin_win;
            smallDingAudio();
            coinWinVisual();
            notificationDialog("WILD [COIN CLUSTER] WIN: $" + (bet * triple_coin_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        } else if (final_slot_1_id.src.includes("wild-symbol.svg") && final_slot_2_id.src.includes("Points-cluster.png") && final_slot_3_id.src.includes("wild-symbol.svg")) { // WILD, COIN CLUSTER, WILD
            total_spins_cash_earned += bet * triple_coin_win;
            player_cash_balance += bet * triple_coin_win;
            wild_bonus_cash_win_total += bet * triple_coin_win;
            smallDingAudio();
            coinWinVisual();
            notificationDialog("WILD [COIN CLUSTER] WIN: $" + (bet * triple_coin_win).toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 }), 3500);
        }

        if (final_slot_1_id.src.includes("star-symbol.svg") && final_slot_2_id.src.includes("star-symbol.svg") && final_slot_3_id.src.includes("star-symbol.svg")) {
            const increased_bet_return = bet * 20;
            player_cash_balance += increased_bet_return;
            total_triple_stars_won_counter++;
        }

        for (let i = 0; i < final_slot_id_storage.length; i++) {
            if (final_slot_id_storage[i].src.includes("star-symbol.svg")) {
                const increased_bet_return = bet * 3;
                player_cash_balance += increased_bet_return;

                smallDingAudio();
                notificationDialog("WIN > STAR > $" + formatMoneyValue(increased_bet_return), 3500);
                final_slot_id_storage[i].style.border = "5px solid springgreen";
            }
        }
    }, 4000)
}

function autoSpin() { // AUTO-SPIN INITIATION
    initiateSpin();
    auto_spin_int = setInterval(() => {
        if (wild_bonus_active || player_cash_balance >= bet) {
            if (!wild_bonus_active) {
                player_cash_balance -= bet;
            }

            initiateSpin();
            spinningReelsAudio();
        } else {
            terminateAutoSpin();
            enableGamblingControls();
            notificationDialog("[AUTO-SPIN STOPPED]: Insufficient Funds!", 2000);
        }
    }, 5500);
}

auto_spin_btn.onclick = function() { // AUTO-SPIN VALIDATION
    if (wild_bonus_active || player_cash_balance >= bet) {
        notificationDialog("AUTO-SPIN ACTIVE", 5000);
        disableGamblingControls();
        autoSpin();

        if (wild_bonus_active) { player_cash_balance -= 0; }
        if (!wild_bonus_active) { player_cash_balance -= bet; }

        auto_spin_active = true;
        stop_auto_spin_btn.style.display = "block";
        stop_auto_spin_btn.disabled = true;
        stop_auto_spin_btn.style.cursor = "not-allowed";
        stop_auto_spin_btn.disabled = true;
        stop_auto_spin_btn.style.cursor = "not-allowed";
        stop_auto_spin_btn.style.opacity = "0.5";
        setTimeout(() => {
            stop_auto_spin_btn.disabled = false;
            stop_auto_spin_btn.style.cursor = "pointer";
            stop_auto_spin_btn.style.opacity = "1";
        }, 1000)
        document.getElementById("gambling-vip-dialog-overlay").style.display = "none";
    } else {
        upgradePurchaseFailedAudio();
        notificationDialog("Insufficient Funds!", 2000);
    }
}

stop_auto_spin_btn.onclick = function() { // MANUAL AUTO-SPIN INTERVAL TERMINATION
    terminateAutoSpin();
}

spin_btn.onclick = function() { // SPIN VALIDATION
    if (wild_bonus_active || player_cash_balance >= bet) {
        spin_initiation_status = true;
        
        if (!wild_bonus_active) { player_cash_balance -= bet; }

        document.getElementById("gambling-vip-dialog-overlay").style.display = "none";
        initiateSpin();
        disableGamblingControls();
    } else {
        upgradePurchaseFailedAudio();
        notificationDialog("Insufficient Funds!", 3000)
    }
}

// SLIDER FOR BET SELECTIONS

bet_selector_slider.oninput = function() {
    bet = Number(bet_selector_slider.value);
    current_bet_output.innerHTML = "Current Bet : $" + formatMoneyValue(bet);
    updateBetDisplay();

    if (bet >= Number(bet_selector_slider.max)) {
        manual_bet_increment_btn.disabled = true; manual_bet_increment_btn.style.cursor = "not-allowed"; manual_bet_increment_btn.style.opacity = "0.5";
    } else {
        manualBetOptDisable();
    }

    if (bet <= Number(bet_selector_slider.min)) {
        manual_bet_decrement_btn.disabled = true; manual_bet_decrement_btn.style.cursor = "not-allowed"; manual_bet_decrement_btn.style.opacity = "0.5";
    }
}

// BET UI OPT

bet_btn.onclick = function() {
    document.getElementById("gambling-bet-dialog-overlay").style.display = "flex";
    //high_roller_disable_opt.click();
}

// MAX BET OPT

max_bet_btn.onclick = function() {
    bet = 100;
    bet_selector_slider.value = 100.00;
    updateBetDisplay();
}

document.getElementById("close-gambling-bet-dialog-btn").onclick = function() {
    document.getElementById("gambling-bet-dialog-overlay").style.display = "none";
}