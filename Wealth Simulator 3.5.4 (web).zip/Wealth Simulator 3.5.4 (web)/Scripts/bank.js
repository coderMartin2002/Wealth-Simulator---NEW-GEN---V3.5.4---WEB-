let bank_ui = document.getElementById("bank-ui");
let bank_menu_opt = document.getElementById("bank-menu-opt");
let close_bank_ui_opt = document.getElementById("close-bank-ui-btn");
let close_bank_loans_ui_opt = document.getElementById("close-bank-loans-ui-btn");
let close_bank_hub_selection_dialog_opt = document.getElementById("close-bank-hub-selection-overlay-btn");
let bank_hub_selection_dialog_overlay = document.getElementById("bank-hub-selection-dialog-overlay");

let bank_loans_ui = document.getElementById("bank-loans-ui");
let bank_loans_menu_opt = document.getElementById("bank-loans-menu-opt");

let currency_exchange_opt = document.getElementById("currency-exchange-hub-opt");
let loans_hub_opt = document.getElementById("loans-hub-opt");

// FIELD INPS

let cash_to_coin_field = document.getElementById("cash-to-coin-field-inp");
let cash_to_diamond_field = document.getElementById("cash-to-diamond-field-inp");
let diamond_to_cash_field = document.getElementById("diamond-to-cash-field-inp");

// SLIDER INPS

let cash_to_coin_slider = document.getElementById("cash-to-coin-slider-inp");
let cash_to_diamond_slider = document.getElementById("cash-to-diamond-slider-inp");
let diamond_to_cash_slider = document.getElementById("diamond-to-cash-slider-inp");

// CONVERSION OPTS

let convert_cash_to_coin = document.getElementById("convert-cash-to-coin-opt");
let convert_cash_to_diamond = document.getElementById("convert-cash-to-diamond-opt");
let convert_diamond_to_cash = document.getElementById("convert-diamond-to-cash-opt");

// RATE OUTPUTS

let cash_to_coin_rate_output = document.getElementById("cash-to-coin-rate-output");
let cash_to_diamond_rate_output = document.getElementById("cash-to-diamond-rate-output");
let diamond_to_cash_rate_output = document.getElementById("diamond-to-cash-rate-output");

// RATE GRANT OUTPUTS

let cash_to_coin_grant_output = document.getElementById("cash-to-coin-grant-output");
let cash_to_diamond_grant_output = document.getElementById("cash-to-diamond-grant-output");
let diamond_to_cash_grant_output = document.getElementById("diamond-to-cash-grant-output");

// CURRENCY RATE VALUES (X per Y)

let cash_to_coin_grant_rate = 3;
let cash_to_diamond_grant_rate = 150;
let diamond_to_cash_grant_rate = 1;

let cash_to_coin_conversion_total;
let cash_to_diamond_conversion_total;
let diamond_to_cash_conversion_total;

bank_menu_opt.onclick = function() {
    setTimeout(() => { document.getElementById("bank-hub-selection-dialog-overlay").style.display = "flex"; }, 250); UiClosure();
}

currency_exchange_opt.onclick = function() {
    bank_ui.style.display = "flex";
    document.getElementById("progress-dialog-overlay").style.display = "none";
    document.getElementById("gambling-hub-ui").style.display = "none"; 
    document.getElementById("gambling-hub-ui-2").style.display = "none";
    document.getElementById("gambling-hub-ui-3").style.display = "none";
    document.getElementById("inventory-ui").style.display = "none";
    document.getElementById("slot-selection-dialog-overlay").style.display = "none";
    document.getElementById("fund-farms-ui").style.display = "none";
    document.getElementById("guessing-game-ui").style.display = "none";
    document.getElementById("upgrades-hub-ui").style.display = "none";
    document.getElementById("settings-ui").style.display = "none";
    document.getElementById("timed-dif-timer-mod-dialog-overlay").style.display = "none";
    document.getElementById("dif-info-panel").style.display = "none";
    mods_access_dialog_overlay.style.display = "none";
    mods_ui.style.display = "none";
    trivia_hub_ui.style.display = "none";
    perks_station_ui.style.display = "none";
    bank_hub_selection_dialog_overlay.style.display = "none";
    updates_hub_ui.style.display = "none";
    challenge_hub_ui.style.display = "none";
    console_ui.style.display = "none";
    close_bank_hub_selection_dialog_opt.click();
    keyboardClickAudio();
}

loans_hub_opt.onclick = function() {
    bank_loans_ui.style.display = "flex";
    if (typeof initializeLoanOptions === "function") {
        initializeLoanOptions();
    }
    keyboardClickAudio();
    close_bank_hub_selection_dialog_opt.click();
}

close_bank_ui_opt.onclick = function() {
    bank_ui.style.display = "none";
    bank_loans_ui.style.display = "none";
    loan_manual_management_dialog_overlay.style.display = "none";
    loans_repayment_interval_output_dialog_overlay.style.display = "none";
    custom_loan_payment_dialog_overlay.style.display = "none";
    keyboardClickAudio();
}

close_bank_loans_ui_opt.onclick = function() {
    bank_loans_ui.style.display = "none";
    bank_ui.style.display = "none";
    loan_manual_management_dialog_overlay.style.display = "none";
    loans_repayment_interval_output_dialog_overlay.style.display = "none";
    custom_loan_payment_dialog_overlay.style.display = "none";
    keyboardClickAudio();
}

close_bank_hub_selection_dialog_opt.onclick = function() {
    document.getElementById("bank-hub-selection-dialog-overlay").style.display = "none";
    keyboardClickAudio();
}

// REGULATORS

setInterval(() => {
    cash_to_coin_field.value = "";
    cash_to_diamond_field.value = "";
    diamond_to_cash_field.value = "";
    diamond_to_coin_field.value = "";

    cash_to_coin_slider.value = 10;
    cash_to_diamond_slider.value = 100;
    diamond_to_cash_slider.value = 1;
    diamond_to_coin_slider.value = 1;
}, 20000)

document.getElementById("manual-exchange-value-increment-opt").onclick = function() {
    cash_to_coin_slider.value = Number(cash_to_coin_slider.value) + Number(cash_to_coin_slider.step);
    cash_to_coin_conversion_total = cash_to_coin_slider.value / cash_to_coin_grant_rate;
    cash_to_coin_rate_output.innerHTML = "<span style='color: springgreen'>Cash</span> > <span style='color: springgreen'>$" + formatMoneyValue(cash_to_coin_slider) + "</span> / <span style='color: yellow'>Coins</span> > <span style='color: yellow'>" + cash_to_coin_conversion_total + "</span>";
}

document.getElementById("manual-exchange-value-decrement-opt").onclick = function() {
    cash_to_coin_slider.value = Number(cash_to_coin_slider.value) - Number(cash_to_coin_slider.step);
    cash_to_coin_conversion_total = cash_to_coin_slider.value / cash_to_coin_grant_rate;
    cash_to_coin_rate_output.innerHTML = "<span style='color: springgreen'>Cash</span> > <span style='color: springgreen'>$" + formatMoneyValue(cash_to_coin_slider) + "</span> / <span style='color: yellow'>Coins</span> > <span style='color: yellow'>" + cash_to_coin_conversion_total + "</span>";
}

// CONVERSION SLIDER INPS EVALUATIONS

cash_to_coin_slider.oninput = function() {
    cash_to_coin_conversion_total = cash_to_coin_slider.value / cash_to_coin_grant_rate;
    cash_to_coin_rate_output.innerHTML = "<span style='color: springgreen'>Cash</span> > <span style='color: springgreen'>$" + formatMoneyValue(cash_to_coin_slider) + "</span> / <span style='color: yellow'>Coins</span> > <span style='color: yellow'>" + cash_to_coin_conversion_total + "</span>";
}

cash_to_diamond_slider.oninput = function() {
    cash_to_diamond_conversion_total = cash_to_diamond_slider.value / cash_to_diamond_grant_rate;
    cash_to_diamond_rate_output.innerHTML = "<span style='color: springgreen'>Cash</span> > <span style='color: springgreen'>$" + formatMoneyValue(cash_to_diamond_slider) + "</span> / <span style='color: aqua'>Diamonds</span> > <span style='color: aqua'>" + cash_to_diamond_conversion_total + "</span>";
}

diamond_to_cash_slider.oninput = function() {
    diamond_to_cash_conversion_total = diamond_to_cash_slider.value * cash_to_diamond_grant_rate;
    diamond_to_cash_rate_output.innerHTML = "<span style='color: aqua'>Diamonds</span> > <span style='color: aqua'>" + diamond_to_cash_slider.value + "</span> / <span style='color: springgreen'>Cash</span> > <span style='color: springgreen'>$" + diamond_to_cash_conversion_total.toFixed(2) + "</span>";
}

// CONVERSION OPTS

convert_cash_to_coin.onclick = function() {
    if (player_cash_balance >= cash_to_coin_slider.value) {
        cash_to_coin_conversion_total = cash_to_coin_slider.value / cash_to_coin_grant_rate;
        notificationDialog("[CASH TO COIN] > You received " + cash_to_coin_conversion_total + " coins", 4500);
        player_cash_balance -= cash_to_coin_slider.value;
        player_coins_balance += cash_to_coin_conversion_total;
    }
}

convert_cash_to_diamond.onclick = function() {
    if (player_cash_balance >= cash_to_diamond_slider.value) {
        cash_to_diamond_conversion_total = cash_to_diamond_slider.value / cash_to_diamond_grant_rate;
        notificationDialog("[CASH TO DIAMOND] > You received " + cash_to_diamond_conversion_total, 4500);
        player_cash_balance -= cash_to_diamond_slider.value;
        player_diamond_balance += cash_to_diamond_conversion_total;
    }
}

convert_diamond_to_cash.onclick = function() {
    if (player_diamond_balance >= diamond_to_cash_slider.value) {
        diamond_to_cash_conversion_total = diamond_to_cash_slider.value * cash_to_diamond_grant_rate;
        notificationDialog("[DIAMOND TO CASH] > You received $" + diamond_to_cash_conversion_total, 4500);
        player_diamond_balance -= diamond_to_cash_slider.value;
        player_cash_balance += diamond_to_cash_conversion_total;
    }
}